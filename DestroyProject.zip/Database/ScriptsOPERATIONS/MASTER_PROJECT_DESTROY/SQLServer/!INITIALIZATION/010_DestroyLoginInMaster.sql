﻿USE master
GO

IF EXISTS (SELECT name  FROM sys.sql_logins WHERE name = '$(DBUSER_LOGIN)')
BEGIN
	BEGIN TRY  
		 DROP LOGIN [$(DBUSER_LOGIN)]
	END TRY  
	BEGIN CATCH  
		 PRINT 'Can not drop login [$(DBUSER_LOGIN)].'
		 PRINT 'Error: ' + ISNULL(CAST(ERROR_NUMBER() AS VARCHAR(1024)), '<null>')
		 PRINT 'Message: '+  ISNULL(CAST(ERROR_MESSAGE() AS VARCHAR(1024)), '<null>')
	END CATCH  
END

IF EXISTS (SELECT name  FROM sys.sql_logins WHERE name = '$(DBADMIN_LOGIN)')
BEGIN
	BEGIN TRY  
		 DROP LOGIN [$(DBADMIN_LOGIN)]
	END TRY  
	BEGIN CATCH  
		 PRINT 'Can not drop login [$(DBADMIN_LOGIN)].'
		 PRINT 'Error: ' + ISNULL(CAST(ERROR_NUMBER() AS VARCHAR(1024)), '<null>')
		 PRINT 'Message: '+  ISNULL(CAST(ERROR_MESSAGE() AS VARCHAR(1024)), '<null>')
	END CATCH  
END


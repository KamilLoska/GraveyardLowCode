﻿Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

Add-Type -ReferencedAssemblies "System.Security" -TypeDefinition @"
using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace VSoft.Framework.Environment.Configuration
{
	/// <summary>
	/// SecurityOperation class. Sources must be identical between files:
	/// tfs:$/VSoft Framework/Base/2.2/Base/Environment/Configuration/SecurityOperation.cs (the one to make any changes)
	/// git:\archITekt.All\Tools\DeploymentScripts\SecurityTools.ps1 (sychronized automaticaly with SecurityTools.tt file there)
	/// </summary>
	public class SecurityOperation
	{
		private const string Prefix = "ENC1:";
		private const string DpapiPrefix = "DPAPI:";
		private const string EnvPrefix = "ENV:";
		private static readonly byte[] _ent = new byte[] { 9, 8, 32, 113, 98, 76, 5, 2, 10, 3, 7 };
		private const int AES_IV_LENGTH = 16;

		public static string CreateKey(string password)
		{
			byte[] hash;
			using (MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider())
			{
				byte[] bytes = Encoding.UTF8.GetBytes(password);
				hash = md5.ComputeHash(bytes);
			}
			return BitConverter.ToString(hash).Replace("-", "").ToLowerInvariant();
		}

		public static string GetDpapiData(string key)
		{
			byte[] bytes = Encoding.UTF8.GetBytes(key);
			byte[] protectedBytes = ProtectedData.Protect(bytes, _ent, DataProtectionScope.LocalMachine);
			string protectedString = Convert.ToBase64String(protectedBytes);
			return DpapiPrefix + protectedString;
		}

		public static string GetEnvVariableData(string envVariableName)
		{
			return EnvPrefix + envVariableName;
		}

		public static string GetKeyFromData(string protectedKey)
		{
			if (protectedKey == null)
				return null;

			if (protectedKey.StartsWith(DpapiPrefix, StringComparison.OrdinalIgnoreCase))
			{
				protectedKey = protectedKey.Remove(0, DpapiPrefix.Length);
				byte[] protectedBytes = Convert.FromBase64String(protectedKey);
				byte[] bytes = ProtectedData.Unprotect(protectedBytes, _ent, DataProtectionScope.LocalMachine);
				return Encoding.UTF8.GetString(bytes);
			}

			if (protectedKey.StartsWith(EnvPrefix, StringComparison.OrdinalIgnoreCase))
			{
				protectedKey = protectedKey.Remove(0, EnvPrefix.Length);
				return System.Environment.GetEnvironmentVariable(protectedKey);
			}

			return protectedKey;
		}

		public static string Encrypt(string plainText, string key)
		{
			if (plainText == null)
				return null;

			if (String.IsNullOrEmpty(key))
				return plainText;

			byte[] array;

			using (Aes aes = Aes.Create())
			{
				aes.Key = Encoding.UTF8.GetBytes(key);

				using (ICryptoTransform encryptor = aes.CreateEncryptor(aes.Key, aes.IV))
				{
					using (MemoryStream memoryStream = new MemoryStream())
					{
						memoryStream.Write(aes.IV, 0, AES_IV_LENGTH);
						using (CryptoStream cryptoStream = new CryptoStream(memoryStream, encryptor, CryptoStreamMode.Write))
						{
							using (StreamWriter streamWriter = new StreamWriter(cryptoStream))
							{
								streamWriter.Write(plainText);
							}
							array = memoryStream.ToArray();
						}
					}
				}
			}

			return Prefix + Convert.ToBase64String(array);
		}

		public static string Decrypt(string cipherText, string key)
		{
			if (cipherText == null || !cipherText.StartsWith(Prefix, StringComparison.OrdinalIgnoreCase))
				return cipherText;

			if (String.IsNullOrEmpty(key))
				throw new ArgumentException("Try to read encypted value without provided security key to unprotect it");

			cipherText = cipherText.Remove(0, Prefix.Length);

			byte[] message = Convert.FromBase64String(cipherText);
			if (message.Length < AES_IV_LENGTH)
				throw new ArgumentException("Invalid encrypted value (too short)");

			byte[] iv = new byte[AES_IV_LENGTH];
			byte[] buffer = new byte[message.Length - AES_IV_LENGTH];

			Array.Copy(message, 0, iv, 0, AES_IV_LENGTH);
			Array.Copy(message, AES_IV_LENGTH, buffer, 0, buffer.Length);

			using (Aes aes = Aes.Create())
			{
				aes.Key = Encoding.UTF8.GetBytes(key);
				aes.IV = iv;
				using (ICryptoTransform decryptor = aes.CreateDecryptor(aes.Key, aes.IV))
				{
					using (MemoryStream memoryStream = new MemoryStream(buffer))
					{
						using (CryptoStream cryptoStream = new CryptoStream(memoryStream, decryptor, CryptoStreamMode.Read))
						{
							using (StreamReader streamReader = new StreamReader(cryptoStream))
							{
								return streamReader.ReadToEnd();
							}
						}
					}
				}
			}
		}

		public static bool IsTextEncrypted(string text)
		{
			if (text == null || !text.StartsWith(Prefix, StringComparison.OrdinalIgnoreCase))
				return false;
			return true;
		}
	}
}
"@
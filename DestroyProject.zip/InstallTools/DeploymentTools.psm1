﻿param(
    [parameter(Position=0,Mandatory=$false)][string]$LogFilePath,
    [parameter(Position=1,Mandatory=$false)][string]$SetupLocation
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

if (-not $SetupLocation) {
  $SetupLocation = Join-Path -Path $PSScriptRoot -ChildPath ".."
}

if (-not $LogFilePath) {
	$logDateTime = Get-Date -Format "yyyyMMdd.HHmmss"
	$LogFilePath = Join-Path -Path $SetupLocation -ChildPath "deployment.$logDateTime.log"
}

$LogFileFolder = Split-Path $LogFilePath -Parent
$LogFileName = Split-Path $LogFilePath -Leaf
$LogFileNameDbUpgrader = "$([System.IO.Path]::GetFileNameWithoutExtension($LogFileName)).db$([System.IO.Path]::GetExtension($LogFileName))"

$LogDbUpgFilePath = Join-Path -Path $LogFileFolder -ChildPath $LogFileNameDbUpgrader

#Ensure log folder exist
if (-not (Test-Path $LogFileFolder)) {
	New-Item -Path $LogFileFolder -ItemType Directory
}

# Importing setup tools
Import-Module $PSScriptRoot\SecurityTools.psm1 -Force
Import-Module $PSScriptRoot\ZipTools.psm1 -Force
Import-Module $PSScriptRoot\InstallTools.psm1 -Force -Global -ArgumentList $LogFilePath

Write-VSOFTLog "Initialization of VSoft DeploymentTools module"
Write-VSOFTLog "Logs will be stored in file: $LogFilePath"
Test-VSOFTFileEncodingIsUTF8 $script:MyInvocation.MyCommand.Definition

if ( ($PSVersionTable.PSVersion) -ge (New-Object System.Version("5.1")) ) {
	Write-VSOFTLog "Running on PowerShell version $($PSVersionTable.PSVersion)"
} else {
	Write-VSOFTLog "Running on PowerShell version $($PSVersionTable.PSVersion) which is lower than 5.1. Can not proceed" Error
}

function Remove-ARCHItem(
      [Parameter(Mandatory = $true, ValueFromPipeline = $true)][string[]] $Path,
      [Parameter(Mandatory = $false)][switch] $Recurse,
      [Parameter(Mandatory = $false)][switch] $Force) {
  process {
    Remove-Item -Path $Path -Recurse:$Recurse -Force:$Force -ErrorVariable tmpErr1 -ErrorAction SilentlyContinue;
    if ($tmpErr1.Count -ne 0) {
      Start-Sleep -Seconds 1;
      Remove-Item -Path $Path -Recurse:$Recurse -Force:$Force -ErrorVariable tmpErr2 -ErrorAction SilentlyContinue;
      if ($tmpErr2.Count -ne 0) {
        Start-Sleep -Seconds 2;
        Remove-Item -Path $Path -Recurse:$Recurse -Force:$Force;
      }
    }
  }
}

function Remove-ARCHItemAsScript() {
  $tmpScript = @'
function Remove-ARCHItem(
  [Parameter(Mandatory = $true, ValueFromPipeline = $true)][string[]] $Path,
  [Parameter(Mandatory = $false)][switch] $Recurse,
  [Parameter(Mandatory = $false)][switch] $Force) {
  process {
    Remove-Item -Path $Path -Recurse:$Recurse -Force:$Force -ErrorVariable tmpErr1 -ErrorAction SilentlyContinue;
    if ($tmpErr1.Count -ne 0) {
      Start-Sleep -Seconds 1;
      Remove-Item -Path $Path -Recurse:$Recurse -Force:$Force -ErrorVariable tmpErr2 -ErrorAction SilentlyContinue;
      if ($tmpErr2.Count -ne 0) {
        Start-Sleep -Seconds 2;
        Remove-Item -Path $Path -Recurse:$Recurse -Force:$Force;
      }
    }
  }
}
'@
  $tmpScript
}

#ToDo: Remove
function Open-ARCHSQLConnection(
  [Parameter(Mandatory = $false)][ValidateSet("SQLServer","PostgreSQL")][string] $DatabaseProvider = "SQLServer",  
  [Parameter(Mandatory = $true)][string] $connectionString) 
{
  if ($DatabaseProvider -eq "SQLServer") {
    $tmpConnection = New-Object System.Data.SqlClient.SQLConnection($connectionString)
  } else {
    #$tmpConnection = New-Object Npgsql.NpgsqlConnection($connectionString)
  }
  
  try
  {
    $tmpConnection.Open()
  }
  catch
  {
    Start-Sleep -Seconds 1
    try
    {
      $tmpConnection.Open()
    }
    catch
    {
      Start-Sleep -Seconds 2
      $tmpConnection.Open()
    }
  }
  $tmpConnection
}

function Invoke-ARCHSQLUpdate(
  [Parameter(Mandatory = $false)][ValidateSet("SQLServer","PostgreSQL")][string] $databaseProvider = "SQLServer",
  [Parameter(Mandatory = $true)][string] $connectionString,
  [Parameter(Mandatory = $true)][string] $sqlCommand, 
  [Parameter(Mandatory = $false)][switch] $ignoreResult, 
  [Parameter(Mandatory = $false)][switch] $trace, 
  [Parameter(Mandatory = $false)][hashtable] $sqlParamaters = @{}) {
  
  $dbQueryProgram = Join-Path $PSScriptRoot "..\Database\DbQuery\DbQuery.exe"

  $dbQueryParams = @()
  if ($trace) {
    $dbQueryParams += "--trace"
  }
  $dbQueryParams += "--base64"
  $dbQueryParams += "-p" , "$databaseProvider"
  $dbQueryParams += "-d" , "$connectionString"
  $dbQueryParams += "-q" , [Convert]::ToBase64String([System.Text.Encoding]::Unicode.GetBytes($sqlCommand))
  if ($ignoreResult) {
    $dbQueryParams += "--ignore-result"
  }
  foreach ($parameter in $sqlParamaters.GetEnumerator()) {
    $dbQueryParams += "-a", [Convert]::ToBase64String([System.Text.Encoding]::Unicode.GetBytes("$($parameter.Name):$($parameter.Value)"))  
  }
  #Write-VSOFTLog "$dbQueryProgram $dbQueryParams" 
  $result = & "$dbQueryProgram" $dbQueryParams

  if ($lastexitcode -ne 0) {
    Write-VSOFTLog "Error occured while executing database query process. Please fix the errors manually and run upgrade again to complete the operation.`n$result" Error
  }
  return $result
}

function Update-ARCHDBConfigKey(
  [Parameter(Mandatory = $false)][ValidateSet("SQLServer","PostgreSQL")][string] $DatabaseProvider = "SQLServer",
  [Parameter(Mandatory = $true)][string] $ConnectionString,
  [Parameter(Mandatory = $true)][string] $KeyName,
  [Parameter(Mandatory = $true)][AllowEmptyString()][string] $NewValue,
  [Parameter(Mandatory = $false)][string] $NodeName = "") {

  Write-VSOFTLog "Updating DB config value for key=$KeyName and Node=$NodeName"  
  if ($DatabaseProvider -eq "SQLServer") {
    $query = "EXEC dbo.SetConfigKey @key=@p_key, @value=@p_value, @nodeName=@p_nodeName"
    $parameters = @{"@p_key" = "$KeyName"; "@p_value" = "$NewValue"; "@p_nodeName" = "$NodeName"}
  } else {
    $query = "CALL SetConfigKey(key=>@p_key, value=>@p_value, nodeName=>@p_nodeName);"
    $parameters = @{"@p_key" = "$KeyName"; "@p_value" = "$NewValue"; "@p_nodeName" = "$NodeName"}
  }
  Invoke-ARCHSQLUpdate -DatabaseProvider $DatabaseProvider -connectionString $ConnectionString -sqlCommand $query -sqlParamaters $parameters -ignoreResult | Out-Null
}



############################################################################################
# VIP UTILS 
############################################################################################
Add-Type -Language CSharp -TypeDefinition @"
using System;
namespace VSoft.Vip.Utils
{
	public class HashPassword
	{
		public static string ComputePasswordHash(string a_password)
		{
			byte[] saltBytes = null;
			if (saltBytes == null)
			{
				saltBytes = new byte[new Random().Next(4, 8)];
				new System.Security.Cryptography.RNGCryptoServiceProvider().GetNonZeroBytes(saltBytes);
			}
			byte[] plainTextBytes = System.Text.Encoding.UTF8.GetBytes(a_password);
			byte[] plainTextWithSaltBytes = new byte[plainTextBytes.Length + saltBytes.Length];
			for (int l = 0; l < plainTextBytes.Length; l++)
			{
				plainTextWithSaltBytes[l] = plainTextBytes[l];
			}
			for (int k = 0; k < saltBytes.Length; k++)
			{
				plainTextWithSaltBytes[plainTextBytes.Length + k] = saltBytes[k];
			}
			byte[] hashBytes = new System.Security.Cryptography.SHA256Managed().ComputeHash(plainTextWithSaltBytes);
			byte[] hashWithSaltBytes = new byte[hashBytes.Length + saltBytes.Length];
			for (int j = 0; j < hashBytes.Length; j++)
			{
				hashWithSaltBytes[j] = hashBytes[j];
			}
			for (int i = 0; i < saltBytes.Length; i++)
			{
				hashWithSaltBytes[hashBytes.Length + i] = saltBytes[i];
			}
			return Convert.ToBase64String(hashWithSaltBytes);
		}
	}
}
"@

function Test-ARCHSecurityKey([hashtable]$hashtable, [string]$SecurityKey) {
	foreach ($itemKey in $hashtable.Keys) {
		$item = $hashtable[$itemKey]
		if ($item -is [hashtable]) {
			Test-ARCHSecurityKey -hashtable $item -SecurityKey $SecurityKey
		} else {
			try {
				$tmp = [VSoft.Framework.Environment.Configuration.SecurityOperation]::Decrypt($item, $SecurityKey);
			}
			catch {
				if ($SecurityKey -eq "") {
					Write-VSOFTLog "Can not load encrypted project item ($itemKey), security password is needed" ERROR;
					
				} else {
					Write-VSOFTLog "Can not load encrypted project item ($itemKey), incorrect security password provided" ERROR;
				}
			}
		}
	}
}


function New-ARCHVipUser (
	[Parameter(Mandatory = $true)] [string]$VipConnectionString,
	[Parameter(Mandatory = $true)] [string]$appName,
	[Parameter(Mandatory = $true)] [string]$userName,
	[Parameter(Mandatory = $false)] [string]$userPassword,
	[Parameter(Mandatory = $true)] [string]$userRole) {

	$tmpHashedPassword = [VSoft.Vip.Utils.HashPassword]::ComputePasswordHash($userPassword)

	$tmpSqlCmd = @"
BEGIN TRANSACTION
 
DECLARE @account_name AS NVARCHAR(50)
SET @account_name = @account_login
DECLARE @account_primary_id AS NVARCHAR(20)
SET @account_primary_id = @account_login
DECLARE @account_profile_name AS NVARCHAR(50)
SET @account_profile_name = @account_login + ' - ' + @app_name
DECLARE @account_profile_description AS NVARCHAR(50)
SET @account_profile_description = @account_login + ' - ' + @app_name

DECLARE @app_id INT
DECLARE @role_id INT, @role_usr_id INT
DECLARE @account_id INT, @account_usr_id INT
DECLARE @auth_acc_id INT, @auth_acc_usr_id INT
DECLARE @profile_id AS INT, @profile_usr_id AS INT

DECLARE @current_date AS DATETIME
SET @current_date = getdate()

SET @app_id = (SELECT TOP 1 [Id] FROM[dbo].[Application] WHERE[Name] = @app_name)

---------- Create account ----------------------
PRINT 'Creating account "' + @account_login + '"'
SET @account_id = (SELECT TOP 1 [ACC_ID] FROM[dbo].[Account] WHERE[ACC_NAME] = @account_login)
IF @account_id IS NULL
BEGIN
    INSERT INTO[dbo].[Account]
([ACC_NAME], [ACC_IS_ACTIVE], [ACC_CREATED], [ACC_CREATOR], [ACC_MODIFIED], [ACC_MODIFIER], [ACC_IS_REMOVED])
       VALUES(@account_login, 1, @current_date, -1, @current_date, -1, 0)

    SET @account_id = SCOPE_IDENTITY()

    PRINT 'Created account "' + @account_login + '"'
END
ELSE
BEGIN
    PRINT 'Account "' + @account_login + '" already exist'
END

---------- Assign account to app ----------------------
PRINT 'Assigning account "' + @account_login + '" to app ' + @app_name
IF(SELECT COUNT(*) FROM [dbo].[Account2Application] WHERE[ACC2APP_ACC_ID] = @account_id AND[ACC2APP_APP_ID] = @app_id) = 0
BEGIN
    INSERT INTO[dbo].[Account2Application] ([ACC2APP_ACC_ID], [ACC2APP_APP_ID]) VALUES(@account_id, @app_id)
END
PRINT 'Account "' + @account_login + '" assigned to app ' + @app_name


---------- Update account information ----------------------
PRINT 'Updating account "' + @account_login + '" information'
IF(SELECT COUNT(*) FROM [dbo].[AccountUser] WHERE[ACCUSR_ID] = @account_id) = 0
BEGIN
    INSERT INTO[dbo].[AccountUser] ([ACCUSR_ID], [ACCUSR_FIRST_NAME], [ACCUSR_SURNAME], [ACCUSR_PRIMARY_ID], [ACCUSR_SECONDARY_ID], [ACCUSR_CITY], [ACCUSR_ZIP_CODE], [ACCUSR_STREET], [ACCUSR_STREET_NO], [ACCUSR_PHONE_NUMBER], [ACCUSR_EMAIL], [ACCUSR_MODIFIED], [ACCUSR_MODIFIER]) 
	VALUES (@account_id, @account_name, @account_name, @account_primary_id, '', '', '', '', '', '', '', @current_date, -1)
END
PRINT 'Account "' + @account_login + '" updated'

---------- Set account authentication method and password ----------------------
PRINT 'Setting account "' + @account_login + '" authentication method'
SET @auth_acc_id = (SELECT TOP 1 [AUTH_ID] FROM[dbo].[AccountAuthentication] WHERE[AUTH_ACC_ID] = @account_id)
IF @auth_acc_id IS NULL
BEGIN
    INSERT INTO[dbo].[AccountAuthentication] ([AUTH_ACC_ID]) VALUES(@account_id)
    SET @auth_acc_id = SCOPE_IDENTITY()
END
PRINT 'Account "' + @account_login + '" authentication method updated'

PRINT 'Setting account "' + @account_login + '" password'
IF(SELECT COUNT(*) FROM [dbo].[AccountAuthLoginPass] WHERE[ALP_ID] = @auth_acc_id) = 0
BEGIN
    INSERT INTO[dbo].[AccountAuthLoginPass] ([ALP_ID], [ALP_PASSWORD], [ALP_EXP_DATE], [ALP_MIST_LIMIT], [ALP_LOG_AFTER_EXP])
	VALUES(@auth_acc_id, @account_hashed_password, dateadd(MONTH, 3, cast(@current_date as date)), 4, 4)
END
ELSE
BEGIN
    UPDATE[dbo].[AccountAuthLoginPass]
		SET[ALP_PASSWORD] = @account_hashed_password,
        [ALP_EXP_DATE] = dateadd(MONTH, 3, cast(@current_date as date)),
        [ALP_MIST_LIMIT] = 4,
        [ALP_LOG_AFTER_EXP] = 4
        WHERE[ALP_ID] = @auth_acc_id
END
PRINT 'Account "' + @account_login + '" password updated'


---------- Creating profile ----------------------
PRINT 'Creating profile for account "' + @account_login + '"'
SET @profile_id = (SELECT TOP 1 [PROF_ID] FROM[dbo].[RoleModuleProfile] WHERE[PROF_APP_ID] = @app_id AND[PROF_ACC_ID] = @account_id AND[PROF_NAME] = @account_profile_name)
IF @profile_id IS NULL
BEGIN
    INSERT INTO[dbo].[RoleModuleProfile] ([PROF_APP_ID], [PROF_ACC_ID], [PROF_ACTIVE_FROM], [PROF_ACTIVE_TO], [PROF_DESC], [PROF_NAME], [PROF_TYPE])
	VALUES(@app_id, @account_id, dateadd(day,-1, cast(@current_date as date)), NULL, @account_profile_description, @account_profile_name, 0)

    SET @profile_id = SCOPE_IDENTITY()
END
PRINT 'Profile for account "' + @account_login + '" created'

PRINT 'Assigning role "' + @role_symbol + '" for account "' + @account_login + '"'
SET @role_id = (SELECT TOP 1 [ROLE_ID] FROM[dbo].[RoleModuleRole] WHERE[ROL_SYMBOL] = @role_symbol)
IF(SELECT COUNT(*) FROM [dbo].[RoleModuleProfile2Role] WHERE[PROF2ROL_ROL_ID] = @role_id AND[PROF2ROL_PROF_ID] = @profile_id) = 0
BEGIN
    INSERT INTO[dbo].[RoleModuleProfile2Role] ([PROF2ROL_ROL_ID], [PROF2ROL_PROF_ID]) VALUES(@role_id, @profile_id)
END
PRINT 'Role "' + @role_symbol + '" assigned for account "' + @account_login + '"'

COMMIT
"@

	$tmp = Invoke-ARCHSQLUpdate `
		-connectionString $VipConnectionString `
		-sqlCommand $tmpSqlCmd `
		-sqlParamaters @{"@app_name" = "$appName"; "@account_login" = "$userName" ; "@account_hashed_password" = "$tmpHashedPassword"; "@role_symbol" = "$userRole" }

	Write-VSOFTLog "Sucessfully create new user $userName in application $appName with role $userRole"
}


function Set-ARCHVipPassword(
	[Parameter(Mandatory = $true)] [string]$VipConnectionString,
	[Parameter(Mandatory = $true)] [string]$UserName,
	[Parameter(Mandatory = $true)] [string]$Password) {
	
	$tmpHashedPassword = [VSoft.Vip.Utils.HashPassword]::ComputePasswordHash($password)
	
	$tmpRowsChanged = Invoke-ARCHSQLUpdate `
		-connectionString $VipConnectionString `
		-sqlCommand "UPDATE AccountAuthLoginPass 
		SET ALP_PASSWORD = @HashedPassword, 
		ALP_EXP_DATE = dateadd(MONTH, 3, cast(GETDATE() as date)), 
		ALP_MIST_LIMIT = 4, 
		ALP_LOG_AFTER_EXP = 4 
		WHERE ALP_ID IN ( 
			SELECT ALP_ID FROM AccountAuthLoginPass 
			INNER JOIN AccountAuthentication ON ALP_ID = AUTH_ID 
			INNER JOIN Account ON AUTH_ACC_ID = ACC_ID 
			WHERE ACC_NAME = @LoginName)" `
		-sqlParamaters @{"@LoginName" = "$userName"; "@HashedPassword" = "$tmpHashedPassword" }
	if ($tmpRowsChanged -eq 1) {
		Write-VSOFTLog "Sucessfully set new password for user $userName"
	} else {
		Write-VSOFTLog "There is no user with name $userName (affected rows = $tmpRowsChanged)" Warning
	}
}

############################################################################################
if (-not (Test-Path variable:global:prcInitialized) ) {
	$global:prcLevelMajor = 0.0 #from 0.0 - 1.0
	$global:prcPartMajor = 0.0  #value of next step
	$global:prcLevelMinor = 0.0 #from 0.0 - 1.0
	$global:prcPartMinor = 0.0 #value of next sub-step
	$global:prcInitialized = "initialized"
}

function Trace-ARCHProgressWrite() {
	$percentDOUBLE = ($global:prcLevelMajor + $global:prcPartMajor * $global:prcLevelMinor) * 100.0
	$percentINT = [int]$percentDOUBLE
	Write-VSOFTLog "[PROGRESS:$percentINT%]"
}

function Trace-ARCHProgressStartMajorStep(
	[Parameter(Mandatory = $false)] [double]$startAt = -1.0, 
	[Parameter(Mandatory = $true)] [double]$endAt) {
	
	if ($startAt -eq -1.0 ) {
		$global:prcLevelMajor = $global:prcLevelMajor + $global:prcPartMajor
	} else {
		$global:prcLevelMajor = $startAt
	}
	
	$global:prcPartMajor =  $endAt - $global:prcLevelMajor
	$global:prcLevelMinor = 0.0
   $global:prcPartMinor = 0.0
	Trace-ARCHProgressWrite
}
function Trace-ARCHProgressStartMinorStep(
    [Parameter(Mandatory = $false)] [double] $minorStartAt = -1.0,
    [Parameter(Mandatory = $true)] [double] $minorEndAt) {

	if ($minorStartAt -eq -1.0 ) {
		$global:prcLevelMinor = $global:prcLevelMinor + $global:prcPartMinor
	} else {
		$global:prcLevelMinor = $minorStartAt
	}

   $global:prcPartMinor =  $minorEndAt - $global:prcLevelMinor
	Trace-ARCHProgressWrite
}

####################################################################################
# Utility functions
####################################################################################
# from: https://4sysops.com/archives/convert-json-to-a-powershell-hash-table/
function ConvertTo-Hashtable {
    [CmdletBinding()]
    [OutputType('hashtable')]
    param (
        [Parameter(ValueFromPipeline)]
        $InputObject
    )
 
    process {
        ## Return null if the input is null. This can happen when calling the function
        ## recursively and a property is null
        if ($null -eq $InputObject) {
            return $null
        }
 
        ## Check if the input is an array or collection. If so, we also need to convert
        ## those types into hash tables as well. This function will convert all child
        ## objects into hash tables (if applicable)
        if ($InputObject -is [System.Collections.IEnumerable] -and $InputObject -isnot [string]) {
            $collection = @(
                foreach ($object in $InputObject) {
                    ConvertTo-Hashtable -InputObject $object
                }
            )
 
            ## Return the array but don't enumerate it because the object may be pretty complex
            , $collection
        } elseif ($InputObject -is [psobject]) { ## If the object has properties that need enumeration
            ## Convert it to its own hash table and return it
            $hash = @{}
            foreach ($property in $InputObject.PSObject.Properties) {
                $hash[$property.Name] = ConvertTo-Hashtable -InputObject $property.Value
            }
            $hash
        } else {
            ## If the object isn't an array, collection, or other object, it's already a hash table
            ## So just return it.
            $InputObject
        }
    }
}

function JsonFileRead ([Parameter(Mandatory = $true)] [string]$path){
	$strJson = Get-Content $path -Encoding UTF8 | Out-String
	$objJson = ConvertFrom-Json $strJson

	$hashJson = ConvertTo-Hashtable $objJson
	
	return $hashJson
}

function JsonFileWrite (
	[Parameter(Mandatory = $true)] [string]$path, 
	[Parameter(Mandatory = $true)] [hashtable]$hashtable) {

	$strJson = ConvertTo-Json -InputObject $hashtable
	
	$tmpTryNo = 0;
	while ($true) {
		$tmpTryNo = $tmpTryNo + 1
		try { 
			#System.IO.File write file content in one transaction; Set-Content use 2 transactions (createFile + AppendText)
			[System.IO.File]::WriteAllText($path, $strJson)
			break;
		} catch { 
			if ($tmpTryNo -ge 5) {
				Write-VSOFTLog "Cannot access to file $path. Throwing exception"
				throw;
			}
			Write-VSOFTLog "Cannot access to file $path. Retry $tmpTryNo of 5"
			Start-Sleep -Seconds 1
		}
	}
}

function Import-ARCHUninstallInfoFile([Parameter(Mandatory = $true)] [string]$path){
	return JSonFileRead -path $path
}

function Import-ARCHImageVersionFile([Parameter(Mandatory = $true)] [string]$path){
	return JSonFileRead -path $path
}

function Import-ARCHProjectFile([Parameter(Mandatory = $true)] [string]$path) {
	return JSonFileRead -path $path
}

function Export-ARCHUninstallInfoFile(
	[Parameter(Mandatory = $true)] [string]$path, 
	[Parameter(Mandatory = $true)] [hashtable]$uninstallInfo) {
	
	JsonFileWrite -path $path -hashtable $uninstallInfo
}


function Export-ARCHProjectFile(
	[Parameter(Mandatory = $true)] [string]$path, 
	[Parameter(Mandatory = $true)] [hashtable]$project) {
	
	JsonFileWrite -path $path -hashtable $project
}

function Import-ARCHRuntimeFile (
    [Parameter(Mandatory = $true)] [string]$path){
	
	return JSonFileRead -path $path
}

function Export-ARCHRuntimeFile(
	[Parameter(Mandatory = $true)] [string]$path, 
    [Parameter(Mandatory = $true)] [hashtable]$runtime) {
	
	JsonFileWrite -path $path -hashtable $runtime
}

function Import-ARCHStateFile (
	[Parameter(Mandatory = $true)] [string]$path) {
	
	return JSonFileRead -path $path
}


function Export-ARCHStateFile (
	[Parameter(Mandatory = $true)] [string]$path, 
    [Parameter(Mandatory = $true)] [hashtable]$state) {
	
	JsonFileWrite -path $path -hashtable $state
}


#https://activedirectoryfaq.com/2017/08/creating-individual-random-passwords/
function Get-VSOFTRandomCharacters($length, $characters) {
    $random = 1..$length | ForEach-Object { Get-Random -Maximum $characters.length }
    $private:ofs=""
    return [String]$characters[$random]
}
 
function Scramble-VSOFTString([string]$inputString){     
    $characterArray = $inputString.ToCharArray()   
    $scrambledStringArray = $characterArray | Get-Random -Count $characterArray.Length     
    $outputString = -join $scrambledStringArray
    return $outputString 
}

function Get-ARCHRandomPassword([Parameter(Mandatory = $false)] [int]$length = 14) {
    $password = Get-VSOFTRandomCharacters -length $($length - 8) -characters 'abcdefghiklmnoprstuvwxyz'
    $password += Get-VSOFTRandomCharacters -length 2 -characters 'ABCDEFGHKLMNOPRSTUVWXYZ'
    $password += Get-VSOFTRandomCharacters -length 2 -characters '1234567890'
    $password += Get-VSOFTRandomCharacters -length 2 -characters '@#$%()&*-_|/~'
 
    $password = Scramble-VSOFTString $password
    $password = (Get-VSOFTRandomCharacters -length 1 -characters 'abcdefghiklmnoprstuvwxyz') + $password + (Get-VSOFTRandomCharacters -length 1 -characters 'abcdefghiklmnoprstuvwxyz')
    return $password
}

function Is-VSOFTManagedIdentityAuthentication([Parameter(Mandatory = $false)] [string]$DatabaseUser) {
	if ($DatabaseUser -eq "[azure-managed-identity]") {
		$true
	} else {
		$false
	}
}


function Get-ARCHDatabaseConnection(
    [Parameter(Mandatory = $false)] [ValidateSet("SQLServer", "PostgreSQL")] [string] $DatabaseProvider = "SQLServer",
    [Parameter(Mandatory = $true)] [string]$DatabaseServerInstance,
    [Parameter(Mandatory = $true)] [string]$DatabaseName,
    [Parameter(Mandatory = $false)] [string]$DatabaseUser,
    [Parameter(Mandatory = $false)] [string]$DatabasePassword,
    [Parameter(Mandatory = $false)] [string]$DatabaseOptions) {

  $DatabaseConnectionString = ""
  if ($DatabaseProvider -eq "SQLServer") {
	  $DatabaseUserSecurity = ""
	  if ( -not $DatabaseUser -or ($DatabaseUser -like "*\*") ) {
		  $DatabaseUserSecurity = "Integrated Security=true" 
	  } elseif (Is-VSOFTManagedIdentityAuthentication -DatabaseUser $DatabaseUser) {
		  $DatabaseUserSecurity = "" 
	  } else { 
		  $DatabaseUserSecurity = "User Id=$DatabaseUser;Password=$DatabasePassword" 
	  }
    $DatabaseConnectionString = "data source=$DatabaseServerInstance;initial catalog=$DatabaseName;$DatabaseUserSecurity;$DatabaseOptions"
  } else {
    $DatabaseConnectionString = "Database=$DatabaseName;Host=$DatabaseServerInstance;Username=$DatabaseUser;Password=$DatabasePassword"
  }
  return $DatabaseConnectionString
}

function Import-VSOFTVersionServer ([Parameter(Mandatory=$true)] [String] $VersionServerConsoleFolder,
									[Parameter(Mandatory = $true)] [string]$Connection, 
									[Parameter(Mandatory = $true)] [string]$Provider, 
									[Parameter(Mandatory = $true)] [string]$Archive) {
	
	Write-VSOFTLog "Importing archive '$Archive' into VersionServer"

	$VersionServerConsoleProgram = join-path $VersionServerConsoleFolder "VSoft.VersionServer.Console.exe"
    
    & "$VersionServerConsoleProgram" import -p "$Provider" -s "$Connection" -f "$Archive" | Write-VSOFTLog
    
										
	if ($lastexitcode -ne 0) {
		Write-VSOFTLog "Error occured while executing version server import process. Please fix the errors manually and run upgrade again to complete the operation." Error
	} else {
		Write-VSOFTLog "Version server import process completed sucesfully" 
	}
}

function Clean-VSOFTVersionServer ([Parameter(Mandatory=$true)] [String] $VersionServerConsoleFolder,
									[Parameter(Mandatory = $true)] [string]$Connection, 
									[Parameter(Mandatory = $true)] [string]$Provider) {
	
	Write-VSOFTLog "Cleaning VersionServer"

	$VersionServerConsoleProgram = join-path $VersionServerConsoleFolder "VSoft.VersionServer.Console.exe"
    
    & "$VersionServerConsoleProgram" cleanup -p "$Provider" -s "$Connection" | Write-VSOFTLog
    
										
	if ($lastexitcode -ne 0) {
		Write-VSOFTLog "Error occured while executing version server cleanup process. Please fix the errors manually and run upgrade again to complete the operation." Error
	} else {
		Write-VSOFTLog "Version server cleanup process completed sucesfully" 
	}
}

function Export-VSOFTVersionServer ([Parameter(Mandatory=$true)] [String] $VersionServerConsoleFolder,
									[Parameter(Mandatory = $true)] [string]$Connection, 
									[Parameter(Mandatory = $true)] [string]$Provider, 
									[Parameter(Mandatory = $true)] [string]$Archive) {
	
	Write-VSOFTLog "Exporting VersionServer into archive '$Archive'"

	$VersionServerConsoleProgram = join-path $VersionServerConsoleFolder "VSoft.VersionServer.Console.exe"
    
    & "$VersionServerConsoleProgram" export -p "$Provider" -s "$Connection" -f "$Archive" | Write-VSOFTLog
    
										
	if ($lastexitcode -ne 0) {
		Write-VSOFTLog "Error occured while executing version server export process. Please fix the errors manually and run upgrade again to complete the operation." Error
	} else {
		Write-VSOFTLog "Version server export process completed sucesfully" 
	}
}

function Create-VSOFTArchive(
    [Parameter(Mandatory = $true)] [string] $ZipFilePath, 
    [Parameter(Mandatory = $true)] [string] $SourceDirectoryPath) {

   Add-Type -Assembly System.IO.Compression.FileSystem
   $compressionLevel = [System.IO.Compression.CompressionLevel]::Optimal
   [System.IO.Compression.ZipFile]::CreateFromDirectory($SourceDirectoryPath,
        $ZipFilePath, $compressionLevel, $false)
}

function Test-ARCHCorrectProjectVersion(
	[Parameter(Mandatory = $true)] [hashtable] $project) {

	Write-VSOFTLog "Verifying project version"

	$hashBinaries = JsonFileRead -path (Join-Path -Path $SetupLocation -ChildPath "version.json")
	$projectVersion = [version]$project["ArchITektVersion"]
	$binariesVersion = [version]$hashBinaries["version"]

	Write-VSOFTLog "* Project version: $projectVersion"
	Write-VSOFTLog "* VSoft archITekt image version: $binariesVersion"

	if ($projectVersion -gt $binariesVersion) {
		Write-VSOFTLog "This project has version ($projectVersion) newer than installed archITekt Image version ($binariesVersion). Can not proceed until you install newer archItekt Image version on this computer" Error
	}
}


function Update-ARCHUninstallPackage ([Parameter(Mandatory = $true)] [string]$pathProjectFolder) {
  #create/update uninstall package

  $tmpZipPath = $(Join-Path -Path $pathProjectFolder -ChildPath "DestroyProject.zip")
  $tmpScriptPath = $(Join-Path -Path $pathProjectFolder -ChildPath "DestroyProject.ps1")

  if (Test-Path $tmpZipPath) {
    Remove-ARCHItem -Path $tmpZipPath -Force
  }
  if (Test-Path $tmpScriptPath) {
    Remove-ARCHItem -Path $tmpScriptPath -Force
  }
  Copy-Item -Path ".\DestroyProject.zip" -Destination $tmpZipPath
  Copy-Item -Path ".\DestroyProject.ps1" -Destination $tmpScriptPath
}



####################################################################################
# Step One - create empty Projectironemnt
####################################################################################

function New-ARCHProject(
  [Parameter(Mandatory = $true)] [string]$projectCodeName, 
	[Parameter(Mandatory = $true)] [string]$pathProjectFolder, 
	[Parameter(Mandatory = $false)] [string]$licenseFilePath, 
	[Parameter(Mandatory = $true)] [ValidateSet("FileSystem", "System.Data.SqlClient")] [string]$versionServerProvider, 
	[Parameter(Mandatory = $false)] [string]$versionServerServerInstance,
	[Parameter(Mandatory = $false)] [string]$versionServerServerAdminLogin,
	[Parameter(Mandatory = $false)] [string]$versionServerServerAdminPassword,
	[Parameter(Mandatory = $true)] [ValidateSet("Windows", "UserPassword")] [string]$applicationDbAuthentication,
	[Parameter(Mandatory = $false)] [string] $applicationCredentialAdminUser,
	[Parameter(Mandatory = $false)] [string] $applicationCredentialUser, 
	[Parameter(Mandatory = $false)] [Hashtable] $configKeys,
	[Parameter(Mandatory = $false)] [string] $forceArchITektVersion,
	[Parameter(Mandatory = $false)] [string] $initialVipAdmin,
	[Parameter(Mandatory = $false)] [string] $initialVipUser,
	[Parameter(Mandatory = $false)] [string] $securityKey,
  [Parameter(Mandatory = $false)] [string] $expPostgreSQLServer,
	[Parameter(Mandatory = $false)] [string] $expPostgreSQLUser,
	[Parameter(Mandatory = $false)] [string] $expPostgreSQLPassword,
  [Parameter(Mandatory = $false)] [ValidateSet("CONFIG","DATA","SCHEDULER", "VERSION_SERVER", "VIP")] [string[]] $expPostgreSQLDatabases
	) {


	$pathArchBinariesFolder = $SetupLocation
  $hashBinaries = JsonFileRead -path (Join-Path -Path $pathArchBinariesFolder -ChildPath "version.json")

  Write-VSOFTLog "Creating new project file"
	if ($applicationDbAuthentication -eq "UserPassword") {
		Write-VSOFTLog "Generating admin and user logins & passwords"
		$adminLogin = $($ProjectCodeName + "_admin").ToLower();
		$adminPassword = Get-ARCHRandomPassword
		$userLogin = $($ProjectCodeName + "_user").ToLower();
		$userPassword = Get-ARCHRandomPassword
	} else {
		Write-VSOFTLog "Using windows login admin and user logins & passwords"
		$adminLogin = $applicationCredentialAdminUser
		$adminPassword = ""
		$userLogin = $applicationCredentialUser
		$userPassword = ""
	}

  $versionServerDatabase = $($ProjectCodeName + "_VERSION_SERVER").ToLower();

  if ($versionServerProvider -eq "FileSystem") {
    $versionServerDatabase = ""
  }

  Write-VSOFTLog "Generating project file:"
  $hashProject = @{}; 
	$hashProject.Add("ArchITektImage", $hashBinaries["image"]);
	$hashProject.Add("ArchITektVersion", $hashBinaries["version"]);
	$hashProject.Add("ProjectCodeName", $ProjectCodeName);
	$hashProject.Add("ProjectVersionServerProvider", $versionServerProvider);
	$hashProject.Add("ProjectVersionServerServerInstance", $versionServerServerInstance);
	$hashProject.Add("ProjectVersionServerDatabaseName", $versionServerDatabase);
	$hashProject.Add("DatabaseAdminLogin", $adminLogin);
	$hashProject.Add("DatabaseAdminPassword", [VSoft.Framework.Environment.Configuration.SecurityOperation]::Encrypt($adminPassword, $securityKey));
	$hashProject.Add("DatabaseUserLogin", $userLogin);
	$hashProject.Add("DatabaseUserPassword", [VSoft.Framework.Environment.Configuration.SecurityOperation]::Encrypt($userPassword, $securityKey));

  #add experimental properies only if set!
  if ($expPostgreSQLServer) {
    $hashProject.Add("expPostgreSQLServer", $expPostgreSQLServer);
  }
  if ($expPostgreSQLDatabases) {
	  $hashProject.Add("expPostgreSQLDatabases", $expPostgreSQLDatabases);
  }
    
	if ($configKeys -ne $null) {
		$hashProject.Add("ConfigKeys", $configKeys);
	}
	if ($forceArchITektVersion -ne "") {
		$hashProject["ArchITektVersion"] = $forceArchITektVersion;
	}

	if ($initialVipAdmin) {
		$hashProject["Init_VipAdmin"] = [VSoft.Framework.Environment.Configuration.SecurityOperation]::Encrypt($initialVipAdmin, $securityKey);
	}
	if ($initialVipUser) {
		$hashProject["Init_VipUser"] = [VSoft.Framework.Environment.Configuration.SecurityOperation]::Encrypt($initialVipUser, $securityKey);
	}
	
  Write-VSOFTLog (ConvertTo-Json -InputObject $hashProject)
    
  Write-VSOFTLog "Creating Project folder"
	Write-VSOFTLog "Project will be saved in folder $pathProjectFolder"
	if (Test-Path -Path $pathProjectFolder) {
		Write-VSOFTLog "WARNING: Folder $pathProjectFolder already exits." Warning
	} else {
		New-Item $pathProjectFolder -ItemType Directory -Force
	}

  Write-VSOFTLog "Creating new project subfolders"
  New-Item (Join-Path -Path $pathProjectFolder -ChildPath "SQL") -ItemType Directory -Force
  New-Item (Join-Path -Path $pathProjectFolder -ChildPath "Files") -ItemType Directory -Force
	New-Item (Join-Path -Path $pathProjectFolder -ChildPath "Licenses") -ItemType Directory -Force

  Write-VSOFTLog "Copying license file"
  if (($licenseFilePath -ne "") -and (Test-Path $licenseFilePath)) {
	  Copy-Item -Path $licenseFilePath -Destination (Join-Path -Path $pathProjectFolder -ChildPath "Licenses") -Force
  }

  Write-VSOFTLog "Creating Version Server"
	if ($versionServerProvider -eq "FileSystem") {
	  Write-VSOFTLog "Creating VersionServer subfolder: $pathProjectFolder\VS"
    New-Item (Join-Path -Path $pathProjectFolder -ChildPath "VS") -ItemType Directory -Force
  } else {
  #create connections to databases
  $connectionSuperAdminToMaster = Get-ARCHDatabaseConnection -DatabaseServerInstance $versionServerServerInstance -DatabaseName "master" -DatabaseUser $versionServerServerAdminLogin -DatabasePassword $versionServerServerAdminPassword
  $connectionSuperAdminToVersionServer = Get-ARCHDatabaseConnection -DatabaseServerInstance $versionServerServerInstance -DatabaseName $versionServerDatabase -DatabaseUser $versionServerServerAdminLogin -DatabasePassword $versionServerServerAdminPassword
  $connectionAdminToVersionServer = Get-ARCHDatabaseConnection -DatabaseServerInstance $versionServerServerInstance -DatabaseName $versionServerDatabase -DatabaseUser $adminLogin -DatabasePassword $adminPassword
  $databaseVersionServerProvider = "SQLServer"

  if ($expPostgreSQLDatabases -contains "VERSION_SERVER") 
  {
    $connectionSuperAdminToMaster = Get-ARCHDatabaseConnection -DatabaseProvider "PostgreSQL" -DatabaseServerInstance $expPostgreSQLServer -DatabaseName "postgres" -DatabaseUser $expPostgreSQLUser -DatabasePassword $expPostgreSQLPassword
    $connectionSuperAdminToVersionServer = Get-ARCHDatabaseConnection -DatabaseProvider "PostgreSQL" -DatabaseServerInstance $expPostgreSQLServer -DatabaseName $versionServerDatabase -DatabaseUser $expPostgreSQLUser -DatabasePassword $expPostgreSQLPassword
    $connectionAdminToVersionServer = Get-ARCHDatabaseConnection -DatabaseProvider "PostgreSQL" -DatabaseServerInstance $expPostgreSQLServer -DatabaseName $versionServerDatabase -DatabaseUser $adminLogin -DatabasePassword $adminPassword
    $databaseVersionServerProvider = "PostgreSQL"
  }
  
  
  $pathDbUpgrader = Join-Path -Path $pathArchBinariesFolder -ChildPath "Database\DbUpgrader"
  $pathScripts = Join-Path -Path $pathArchBinariesFolder -ChildPath "Database\Scripts"
  $pathMasterScripts = Join-Path -Path $pathArchBinariesFolder -ChildPath "Database\ScriptsMASTER"
  
  $DbUpgrader_Variables = @{
    "VERSION_SERVER_DATABASE" = $versionServerDatabase;
    "DBADMIN_LOGIN" = $adminLogin;
    "DBADMIN_PASSWORD" = $adminPassword;
    "DBUSER_LOGIN" = $userLogin;
    "DBUSER_PASSWORD" = $userPassword;
    "ELASTIC_POOL" = "not-existing-pool-name"; # there is no possibility to create DB VersionServer on Azure SQL
  }
  $DbUpgrader_MaskedVariables = @("DBADMIN_PASSWORD", "DBUSER_PASSWORD", "ANYUSER_PASSWORD", "ANYUSER_OLDPASSWORD");
		
  #create database and logins
	Write-VSOFTLog "Creating VersionServer database"
  $DbUpdater_Databases = @{
	  "MASTER_PROJECT" = $connectionSuperAdminToMaster;
  }
  $DbUpdater_Providers = @{
	  "MASTER_PROJECT" = $databaseVersionServerProvider;
  }

	$accessToken = ""
	if (Is-VSOFTManagedIdentityAuthentication -DatabaseUser $versionServerServerAdminLogin) {
		$accessToken = "[azure-managed-identity]"
	}
		
  Invoke-VSOFTDbUpgrader -InitializationMode -DbUpgraderFolder $pathDbUpgrader -ScriptsFolder $pathMasterScripts -Databases $DbUpdater_Databases -DatabaseProviders $DbUpdater_Providers -Variables $DbUpgrader_Variables -LogFilePath $LogDbUpgFilePath -AccessToken $accessToken -MaskedVariables $DbUpgrader_MaskedVariables

  #create users and permissions
  Write-VSOFTLog "Creating VersionServer users and grant permissions"
  $DbUpdater_Databases = @{
	"VERSION_SERVER" = $connectionSuperAdminToVersionServer;
  }
  $DbUpdater_Providers = @{
	  "VERSION_SERVER" = $databaseVersionServerProvider;
  }

  Invoke-VSOFTDbUpgrader -InitializationMode -DbUpgraderFolder $pathDbUpgrader -ScriptsFolder $pathMasterScripts -Databases $DbUpdater_Databases -DatabaseProviders $DbUpdater_Providers -Variables $DbUpgrader_Variables -LogFilePath $LogDbUpgFilePath -AccessToken $accessToken -MaskedVariables $DbUpgrader_MaskedVariables

  #initialize version server database
  Write-VSOFTLog "Initializing VersionServer database"
  $DbUpdater_Databases = @{
	  "VERSION_SERVER" = $connectionAdminToVersionServer;
  }
  $DbUpdater_Providers = @{
	  "VERSION_SERVER" = $databaseVersionServerProvider;
  }
  $DbUpgrader_Variables = @{
  }
  Invoke-VSOFTDbUpgrader -InitializationMode -DbUpgraderFolder $pathDbUpgrader -ScriptsFolder $pathScripts -Databases $DbUpdater_Databases -DatabaseProviders $DbUpdater_Providers -Variables $DbUpgrader_Variables -LogFilePath $LogDbUpgFilePath -MaskedVariables $DbUpgrader_MaskedVariables

  #run scripts on version server database
  Write-VSOFTLog "Updating VersionServer database"
  $DbUpdater_Databases = @{
	  "VERSION_SERVER" = $connectionAdminToVersionServer;
  }
  $DbUpdater_Providers = @{
	  "VERSION_SERVER" = $databaseVersionServerProvider;
  }
  $DbUpgrader_Variables = @{
      "VERSION_SERVER_DATABASE" = $versionServerDatabase;
  }
  Invoke-VSOFTDbUpgrader -DbUpgraderFolder $pathDbUpgrader -ScriptsFolder $pathScripts -Databases $DbUpdater_Databases -DatabaseProviders $DbUpdater_Providers -Variables $DbUpgrader_Variables -LogFilePath $LogDbUpgFilePath -MaskedVariables $DbUpgrader_MaskedVariables
  }

  Write-VSOFTLog "Importing initial Version Server archive"
	$versionServerInitialFolder = Join-Path -Path $pathArchBinariesFolder -ChildPath "Database\ScriptsVS\INITIAL"

  if ($hashProject["ProjectVersionServerProvider"] -eq "FileSystem") {
	  $tempPathVersionServerFolder = [System.IO.Path]::GetTempFileName() | %{ rm $_; mkdir $_ }
    $tempPathVersionServerFile = Join-Path -Path $pathProjectFolder -ChildPath "VS\vs.zip"
    if (Test-Path -Path $tempPathVersionServerFile) {
      Remove-Item -Path $tempPathVersionServerFile -Recurse -Force
    }
		Expand-VSOFTArchive -Path "$versionServerInitialFolder\*.zip" -DestinationPath $tempPathVersionServerFolder
		Create-VSOFTArchive -ZipFilePath (Join-Path -Path $pathProjectFolder -ChildPath "VS\vs.zip") -SourceDirectoryPath $tempPathVersionServerFolder
		Remove-ARCHItem -Path $tempPathVersionServerFolder -Recurse -Force
  } else {
    #ToDo: PostgreSQL
    $VersionServerConsoleFolder = Join-Path -Path $pathArchBinariesFolder -ChildPath "Database\VSoft.VersionServer.Console"
	  $DatabasePassword = [VSoft.Framework.Environment.Configuration.SecurityOperation]::Decrypt($hashProject["DatabaseUserPassword"], $SecurityKey)
		$versionServerConnection = Get-ARCHDatabaseConnection -DatabaseServerInstance $hashProject["ProjectVersionServerServerInstance"] -DatabaseName $hashProject["ProjectVersionServerDatabaseName"] -DatabaseUser $hashProject["DatabaseUserLogin"] -DatabasePassword $DatabasePassword
		Get-ChildItem $versionServerInitialFolder -Filter *.zip | Sort-Object | Foreach-Object {
		  Import-VSOFTVersionServer -VersionServerConsoleFolder $VersionServerConsoleFolder -Provider $hashProject["ProjectVersionServerProvider"] -Connection $versionServerConnection -Archive ($_.FullName)
	  }
  }

	$projectFilePath = Join-Path -Path $pathProjectFolder -ChildPath "project.json"

  #Save Project file into folder
  Write-VSOFTLog "Save project file: $projectFilePath"

  #Save Project file on disk
  Export-ARCHProjectFile -path $projectFilePath -Project $hashProject

  #create uninstall package
  Update-ARCHUninstallPackage -pathProjectFolder $pathProjectFolder

  Write-VSOFTLog "Creating new project procedure completed successfully"
}


####################################################################################
# Step Three - Initialize runtime
####################################################################################

function Create-ARCHRuntimePrivate (
	[Parameter(Mandatory = $true)] [string] $pathProjectFolder,
	[Parameter(Mandatory = $true)] [string] $runtimeFileName,
	[Parameter(Mandatory = $true)] [string] $databaseServerInstance,
	[Parameter(Mandatory = $false)] [string] $databaseServerAdminLogin,
	[Parameter(Mandatory = $false)] [string] $databaseServerAdminPassword,
	[Parameter(Mandatory = $false)] [string] $elasticPoolName,
  [Parameter(Mandatory = $false)] [string] $securityKey,
  [Parameter(Mandatory = $false)] [string] $expPostgreSQLAdminLogin,
	[Parameter(Mandatory = $false)] [string] $expPostgreSQLAdminPassword
) {

	Write-VSOFTLogHeader "Create runtime" 2
	$projectFilePath = Join-Path -Path $pathProjectFolder -ChildPath "project.json"
	$hashProject = Import-ARCHProjectFile -path $projectFilePath

  Test-ARCHCorrectProjectVersion -project $hashProject


  $ProjectCodeName = $hashProject["ProjectCodeName"]
  $adminLogin = $hashProject["DatabaseAdminLogin"]
  $adminPassword = [VSoft.Framework.Environment.Configuration.SecurityOperation]::Decrypt($hashProject["DatabaseAdminPassword"], $securityKey); 
  $userLogin = $hashProject["DatabaseUserLogin"] 
  $userPassword = [VSoft.Framework.Environment.Configuration.SecurityOperation]::Decrypt($hashProject["DatabaseUserPassword"], $securityKey) 

  $expPostgreSQLServer = $hashProject["expPostgreSQLServer"] 
  $expPostgreSQLDatabases = $hashProject["expPostgreSQLDatabases"] 

  if ($null -eq $expPostgreSQLDatabases) {
    $expPostgreSQLDatabases = @()
  }
  $tmpAnyPostgreSQLDatabase = $expPostgreSQLDatabases.Count -gt 0

  $pathArchBinariesFolder = $SetupLocation

  $dbDATA = $($ProjectCodeName + "_DATA").ToLower();
  $dbCONFIG = $($ProjectCodeName + "_CONFIG").ToLower();
  $dbSCHEDULER = $($ProjectCodeName + "_SCHEDULER").ToLower();
  $dbVIP = $($ProjectCodeName + "_VIP").ToLower();

  $dbProviderDATA = "SQLServer"
  if ($expPostgreSQLDatabases.Contains("DATA")) {
    $dbProviderDATA = "PostgreSQL"
  }
  $dbProviderCONFIG = "SQLServer"
  if ($expPostgreSQLDatabases.Contains("CONFIG")) {
    $dbProviderCONFIG = "PostgreSQL"
  }
  $dbProviderSCHEDULER = "SQLServer"
  if ($expPostgreSQLDatabases.Contains("SCHEDULER")) {
    $dbProviderSCHEDULER = "PostgreSQL"
  }
  $dbProviderVIP = "SQLServer"
  if ($expPostgreSQLDatabases.Contains("VIP")) {
    $dbProviderVIP = "PostgreSQL"
  }

  $connectionSuperAdminToMaster = Get-ARCHDatabaseConnection -DatabaseServerInstance $databaseServerInstance -DatabaseName "master" -DatabaseUser $databaseServerAdminLogin -DatabasePassword $databaseServerAdminPassword
  if ($tmpAnyPostgreSQLDatabase) {
    $connectionSuperAdminToMasterPostgreSQL = Get-ARCHDatabaseConnection -DatabaseServerInstance $expPostgreSQLServer -DatabaseProvider "PostgreSQL" -DatabaseName "postgres" -DatabaseUser $expPostgreSQLAdminLogin -DatabasePassword $expPostgreSQLAdminPassword
  }
  
  $connectionSuperAdminToDATA = Get-ARCHDatabaseConnection -DatabaseServerInstance $databaseServerInstance -DatabaseName $dbDATA -DatabaseUser $databaseServerAdminLogin -DatabasePassword $databaseServerAdminPassword
  if ($dbProviderDATA -eq "PostgreSQL") {
    $connectionSuperAdminToDATA = Get-ARCHDatabaseConnection -DatabaseServerInstance $expPostgreSQLServer -DatabaseName $dbDATA -DatabaseProvider "PostgreSQL" -DatabaseUser $expPostgreSQLAdminLogin -DatabasePassword $expPostgreSQLAdminPassword
  }
  $connectionSuperAdminToCONFIG = Get-ARCHDatabaseConnection -DatabaseServerInstance $databaseServerInstance -DatabaseName $dbCONFIG -DatabaseUser $databaseServerAdminLogin -DatabasePassword $databaseServerAdminPassword
  if ($dbProviderCONFIG -eq "PostgreSQL") {
    $connectionSuperAdminToCONFIG = Get-ARCHDatabaseConnection -DatabaseServerInstance $expPostgreSQLServer -DatabaseName $dbCONFIG -DatabaseProvider "PostgreSQL" -DatabaseUser $expPostgreSQLAdminLogin -DatabasePassword $expPostgreSQLAdminPassword
  }
  $connectionSuperAdminToSCHEDULER = Get-ARCHDatabaseConnection -DatabaseServerInstance $databaseServerInstance -DatabaseName $dbSCHEDULER -DatabaseUser $databaseServerAdminLogin -DatabasePassword $databaseServerAdminPassword
  if ($dbProviderSCHEDULER -eq "PostgreSQL") {
    $connectionSuperAdminToSCHEDULER = Get-ARCHDatabaseConnection -DatabaseServerInstance $expPostgreSQLServer -DatabaseName $dbSCHEDULER -DatabaseProvider "PostgreSQL" -DatabaseUser $expPostgreSQLAdminLogin -DatabasePassword $expPostgreSQLAdminPassword
  }
  $connectionSuperAdminToVIP = Get-ARCHDatabaseConnection -DatabaseServerInstance $databaseServerInstance -DatabaseName $dbVIP -DatabaseUser $databaseServerAdminLogin -DatabasePassword $databaseServerAdminPassword
  if ($dbProviderVIP -eq "PostgreSQL") {
    $connectionSuperAdminToVIP = Get-ARCHDatabaseConnection -DatabaseServerInstance $expPostgreSQLServer -DatabaseName $dbVIP -DatabaseProvider "PostgreSQL" -DatabaseUser $expPostgreSQLAdminLogin -DatabasePassword $expPostgreSQLAdminPassword
  }

  $connectionAdminToDATA = Get-ARCHDatabaseConnection -DatabaseServerInstance $databaseServerInstance -DatabaseName $dbDATA -DatabaseUser $adminLogin -DatabasePassword $adminPassword
  if ($dbProviderDATA -eq "PostgreSQL") {
    $connectionAdminToDATA = Get-ARCHDatabaseConnection -DatabaseServerInstance $expPostgreSQLServer -DatabaseName $dbDATA -DatabaseProvider "PostgreSQL" -DatabaseUser $adminLogin -DatabasePassword $adminPassword
  }
  $connectionAdminToCONFIG = Get-ARCHDatabaseConnection -DatabaseServerInstance $databaseServerInstance -DatabaseName $dbCONFIG -DatabaseUser $adminLogin -DatabasePassword $adminPassword
  if ($dbProviderCONFIG -eq "PostgreSQL") {
    $connectionAdminToCONFIG = Get-ARCHDatabaseConnection -DatabaseServerInstance $expPostgreSQLServer -DatabaseName $dbCONFIG -DatabaseProvider "PostgreSQL" -DatabaseUser $adminLogin -DatabasePassword $adminPassword
  }
  $connectionAdminToSCHEDULER = Get-ARCHDatabaseConnection -DatabaseServerInstance $databaseServerInstance -DatabaseName $dbSCHEDULER -DatabaseUser $adminLogin -DatabasePassword $adminPassword
  if ($dbProviderSCHEDULER -eq "PostgreSQL") {
    $connectionAdminToSCHEDULER = Get-ARCHDatabaseConnection -DatabaseServerInstance $expPostgreSQLServer -DatabaseName $dbSCHEDULER -DatabaseProvider "PostgreSQL" -DatabaseUser $adminLogin -DatabasePassword $adminPassword
  }
  $connectionAdminToVIP = Get-ARCHDatabaseConnection -DatabaseServerInstance $databaseServerInstance -DatabaseName $dbVIP -DatabaseUser $adminLogin -DatabasePassword $adminPassword
  if ($dbProviderVIP -eq "PostgreSQL") {
    $connectionAdminToVIP = Get-ARCHDatabaseConnection -DatabaseServerInstance $expPostgreSQLServer -DatabaseName $dbVIP -DatabaseProvider "PostgreSQL" -DatabaseUser $adminLogin -DatabasePassword $adminPassword
  }

  $pathDbUpgrader = Join-Path -Path $pathArchBinariesFolder -ChildPath "Database\DbUpgrader"
  $pathScripts = Join-Path -Path $pathArchBinariesFolder -ChildPath "Database\Scripts"
  $pathMasterScripts = Join-Path -Path $pathArchBinariesFolder -ChildPath "Database\ScriptsMASTER"

  $DbUpgrader_Variables = @{
		"DATA_DATABASE" = $dbDATA;
		"CONFIG_DATABASE" = $dbCONFIG;
		"SCHEDULER_DATABASE" = $dbSCHEDULER;
		"VIP_DATABASE" = $dbVIP;
		"DBADMIN_LOGIN" = $adminLogin;
		"DBADMIN_PASSWORD" = $adminPassword;
		"DBUSER_LOGIN" = $userLogin;
		"DBUSER_PASSWORD" = $userPassword;
		"ELASTIC_POOL" = $elasticPoolName;
  }
	$DbUpgrader_MaskedVariables = @("DBADMIN_PASSWORD", "DBUSER_PASSWORD", "ANYUSER_PASSWORD", "ANYUSER_OLDPASSWORD");

  #create database and logins
  Write-VSOFTLog "Creating runtime databases"
  $DbUpdater_Databases = @{
	   "MASTER_RUNTIME" = $connectionSuperAdminToMaster;
  }

	$accessToken = ""
	if (Is-VSOFTManagedIdentityAuthentication -DatabaseUser $databaseServerAdminLogin) {
		$accessToken = "[azure-managed-identity]"
	}

  Invoke-VSOFTDbUpgrader -InitializationMode -DbUpgraderFolder $pathDbUpgrader -ScriptsFolder $pathMasterScripts -Databases $DbUpdater_Databases -Variables $DbUpgrader_Variables -LogFilePath $LogDbUpgFilePath -AccessToken $accessToken -MaskedVariables $DbUpgrader_MaskedVariables
  if ($tmpAnyPostgreSQLDatabase) {
    $DbUpdater_Databases = @{
	     "MASTER_RUNTIME" = $connectionSuperAdminToMasterPostgreSQL;
    }
    $DbUpdater_Providers = @{
	     "MASTER_RUNTIME" = "PostgreSQL";
    }
    Invoke-VSOFTDbUpgrader -InitializationMode -DbUpgraderFolder $pathDbUpgrader -ScriptsFolder $pathMasterScripts -Databases $DbUpdater_Databases -DatabaseProviders $DbUpdater_Providers -Variables $DbUpgrader_Variables -LogFilePath $LogDbUpgFilePath -AccessToken $accessToken -MaskedVariables $DbUpgrader_MaskedVariables
  }

  #create users and permissions
  Write-VSOFTLog "Creating users and grant permissions in runtime databases"
  $DbUpdater_Databases = @{
	  "CONFIG" = $connectionSuperAdminToCONFIG;
	  "DATA" = $connectionSuperAdminToDATA;
	  "SCHEDULER" = $connectionSuperAdminToSCHEDULER;
    "VIP" = $connectionSuperAdminToVIP;
  }
  $DbUpdater_Providers = @{
	  "CONFIG" = $dbProviderCONFIG;
	  "DATA" = $dbProviderDATA;
	  "SCHEDULER" = $dbProviderSCHEDULER;
    "VIP" = $dbProviderVIP;
  }
  Invoke-VSOFTDbUpgrader -InitializationMode -DbUpgraderFolder $pathDbUpgrader -ScriptsFolder $pathMasterScripts -Databases $DbUpdater_Databases -DatabaseProviders $DbUpdater_Providers -Variables $DbUpgrader_Variables -LogFilePath $LogDbUpgFilePath -AccessToken $accessToken -MaskedVariables $DbUpgrader_MaskedVariables

  #initialize databases
  Write-VSOFTLog "Initializing runtime databases"
  $DbUpdater_Databases = @{
	  "CONFIG" = $connectionAdminToCONFIG;
	  "DATA" = $connectionAdminToDATA;
	  "SCHEDULER" = $connectionAdminToSCHEDULER;
    "VIP" = $connectionAdminToVIP;
  }
  $DbUpgrader_Variables = @{
  }
  Invoke-VSOFTDbUpgrader -InitializationMode -DbUpgraderFolder $pathDbUpgrader -ScriptsFolder $pathScripts -Databases $DbUpdater_Databases -DatabaseProviders $DbUpdater_Providers -Variables $DbUpgrader_Variables -LogFilePath $LogDbUpgFilePath -MaskedVariables $DbUpgrader_MaskedVariables

  #save information to runtime file

	$hashRuntime = @{}; 

  $hashRuntime.Add("DatabaseServerInstance", $databaseServerInstance);
  $hashRuntime.Add("DatabaseNameCONFIG", $dbCONFIG);
  $hashRuntime.Add("DatabaseNameDATA", $dbDATA);
  $hashRuntime.Add("DatabaseNameSCHEDULER", $dbSCHEDULER);
  $hashRuntime.Add("DatabaseNameVIP", $dbVIP);

	$runtimeFilePath = Join-Path -Path $pathProjectFolder -ChildPath $runtimeFileName
  Export-ARCHRuntimeFile -path $runtimeFilePath -runtime $hashRuntime 
}

function New-ARCHRuntimeDeveloper (
	[Parameter(Mandatory = $true)] [string]$pathProjectFolder,
	[Parameter(Mandatory = $false)] [string]$runtimeFileName = "default.runtime.json",
	[Parameter(Mandatory = $true)] [string]$environmentName,
	[Parameter(Mandatory = $true)] [string]$runtimeFolder,
	[Parameter(Mandatory = $true)] [string]$databaseServerInstance,
  [Parameter(Mandatory = $false)] [string]$databaseServerAdminLogin,
  [Parameter(Mandatory = $false)] [string]$databaseServerAdminPassword,
  [Parameter(Mandatory = $true)] [ValidateSet("SSL", "NONE")] [string]$securityMode,
	[Parameter(Mandatory = $false)] [string]$reservedPortsBlockBegin,
	[Parameter(Mandatory = $false)] [ValidateSet("On", "Off")] [string] $FeatureSSO = "Off",
	[Parameter(Mandatory = $false)] [string] $securityKey,
  [Parameter(Mandatory = $false)] [string]$expPostgreSQLAdminLogin,
  [Parameter(Mandatory = $false)] [string]$expPostgreSQLAdminPassword) {
	
  Create-ARCHRuntimePrivate `
		-pathProjectFolder $pathProjectFolder `
		-runtimeFileName $runtimeFileName `
		-databaseServerInstance $databaseServerInstance `
		-databaseServerAdminLogin $databaseServerAdminLogin `
		-databaseServerAdminPassword $databaseServerAdminPassword `
		-elasticPoolName "" `
		-securityKey $securityKey `
    -expPostgreSQLAdminLogin $expPostgreSQLAdminLogin `
    -expPostgreSQLAdminPassword $expPostgreSQLAdminPassword


	$runtimeFilePath = Join-Path -Path $pathProjectFolder -ChildPath $runtimeFileName
  $hashRuntime = Import-ARCHRuntimeFile -path $runtimeFilePath

	$hashRuntime["RuntimeType"] = "Developer"
	$hashRuntime["Config_EnvironmentName"] = $environmentName
	$hashRuntime["RuntimeFolder"] = $runtimeFolder	
  $hashRuntime["SecurityMode"] = $securityMode
	$hashRuntime["ReservedPortsBlockBegin"] = $reservedPortsBlockBegin
	$hashRuntime["FeatureSSO"] = $FeatureSSO;


   Export-ARCHRuntimeFile -path $runtimeFilePath -runtime  $hashRuntime
}

function New-ARCHRuntimeContainers (
	[Parameter(Mandatory = $true)] [string] $pathProjectFolder,
	[Parameter(Mandatory = $true)] [string] $environmentName,
	[Parameter(Mandatory = $false)] [string] $runtimeFolder = "",
	[Parameter(Mandatory = $true)] [string] $databaseServerInstance,
    [Parameter(Mandatory = $false)] [string] $databaseServerAdminLogin,
    [Parameter(Mandatory = $false)] [string] $databaseServerAdminPassword,
	[Parameter(Mandatory = $true)] [ValidateSet("SSL", "NONE")] [string] $securityMode,
    [Parameter(Mandatory = $true)] [string] $reservedPortsBlockBegin,
    [Parameter(Mandatory = $true)] [string] $appServerFQDNAddress,
	[Parameter(Mandatory = $true)] [string] $webServerFQDNAddress,
	[Parameter(Mandatory = $true)] [string[]] $targetAppServers,
	[Parameter(Mandatory = $true)] [string[]] $targetWebServers,
	[Parameter(Mandatory = $false)] [string] $appServer_HttpsCertificate = "0000000000000000000000000000000000000000",
	[Parameter(Mandatory = $false)] [string] $webServer_HttpsCertificate = "0000000000000000000000000000000000000000",
	[Parameter(Mandatory = $false)] [string] $applicationCredentialUser = "",
	[Parameter(Mandatory = $false)] [string] $applicationCredentialPassword = "",
	[Parameter(Mandatory = $true)] [string] $elasticPoolName,
	[Parameter(Mandatory = $false)] [string] $securityKey) {
   
	$runtimeFileName = "default.runtime.json"
	
	if (-not $runtimeFolder) {
		$projectFilePath = Join-Path -Path $pathProjectFolder -ChildPath "project.json"
      $hashProject = Import-ARCHProjectFile -path $projectFilePath
      $ProjectCodeName = $hashProject["ProjectCodeName"]
      $runtimeFolder = Join-Path -Path "C:\VSoft" -ChildPath $ProjectCodeName
   }

	Create-ARCHRuntimePrivate `
		-pathProjectFolder $pathProjectFolder `
		-runtimeFileName $runtimeFileName `
		-databaseServerInstance $databaseServerInstance `
		-databaseServerAdminLogin $databaseServerAdminLogin `
		-databaseServerAdminPassword $databaseServerAdminPassword `
		-elasticPoolName $elasticPoolName `
		-securityKey $securityKey


	$runtimeFilePath = Join-Path -Path $pathProjectFolder -ChildPath $runtimeFileName
   $hashRuntime = Import-ARCHRuntimeFile -path $runtimeFilePath
    
	$hashRuntime["RuntimeType"] = "Container"
	$hashRuntime["Config_EnvironmentName"] = $environmentName
   $hashRuntime["RuntimeFolder"] = $runtimeFolder	
	$hashRuntime["SecurityMode"] = $securityMode
	$hashRuntime["TargetAppServers"] = $targetAppServers
	$hashRuntime["TargetWebServers"] = $targetWebServers
	$hashRuntime["AppServerFQDNAddress"] = $appServerFQDNAddress
	$hashRuntime["WebServerFQDNAddress"] = $webServerFQDNAddress
	$hashRuntime["AppServer_HttpsCertificate"] = $appServer_HttpsCertificate
	$hashRuntime["WebServer_HttpsCertificate"] = $webServer_HttpsCertificate
	
	$hashRuntime["ApplicationCredentialUser"] = $applicationCredentialUser
	$hashRuntime["ApplicationCredentialPassword"] = [VSoft.Framework.Environment.Configuration.SecurityOperation]::Encrypt($applicationCredentialPassword, $securityKey)
	$hashRuntime["ReservedPortsBlockBegin"] = $reservedPortsBlockBegin
		
	Export-ARCHRuntimeFile -path $runtimeFilePath -runtime  $hashRuntime

	$stateFilePath = Join-Path -Path $pathProjectFolder -ChildPath "state.json"
	$stateDateTime = Get-Date -Format "yyyyMMdd.HHmmss"

	$hashState = @{};
	$hashState["VersionServerTimeStamp"] = "$stateDateTime"
	$hashState["BinariesTimeStamp"] = "$stateDateTime"
	$hashState["ApplicationShouldRun"] = $true
	$hashState["MemorySnapshotTimeSpan"] = "01:00:00"
	
	Export-ARCHStateFile -path $stateFilePath -state  $hashState
}
	
function New-ARCHRuntimeOnPremises (
	[Parameter(Mandatory = $true)] [string] $pathProjectFolder,
	[Parameter(Mandatory = $true)] [string] $environmentName,
	[Parameter(Mandatory = $false)] [string] $runtimeFolder = "",
	[Parameter(Mandatory = $true)] [string] $databaseServerInstance,
  [Parameter(Mandatory = $false)] [string] $databaseServerAdminLogin,
  [Parameter(Mandatory = $false)] [string] $databaseServerAdminPassword,
	[Parameter(Mandatory = $true)] [ValidateSet("SSL", "NONE")] [string] $securityMode,
  [Parameter(Mandatory = $true)] [string] $reservedPortsBlockBegin,
  [Parameter(Mandatory = $true)] [string] $appServerFQDNAddress,
	[Parameter(Mandatory = $true)] [string] $webServerFQDNAddress,
	[Parameter(Mandatory = $true)] [string[]] $targetAppServers,
	[Parameter(Mandatory = $true)] [string[]] $targetWebServers,
	[Parameter(Mandatory = $false)] [string] $appServer_HttpsCertificate = "0000000000000000000000000000000000000000",
	[Parameter(Mandatory = $false)] [string] $webServer_HttpsCertificate = "0000000000000000000000000000000000000000",
	[Parameter(Mandatory = $false)] [string] $applicationCredentialUser = "",
	[Parameter(Mandatory = $false)] [string] $applicationCredentialPassword = "",
	[Parameter(Mandatory = $false)] [ValidateSet("On", "Off")] [string] $FeatureSSO = "Off",
	[Parameter(Mandatory = $false)] [string] $FailoverCluster = "",
  [Parameter(Mandatory = $false)] [string] $FailoverClusterGroup = "",
  [Parameter(Mandatory = $false)] [ValidateSet("Automatic", "AutomaticDelayedStart", "Disabled", "Manual")] [string]$ServiceStartupType,
  [Parameter(Mandatory = $false)] [string] $securityKey) {

    $runtimeFileName = "default.runtime.json"

   if (-not $runtimeFolder) {
		$projectFilePath = Join-Path -Path $pathProjectFolder -ChildPath "project.json"
      $hashProject = Import-ARCHProjectFile -path $projectFilePath
      $ProjectCodeName = $hashProject["ProjectCodeName"]
      $runtimeFolder = Join-Path -Path "C:\VSoft" -ChildPath $ProjectCodeName
   }

  Create-ARCHRuntimePrivate `
		-pathProjectFolder $pathProjectFolder `
		-runtimeFileName $runtimeFileName `
		-databaseServerInstance $databaseServerInstance `
		-databaseServerAdminLogin $databaseServerAdminLogin `
		-databaseServerAdminPassword $databaseServerAdminPassword `
		-elasticPoolName "" `
		-securityKey $securityKey


  $runtimeFilePath = Join-Path -Path $pathProjectFolder -ChildPath $runtimeFileName
  $hashRuntime = Import-ARCHRuntimeFile -path $runtimeFilePath
    
	$hashRuntime["RuntimeType"] = "OnPremises"
	$hashRuntime["Config_EnvironmentName"] = $environmentName
  $hashRuntime["RuntimeFolder"] = $runtimeFolder	
	$hashRuntime["SecurityMode"] = $securityMode
	$hashRuntime["TargetAppServers"] = $targetAppServers
	$hashRuntime["TargetWebServers"] = $targetWebServers
	$hashRuntime["AppServerFQDNAddress"] = $appServerFQDNAddress
	$hashRuntime["WebServerFQDNAddress"] = $webServerFQDNAddress
	$hashRuntime["AppServer_HttpsCertificate"] = $appServer_HttpsCertificate
	$hashRuntime["WebServer_HttpsCertificate"] = $webServer_HttpsCertificate
	
	$hashRuntime["ApplicationCredentialUser"] = $applicationCredentialUser
	$hashRuntime["ApplicationCredentialPassword"] = [VSoft.Framework.Environment.Configuration.SecurityOperation]::Encrypt($applicationCredentialPassword, $securityKey)
	$hashRuntime["ReservedPortsBlockBegin"] = $reservedPortsBlockBegin
	$hashRuntime["FeatureSSO"] = $FeatureSSO;
  
  $hashRuntime["FailoverCluster"] = $FailoverCluster
  $hashRuntime["FailoverClusterGroupName"] = $FailoverClusterGroup

  $hashRuntime["ServiceStartupType"] = $ServiceStartupType

	Export-ARCHRuntimeFile -path $runtimeFilePath -runtime  $hashRuntime
}

####################################################################################
# Destroy projects
####################################################################################
function Get-ARCHRuntimeDeveloperFolder (
	[Parameter(Mandatory = $true)] [string]$pathProjectFolder,
	[Parameter(Mandatory = $false)] [string]$runtimeFileName = "default.runtime.json") {
	$runtimeFilePath = Join-Path -Path $pathProjectFolder -ChildPath $runtimeFileName
	if (Test-Path -Path $runtimeFilePath) {
		$hashRuntime = Import-ARCHRuntimeFile -path $runtimeFilePath 
		
		$hashRuntime["RuntimeFolder"]
	} else {
		""
	}
}


function Remove-ARCHRuntimeDeveloper (
	[Parameter(Mandatory = $true)] [string]$pathProjectFolder,
	[Parameter(Mandatory = $false)] [string]$runtimeFileName = "default.runtime.json",
   [Parameter(Mandatory = $false)] [string]$databaseServerAdminLogin,
   [Parameter(Mandatory = $false)] [string]$databaseServerAdminPassword,
	[Parameter(Mandatory = $false)] [switch]$leaveRuntimeFolder) {


	$projectFilePath = Join-Path -Path $pathProjectFolder -ChildPath "project.json"
	$runtimeFilePath = Join-Path -Path $pathProjectFolder -ChildPath $runtimeFileName

	if (Test-Path -Path $runtimeFilePath) {

		$hashProject = Import-ARCHProjectFile -path $projectFilePath
		$hashRuntime = Import-ARCHRuntimeFile -path $runtimeFilePath 

		#Test-ARCHCorrectProjectVersion -project $hashProject
		$databaseServerInstance = $hashRuntime["DatabaseServerInstance"];


		$ProjectCodeName = $hashProject["ProjectCodeName"]
		$adminLogin = $hashProject["DatabaseAdminLogin"]
		$userLogin = $hashProject["DatabaseUserLogin"] 
		$pathArchBinariesFolder = $SetupLocation

		$dbDATA = $ProjectCodeName + "_DATA"
		$dbCONFIG = $ProjectCodeName + "_CONFIG"
		$dbSCHEDULER = $ProjectCodeName + "_SCHEDULER"
		$dbVIP = $ProjectCodeName + "_VIP"

		$connectionSuperAdminToMaster = Get-ARCHDatabaseConnection -DatabaseServerInstance $databaseServerInstance -DatabaseName "master" -DatabaseUser $databaseServerAdminLogin -DatabasePassword $databaseServerAdminPassword
		$connectionSuperAdminToDATA = Get-ARCHDatabaseConnection -DatabaseServerInstance $databaseServerInstance -DatabaseName $dbDATA -DatabaseUser $databaseServerAdminLogin -DatabasePassword $databaseServerAdminPassword
		$connectionSuperAdminToCONFIG = Get-ARCHDatabaseConnection -DatabaseServerInstance $databaseServerInstance -DatabaseName $dbCONFIG -DatabaseUser $databaseServerAdminLogin -DatabasePassword $databaseServerAdminPassword
		$connectionSuperAdminToSCHEDULER = Get-ARCHDatabaseConnection -DatabaseServerInstance $databaseServerInstance -DatabaseName $dbSCHEDULER -DatabaseUser $databaseServerAdminLogin -DatabasePassword $databaseServerAdminPassword
		$connectionSuperAdminToVIP = Get-ARCHDatabaseConnection -DatabaseServerInstance $databaseServerInstance -DatabaseName $dbVIP -DatabaseUser $databaseServerAdminLogin -DatabasePassword $databaseServerAdminPassword

		$pathDbUpgrader = Join-Path -Path $pathArchBinariesFolder -ChildPath "Database\DbUpgrader"
		$pathMasterScripts = Join-Path -Path $pathArchBinariesFolder -ChildPath "Database\ScriptsOPERATIONS"

		$DbUpgrader_Variables = @{
			"DATA_DATABASE" = $dbDATA;
			"CONFIG_DATABASE" = $dbCONFIG;
			"SCHEDULER_DATABASE" = $dbSCHEDULER;
			"VIP_DATABASE" = $dbVIP;
			"DBADMIN_LOGIN" = $adminLogin;
			"DBUSER_LOGIN" = $userLogin;
		}
		$DbUpgrader_MaskedVariables = @("DBADMIN_PASSWORD", "DBUSER_PASSWORD", "ANYUSER_PASSWORD", "ANYUSER_OLDPASSWORD");

		#drop database and logins
		Write-VSOFTLog "Destroying runtime databases"
		$DbUpdater_Databases = @{
			"MASTER_RUNTIME_DESTROY" = $connectionSuperAdminToMaster;
		}

		$accessToken = ""
		if (Is-VSOFTManagedIdentityAuthentication -DatabaseUser $databaseServerAdminLogin) {
			$accessToken = "[azure-managed-identity]"
		}

		Invoke-VSOFTDbUpgrader -InitializationMode -DbUpgraderFolder $pathDbUpgrader -ScriptsFolder $pathMasterScripts -Databases $DbUpdater_Databases -Variables $DbUpgrader_Variables -LogFilePath $LogDbUpgFilePath -AccessToken $accessToken -MaskedVariables $DbUpgrader_MaskedVariables

		if (!$leaveRuntimeFolder) {
			Remove-ARCHItem -Path $runtimeFilePath -Force
		}
	}
}

function Remove-ARCHRuntimeOnPremises (
	[Parameter(Mandatory = $true)] [string]$pathProjectFolder,
	[Parameter(Mandatory = $false)] [string]$runtimeFileName = "default.runtime.json",
  [Parameter(Mandatory = $false)] [string]$databaseServerAdminLogin,
  [Parameter(Mandatory = $false)] [string]$databaseServerAdminPassword,
	[Parameter(Mandatory = $false)] [string]$expPostgreSQLUser,
	[Parameter(Mandatory = $false)] [string]$expPostgreSQLPassword) {


	$projectFilePath = Join-Path -Path $pathProjectFolder -ChildPath "project.json"
	$runtimeFilePath = Join-Path -Path $pathProjectFolder -ChildPath $runtimeFileName

	if (Test-Path -Path $runtimeFilePath) {

		$hashProject = Import-ARCHProjectFile -path $projectFilePath
		$hashRuntime = Import-ARCHRuntimeFile -path $runtimeFilePath 

		#Test-ARCHCorrectProjectVersion -project $hashProject
		$databaseServerInstance = $hashRuntime["DatabaseServerInstance"];


		$ProjectCodeName = $hashProject["ProjectCodeName"]
		$adminLogin = $hashProject["DatabaseAdminLogin"]
		$userLogin = $hashProject["DatabaseUserLogin"] 
		$pathArchBinariesFolder = $SetupLocation

		$dbDATA = $hashRuntime["DatabaseNameDATA"]
		$dbCONFIG = $hashRuntime["DatabaseNameCONFIG"]
		$dbSCHEDULER = $hashRuntime["DatabaseNameSCHEDULER"]
		$dbVIP = $hashRuntime["DatabaseNameVIP"]

		$connectionSuperAdminToMaster = Get-ARCHDatabaseConnection -DatabaseServerInstance $databaseServerInstance -DatabaseName "master" -DatabaseUser $databaseServerAdminLogin -DatabasePassword $databaseServerAdminPassword

		$pathDbUpgrader = Join-Path -Path $pathArchBinariesFolder -ChildPath "Database\DbUpgrader"
		$pathMasterScripts = Join-Path -Path $pathArchBinariesFolder -ChildPath "Database\ScriptsOPERATIONS"

		$DbUpgrader_Variables = @{
			"DATA_DATABASE" = $dbDATA;
			"CONFIG_DATABASE" = $dbCONFIG;
			"SCHEDULER_DATABASE" = $dbSCHEDULER;
			"VIP_DATABASE" = $dbVIP;
			"DBADMIN_LOGIN" = $adminLogin;
			"DBUSER_LOGIN" = $userLogin;
		}
		$DbUpgrader_MaskedVariables = @("DBADMIN_PASSWORD", "DBUSER_PASSWORD", "ANYUSER_PASSWORD", "ANYUSER_OLDPASSWORD");

		#drop database and logins
		Write-VSOFTLog "Destroying runtime databases"
		$DbUpdater_Databases = @{
			"MASTER_RUNTIME_DESTROY" = $connectionSuperAdminToMaster;
		}

		$accessToken = ""
		if (Is-VSOFTManagedIdentityAuthentication -DatabaseUser $databaseServerAdminLogin) {
			$accessToken = "[azure-managed-identity]"
		}

		Invoke-VSOFTDbUpgrader -InitializationMode -DbUpgraderFolder $pathDbUpgrader -ScriptsFolder $pathMasterScripts -Databases $DbUpdater_Databases -Variables $DbUpgrader_Variables -LogFilePath $LogDbUpgFilePath -AccessToken $accessToken -MaskedVariables $DbUpgrader_MaskedVariables

    $expPostgreSQLServer = $hashProject["expPostgreSQLServer"]
    if ($expPostgreSQLServer) {
      Write-VSOFTLog "Destroying PostgreSQL runtime databases"  
      
      $connectionSuperAdminToMaster = Get-ARCHDatabaseConnection -DatabaseProvider "PostgreSQL" -DatabaseServerInstance $expPostgreSQLServer -DatabaseName "postgres" -DatabaseUser $expPostgreSQLUser -DatabasePassword $expPostgreSQLPassword

      $DbUpdater_Databases = @{
			  "MASTER_RUNTIME_DESTROY" = $connectionSuperAdminToMaster;
		  }  
    
      $DbUpdater_Providers = @{
	      "MASTER_RUNTIME_DESTROY" = "PostgreSQL";
      }
      
  		Invoke-VSOFTDbUpgrader -InitializationMode -DbUpgraderFolder $pathDbUpgrader -ScriptsFolder $pathMasterScripts -Databases $DbUpdater_Databases -DatabaseProviders $DbUpdater_Providers -Variables $DbUpgrader_Variables -LogFilePath $LogDbUpgFilePath -AccessToken $accessToken -MaskedVariables $DbUpgrader_MaskedVariables
    }
	}
}


function Remove-ARCHProject(
  [Parameter(Mandatory = $true)] [string]$pathProjectFolder, 
  [Parameter(Mandatory = $false)] [string]$versionServerServerAdminLogin,
  [Parameter(Mandatory = $false)] [string]$versionServerServerAdminPassword,
	[Parameter(Mandatory = $false)] [switch]$leaveProjectFolder,
	[Parameter(Mandatory = $false)] [string]$expPostgreSQLUser,
	[Parameter(Mandatory = $false)] [string]$expPostgreSQLPassword) {

	$projectFilePath = Join-Path -Path $pathProjectFolder -ChildPath "project.json"

	if (Test-Path $projectFilePath) {	
		$hashProject = Import-ARCHProjectFile -path $projectFilePath

		$ProjectCodeName = $hashProject["ProjectCodeName"]
		$adminLogin = $hashProject["DatabaseAdminLogin"]
		$userLogin = $hashProject["DatabaseUserLogin"] 
		$pathArchBinariesFolder = $SetupLocation
		$versionServerServerInstance = $hashProject["ProjectVersionServerServerInstance"]
		$versionServerProvider = $hashProject["ProjectVersionServerProvider"]

		$versionServerDatabase = $hashProject["ProjectVersionServerDatabaseName"] 
		if ($versionServerProvider -eq "FileSystem") {
			$versionServerDatabase = ""
		}
		else {
			$connectionSuperAdminToMaster = Get-ARCHDatabaseConnection -DatabaseServerInstance $versionServerServerInstance -DatabaseName "master" -DatabaseUser $versionServerServerAdminLogin -DatabasePassword $versionServerServerAdminPassword

			$pathDbUpgrader = Join-Path -Path $pathArchBinariesFolder -ChildPath "Database\DbUpgrader"
			$pathScripts = Join-Path -Path $pathArchBinariesFolder -ChildPath "Database\Scripts"
			$pathMasterScripts = Join-Path -Path $pathArchBinariesFolder -ChildPath "Database\ScriptsOPERATIONS"


			$DbUpgrader_Variables = @{
				"VERSION_SERVER_DATABASE" = $versionServerDatabase;
				"DBADMIN_LOGIN" = $adminLogin;
				"DBUSER_LOGIN" = $userLogin;
			}
			$DbUpgrader_MaskedVariables = @("DBADMIN_PASSWORD", "DBUSER_PASSWORD", "ANYUSER_PASSWORD", "ANYUSER_OLDPASSWORD");

			#destroy database and logins
			Write-VSOFTLog "Destroying VersionServer database"
			$DbUpdater_Databases = @{
				"MASTER_PROJECT_DESTROY" = $connectionSuperAdminToMaster;
			}

			$accessToken = ""
			if (Is-VSOFTManagedIdentityAuthentication -DatabaseUser $versionServerServerAdminLogin) {
				$accessToken = "[azure-managed-identity]"
			}
       
			Invoke-VSOFTDbUpgrader -InitializationMode -DbUpgraderFolder $pathDbUpgrader -ScriptsFolder $pathMasterScripts -Databases $DbUpdater_Databases -Variables $DbUpgrader_Variables -LogFilePath $LogDbUpgFilePath -AccessToken $accessToken -MaskedVariables $DbUpgrader_MaskedVariables

      $expPostgreSQLServer = $hashProject["expPostgreSQLServer"]
      if ($expPostgreSQLServer) {
        Write-VSOFTLog "Destroying PostgreSQL version server database"  
      
        $connectionSuperAdminToMaster = Get-ARCHDatabaseConnection -DatabaseProvider "PostgreSQL" -DatabaseServerInstance $expPostgreSQLServer -DatabaseName "postgres" -DatabaseUser $expPostgreSQLUser -DatabasePassword $expPostgreSQLPassword

        $DbUpdater_Databases = @{
			    "MASTER_PROJECT_DESTROY" = $connectionSuperAdminToMaster;
		    }  
    
        $DbUpdater_Providers = @{
	        "MASTER_PROJECT_DESTROY" = "PostgreSQL";
        }
      
  		  Invoke-VSOFTDbUpgrader -InitializationMode -DbUpgraderFolder $pathDbUpgrader -ScriptsFolder $pathMasterScripts -Databases $DbUpdater_Databases -DatabaseProviders $DbUpdater_Providers -Variables $DbUpgrader_Variables -LogFilePath $LogDbUpgFilePath -AccessToken $accessToken -MaskedVariables $DbUpgrader_MaskedVariables
      }
		}
	}
	if (-not $leaveProjectFolder) {
		if (Test-Path -Path $pathProjectFolder) {
			Remove-ARCHItem -Path $pathProjectFolder -Force -Recurse
		}
	}
}

function Import-ARCHPackageSQLScriptsBackwardCompatibility(
  [Parameter(Mandatory = $true)] [string] $scriptsFolder, 
  [Parameter(Mandatory = $true)] [string] $databaseName) {

  $databaseSqlFolder = Join-Path -Path $scriptsFolder -ChildPath $databaseName

  if (Test-Path -Path $databaseSqlFolder) {
  
    $tmpSQLServerFolder = Join-Path -Path $databaseSqlFolder -ChildPath "SQLServer"
    $tmpPostgreSQLFolder = Join-Path -Path $databaseSqlFolder -ChildPath "PostgreSQL"

    if ( (Test-Path -Path $tmpSQLServerFolder) -or (Test-Path -Path $tmpPostgreSQLFolder) ) {
      #new format - do nothing
    } else {
      #old format - move scripts to subfolder 'SQLServer'
      New-Item -ItemType Directory -Path $tmpSQLServerFolder -Force | Out-Null
      Get-ChildItem -Path $databaseSqlFolder -Exclude "SQLServer" | Move-Item -Destination $tmpSQLServerFolder
    }
  }
}

function Import-ARCHPackage(
	[Parameter(Mandatory = $true)] [string] $PathProjectFolder,
	[Parameter(Mandatory = $false)] [string] $RuntimeFileName = "default.runtime.json",
	[Parameter(Mandatory = $true)] [string] $PackagePath,
	[Parameter(Mandatory = $false)] [switch] $Override,
	[Parameter(Mandatory = $false)] [string] $SecurityKey) {
    
	Write-VSOFTLog "Preparing to import package"

	if (-not ((Get-Item $PackagePath) -is [System.IO.DirectoryInfo])) {
		$tmpPackageFilename = Split-Path $PackagePath -Leaf
		if ( $tmpPackageFilename -notmatch "\.arch.*\.zip$" ) {
			Write-VSOFTLog "Application package file ($PackagePath) do not have valid extension (*.arch.zip)"  Error
		}
	}
	$projectFilePath = Join-Path -Path $PathProjectFolder -ChildPath "project.json"
	$hashProject = Import-ARCHProjectFile -path $projectFilePath

	$runtimeFilePath = Join-Path -Path $PathProjectFolder -ChildPath $RuntimeFileName
	$hashRuntime = Import-ARCHRuntimeFile -path $runtimeFilePath 

	Trace-ARCHProgressStartMinorStep -minorEndAt 0.05

	Test-ARCHCorrectProjectVersion -project $hashProject

	$tempPathFolder = [System.IO.Path]::GetTempFileName() | %{ rm $_; mkdir $_ }
	Write-VSOFTLog "Using temporary folder: $tempPathFolder"

	Trace-ARCHProgressStartMinorStep -minorEndAt 0.1
	$tempPathFolderPKG = Join-Path -Path $tempPathFolder -ChildPath "PKG"
	New-Item -ItemType Directory -Path $tempPathFolderPKG -Force | Out-Null

  $tmpProjectSQLFolder = Join-Path -Path $pathProjectFolder -ChildPath "SQL"
  if (Test-Path $tmpProjectSQLFolder) {
    #backward compatibility
    Import-ARCHPackageSQLScriptsBackwardCompatibility -scriptsFolder  $tmpProjectSQLFolder -databaseName "CONFIG"
    Import-ARCHPackageSQLScriptsBackwardCompatibility -scriptsFolder  $tmpProjectSQLFolder -databaseName "DATA"
    Import-ARCHPackageSQLScriptsBackwardCompatibility -scriptsFolder  $tmpProjectSQLFolder -databaseName "SCHEDULER"
    Import-ARCHPackageSQLScriptsBackwardCompatibility -scriptsFolder  $tmpProjectSQLFolder -databaseName "VERSION_SERVER"
    Import-ARCHPackageSQLScriptsBackwardCompatibility -scriptsFolder  $tmpProjectSQLFolder -databaseName "VIP"
  }
  
	if ((Get-Item $PackagePath) -is [System.IO.DirectoryInfo]) {
		Write-VSOFTLog "Copying package folder to temporary folder"
		Copy-VSOFTFiles -SourcePath $PackagePath -DestinationPath $tempPathFolderPKG -WithSubdirectories -PurgeDestination -NoSummary
	} else {
		Write-VSOFTLog "Extracting package to temporary folder"
		Expand-VSOFTArchive -Path $PackagePath -DestinationPath $tempPathFolderPKG
  }
	Trace-ARCHProgressStartMinorStep -minorEndAt 0.3
	Write-VSOFTLog "Validate before import: checking imported SQL scripts against project databases"

	$temporarySqlFolder = Join-Path -Path $tempPathFolderPKG -ChildPath "SQL"
	if ( -not (Test-Path -Path $temporarySqlFolder) ) {
		Write-VSOFTLog "Imported package does not contain any SQL script - no need to validate anything"
	} else {
    #backward compatibility
    Import-ARCHPackageSQLScriptsBackwardCompatibility -scriptsFolder  $temporarySqlFolder -databaseName "CONFIG"
    Import-ARCHPackageSQLScriptsBackwardCompatibility -scriptsFolder  $temporarySqlFolder -databaseName "DATA"
    Import-ARCHPackageSQLScriptsBackwardCompatibility -scriptsFolder  $temporarySqlFolder -databaseName "SCHEDULER"
    Import-ARCHPackageSQLScriptsBackwardCompatibility -scriptsFolder  $temporarySqlFolder -databaseName "VERSION_SERVER"
    Import-ARCHPackageSQLScriptsBackwardCompatibility -scriptsFolder  $temporarySqlFolder -databaseName "VIP"

    $expPostgreSQLServer = $hashProject["expPostgreSQLServer"] 
    $expPostgreSQLDatabases = $hashProject["expPostgreSQLDatabases"] 
    if (-not $expPostgreSQLDatabases)
    { 
      $expPostgreSQLDatabases = @{} 
    }

    $dbProviderDATA = "SQLServer"
    if ($expPostgreSQLDatabases.Contains("DATA")) {
      $dbProviderDATA = "PostgreSQL"
    }
    $dbProviderCONFIG = "SQLServer"
    if ($expPostgreSQLDatabases.Contains("CONFIG")) {
      $dbProviderCONFIG = "PostgreSQL"
    }
    $dbProviderSCHEDULER = "SQLServer"
    if ($expPostgreSQLDatabases.Contains("SCHEDULER")) {
      $dbProviderSCHEDULER = "PostgreSQL"
    }
    $dbProviderVIP = "SQLServer"
    if ($expPostgreSQLDatabases.Contains("VIP")) {
      $dbProviderVIP = "PostgreSQL"
    }

		$DatabasePassword = $([VSoft.Framework.Environment.Configuration.SecurityOperation]::Decrypt($hashProject["DatabaseUserPassword"], $SecurityKey));
		$tmpDbDATA = Get-ARCHDatabaseConnection -DatabaseServerInstance $hashRuntime["DatabaseServerInstance"] -DatabaseName $hashRuntime["DatabaseNameDATA"] -DatabaseUser $hashProject["DatabaseUserLogin"] -DatabasePassword $DatabasePassword
    if ($dbProviderDATA -eq "PostgreSQL") {
      $tmpDbDATA = Get-ARCHDatabaseConnection -DatabaseServerInstance $expPostgreSQLServer -DatabaseProvider "PostgreSQL" -DatabaseName $hashRuntime["DatabaseNameDATA"] -DatabaseUser $hashProject["DatabaseUserLogin"] -DatabasePassword $DatabasePassword
    }

		$tmpDbCONFIG = Get-ARCHDatabaseConnection -DatabaseServerInstance $hashRuntime["DatabaseServerInstance"] -DatabaseName $hashRuntime["DatabaseNameCONFIG"] -DatabaseUser $hashProject["DatabaseUserLogin"] -DatabasePassword $DatabasePassword
    if ($dbProviderCONFIG -eq "PostgreSQL") {
      $tmpDbCONFIG = Get-ARCHDatabaseConnection -DatabaseServerInstance $expPostgreSQLServer -DatabaseProvider "PostgreSQL" -DatabaseName $hashRuntime["DatabaseNameCONFIG"] -DatabaseUser $hashProject["DatabaseUserLogin"] -DatabasePassword $DatabasePassword
    }

		$tmpDbSCHEDULER = Get-ARCHDatabaseConnection -DatabaseServerInstance $hashRuntime["DatabaseServerInstance"] -DatabaseName $hashRuntime["DatabaseNameSCHEDULER"] -DatabaseUser $hashProject["DatabaseUserLogin"] -DatabasePassword $DatabasePassword
    if ($dbProviderSCHEDULER -eq "PostgreSQL") {
      $tmpDbSCHEDULER = Get-ARCHDatabaseConnection -DatabaseServerInstance $expPostgreSQLServer -DatabaseProvider "PostgreSQL" -DatabaseName $hashRuntime["DatabaseNameSCHEDULER"] -DatabaseUser $hashProject["DatabaseUserLogin"] -DatabasePassword $DatabasePassword
    }
		$tmpDbVIP = Get-ARCHDatabaseConnection -DatabaseServerInstance $hashRuntime["DatabaseServerInstance"] -DatabaseName $hashRuntime["DatabaseNameVIP"] -DatabaseUser $hashProject["DatabaseUserLogin"] -DatabasePassword $DatabasePassword
    if ($dbProviderVIP -eq "PostgreSQL") {
      $tmpDbVIP = Get-ARCHDatabaseConnection -DatabaseServerInstance $expPostgreSQLServer -DatabaseProvider "PostgreSQL" -DatabaseName $hashRuntime["DatabaseNameVIP"] -DatabaseUser $hashProject["DatabaseUserLogin"] -DatabasePassword $DatabasePassword
    }
		$DbUpdater_Databases = @{
			"CONFIG" = $tmpDbCONFIG;
			"DATA" = $tmpDbDATA;
			"SCHEDULER" = $tmpDbSCHEDULER;
			"VIP" = $tmpDbVIP;
		}
    $DbUpdater_Providers = @{
	    "CONFIG" = $dbProviderCONFIG;
	    "DATA" = $dbProviderDATA;
	    "SCHEDULER" = $dbProviderSCHEDULER;
      "VIP" = $dbProviderVIP;
    }
		Write-VSOFTLog "Validating SQL scripts from imported package"

		$temporarySqlFolderForCompare = Join-Path -Path $tempPathFolderPKG -ChildPath "SQL_COMPARE"
		Copy-VSOFTFiles -SourcePath $temporarySqlFolder -DestinationPath $temporarySqlFolderForCompare -WithSubdirectories -NoSummary
		Copy-VSOFTFiles -SourcePath "Database\Scripts\CONFIG" -DestinationPath "$temporarySqlFolderForCompare\CONFIG" -WithSubdirectories -NoSummary
		Copy-VSOFTFiles -SourcePath "Database\Scripts\DATA" -DestinationPath "$temporarySqlFolderForCompare\DATA" -WithSubdirectories -NoSummary
		Copy-VSOFTFiles -SourcePath "Database\Scripts\SCHEDULER" -DestinationPath "$temporarySqlFolderForCompare\SCHEDULER" -WithSubdirectories -NoSummary
		Copy-VSOFTFiles -SourcePath "Database\Scripts\VIP" -DestinationPath "$temporarySqlFolderForCompare\VIP" -WithSubdirectories -NoSummary

		Invoke-ARCHLocalSqlScriptsPatcher -LocalSqlScriptsPatcherFolder "Database\LocalSqlScriptsPatcher" -ScriptsFolder $temporarySqlFolderForCompare -Databases $DbUpdater_Databases -DatabaseProviders $DbUpdater_Providers -WhatIf

		Write-VSOFTLog "Validation of SQL scripts from imported package completed sucesfully"
	}

    Trace-ARCHProgressStartMinorStep -minorEndAt 0.5
	Write-VSOFTLog "Validation passed. Importing package"

	Write-VSOFTLog "Copying SQL Scripts"
	if ($Override) {
		Write-VSOFTLog "Override mode: remove any previous environment-specyfic SQL scripts"
		Remove-ARCHItem (Join-Path -Path $pathProjectFolder -ChildPath "SQL\*") -Recurse -Force
		Write-VSOFTLog "Removing any previous environment-specyfic SQL scripts completed sucesfully"
	}
	if (Test-Path -Path (Join-Path -Path $tempPathFolderPKG -ChildPath "SQL") ) {
		Write-VSOFTLog "Copying environment-specyfic SQL Scripts"
		Copy-VSOFTFiles -SourcePath (Join-Path -Path $tempPathFolderPKG -ChildPath "SQL") -DestinationPath (Join-Path -Path $pathProjectFolder -ChildPath "SQL") -WithSubdirectories -NoSummary
		Write-VSOFTLog "Copying environment-specyfic SQL Scripts completed succesfully"
	}

    Trace-ARCHProgressStartMinorStep -minorEndAt 0.6
	Write-VSOFTLog "Copying Files"
	if ($Override) {
		Write-VSOFTLog "Override mode: remove any previous environment-specyfic files"
		Remove-ARCHItem (Join-Path -Path $pathProjectFolder -ChildPath "Files\*") -Recurse -Force
		Write-VSOFTLog "Removing any previous environment-specyfic files completed sucesfully"
	}
	if (Test-Path -Path (Join-Path -Path $tempPathFolderPKG -ChildPath "Files") ) {
		Write-VSOFTLog "Copying environment-specyfic files"
		Copy-VSOFTFiles -SourcePath (Join-Path -Path $tempPathFolderPKG -ChildPath "Files") -DestinationPath (Join-Path -Path $pathProjectFolder -ChildPath "Files") -WithSubdirectories -NoSummary
		Write-VSOFTLog "Copying environment-specyfic files completed succesfully"
	}

	Trace-ARCHProgressStartMinorStep -minorEndAt 0.7
	Write-VSOFTLog "Importing Version Server archives"

	Write-VSOFTLog "Creating temporary Version Server in folder"
	$tempPathFolderVS = Join-Path -Path $tempPathFolder -ChildPath "VS"
	New-Item -ItemType Directory -Path $tempPathFolderVS -Force | Out-Null

	if ($Override) {
		Write-VSOFTLog "Cleaning project Version Server"
		if ($hashProject["ProjectVersionServerProvider"] -eq "FileSystem") {
			Remove-ARCHItem -Path (Join-Path -Path $pathProjectFolder -ChildPath "VS\*") -Recurse -Force
		} else {
	        #this command requires admin account to perform DBCC CHECKIDENT (resed id seed)
			$DatabasePassword = [VSoft.Framework.Environment.Configuration.SecurityOperation]::Decrypt($hashProject["DatabaseAdminPassword"], $SecurityKey)
			$versionServerConnection = Get-ARCHDatabaseConnection -DatabaseServerInstance $hashProject["ProjectVersionServerServerInstance"] -DatabaseName $hashProject["ProjectVersionServerDatabaseName"] -DatabaseUser $hashProject["DatabaseAdminLogin"] -DatabasePassword $DatabasePassword
			Clean-VSOFTVersionServer -VersionServerConsoleFolder "Database\VSoft.VersionServer.Console" -Provider $hashProject["ProjectVersionServerProvider"] -Connection $versionServerConnection
		}
		Write-VSOFTLog "Copying default Version Server files content (from image) to temporary Version Server"
		Expand-VSOFTArchive -Path "Database\ScriptsVS\INITIAL\*.zip" -DestinationPath $tempPathFolderVS
	} else {
		Write-VSOFTLog "Copying project's Version Server content to temporary Version Server"
		if ($hashProject["ProjectVersionServerProvider"] -eq "FileSystem") {
			Expand-VSOFTArchive -Path (Join-Path -Path $pathProjectFolder -ChildPath "VS\*.zip") -DestinationPath $tempPathFolderVS
		} else {
			$tempPathArchiveOriginalVS = Join-Path -Path $tempPathFolder -ChildPath "vs_original.zip"
			$DatabasePassword = $([VSoft.Framework.Environment.Configuration.SecurityOperation]::Decrypt($hashProject["DatabaseUserPassword"], $SecurityKey))
			$versionServerConnection = Get-ARCHDatabaseConnection -DatabaseServerInstance $hashProject["ProjectVersionServerServerInstance"] -DatabaseName $hashProject["ProjectVersionServerDatabaseName"] -DatabaseUser $hashProject["DatabaseUserLogin"] -DatabasePassword $DatabasePassword
			Export-VSOFTVersionServer -VersionServerConsoleFolder "Database\VSoft.VersionServer.Console" -Provider $hashProject["ProjectVersionServerProvider"] -Connection $versionServerConnection -Archive $tempPathArchiveOriginalVS
			Expand-VSOFTArchive -Path $tempPathArchiveOriginalVS -DestinationPath $tempPathFolderVS
		}
	}

	Trace-ARCHProgressStartMinorStep -minorEndAt 1.0
	#ToDo: change into importing folders not only zip's when it will be possible in Version.Server.Console
	Add-Type -Assembly System.IO.Compression.FileSystem
	foreach ($directory in [System.IO.Directory]::GetDirectories( (Join-Path -Path $tempPathFolderPKG -ChildPath "VS")  )) { 
		Write-VSOFTLog "Compressing $directory into $directory`.zip"
		[System.IO.Compression.ZipFile]::CreateFromDirectory($directory, "$directory`.zip")
	}

	#import files in alfabetical order (Sort-Object default sorts in alfabetical order by Name)!
	Write-VSOFTLog "Importing Version Server archives from package to temporary Version Server"
	Get-ChildItem (Join-Path -Path $tempPathFolderPKG -ChildPath "VS") -Filter *.zip | Sort-Object | Foreach-Object {
		Import-VSOFTVersionServer -VersionServerConsoleFolder "Database\VSoft.VersionServer.Console" -Provider "FileSystem" -Connection $tempPathFolderVS -Archive ($_.FullName)
	}

	Write-VSOFTLog "Run Version Server upgrade scripts on imported package"
	Invoke-ARCHVersionServerRunUpgradeScripts -paramVersionServerProvider "FileSystem" -paramVersionServerCS $tempPathFolderVS

	Write-VSOFTLog "Exporting temporary Version Server content to temporary archive"
	$tempPathArchiveToImportVS = (Join-Path -Path $tempPathFolder -ChildPath "vs_to_import.zip")
	Export-VSOFTVersionServer -VersionServerConsoleFolder "Database\VSoft.VersionServer.Console" -Provider "FileSystem" -Connection $tempPathFolderVS -Archive $tempPathArchiveToImportVS

	Write-VSOFTLog "Importing prepared temporary archive to project's Version Server"
	if ($hashProject["ProjectVersionServerProvider"] -eq "FileSystem") {
		Remove-ARCHItem -Path (Join-Path -Path $pathProjectFolder -ChildPath "VS\*") -Recurse -Force
		Copy-Item -Path $tempPathArchiveToImportVS -Destination (Join-Path -Path $pathProjectFolder -ChildPath "VS\vs.zip")
	} else {
		#ToDo: remove data from database VersionServer
		$DatabasePassword = $([VSoft.Framework.Environment.Configuration.SecurityOperation]::Decrypt($hashProject["DatabaseUserPassword"], $SecurityKey))
		$versionServerConnection = Get-ARCHDatabaseConnection -DatabaseServerInstance $hashProject["ProjectVersionServerServerInstance"] -DatabaseName $hashProject["ProjectVersionServerDatabaseName"] -DatabaseUser $hashProject["DatabaseUserLogin"] -DatabasePassword $DatabasePassword
		Import-VSOFTVersionServer -VersionServerConsoleFolder "Database\VSoft.VersionServer.Console" -Provider $hashProject["ProjectVersionServerProvider"] -Connection $versionServerConnection -Archive $tempPathArchiveToImportVS
	}
	Write-VSOFTLog "Importing Version Server archives completed succesfully"

	Write-VSOFTLog "Removing temporary folder $tempPathFolder"
	Remove-ARCHItem -Path $tempPathFolder -Recurse -Force

	Trace-ARCHProgressStartMinorStep -minorEndAt 1
	Write-VSOFTLog "Import package procedure completed succesfully"
}

function Export-ARCHPackage(
  [Parameter(Mandatory = $true)] [string]$PathProjectFolder,
	[Parameter(Mandatory = $false)] [string]$RuntimeFileName = "default.runtime.json",
	[Parameter(Mandatory = $true)] [string]$PackagePath,
	[Parameter(Mandatory = $true)] [string]$UserVersionNumber,
	[Parameter(Mandatory = $false)] [switch]$OptExcludeSystemFolder,
	[Parameter(Mandatory = $false)] [switch]$OptOptimizeUserSQLAutoScripts,
	[Parameter(Mandatory = $false)] [string]$SecurityKey) {
	
	Write-VSOFTLog "Exporting package"

	$projectFilePath = Join-Path -Path $pathProjectFolder -ChildPath "project.json"
	$runtimeFilePath = Join-Path -Path $pathProjectFolder -ChildPath $runtimeFileName
	$hashProject = Import-ARCHProjectFile -path $projectFilePath
	$hashRuntime = Import-ARCHRuntimeFile -path $runtimeFilePath 

  Trace-ARCHProgressStartMinorStep -minorEndAt 0.05

	$tempPathFolder = [System.IO.Path]::GetTempFileName() | %{ rm $_; mkdir $_ }
	Write-VSOFTLog "Using temporary folder: $tempPathFolder"
	
	$tempPathFolderPKG = Join-Path -Path $tempPathFolder -ChildPath "PKG"
	New-Item -ItemType Directory -Path $tempPathFolderPKG -Force | Out-Null

	Write-VSOFTLog "Copying archItekt version.json file into package"
	$tmpRuntimeVersionPath = Join-Path -Path $hashRuntime["RuntimeFolder"] -ChildPath "version.json"
	Copy-Item -Path $tmpRuntimeVersionPath -Destination $tempPathFolderPKG

  Trace-ARCHProgressStartMinorStep -minorEndAt 0.1
	Write-VSOFTLog "Copying project files"
	$sourcePathFiles = Join-Path -Path $PathProjectFolder -ChildPath "Files"
	$destinationPathFiles = Join-Path -Path $tempPathFolderPKG -ChildPath "Files"
	New-Item -Path $destinationPathFiles -ItemType Directory -Force  | Out-Null
  Copy-VSOFTFiles -SourcePath $sourcePathFiles -DestinationPath $destinationPathFiles -WithSubdirectories -PurgeDestination -NoSummary
	

  Trace-ARCHProgressStartMinorStep -minorEndAt 0.2
	Write-VSOFTLog "Copying database scripts"

	$sourcePathSQL = Join-Path -Path $PathProjectFolder -ChildPath "SQL"
	$destinationPathSQL = Join-Path -Path $tempPathFolderPKG -ChildPath "SQL"
	New-Item -Path $destinationPathSQL -ItemType Directory -Force  | Out-Null

  #backward compatibility
  Import-ARCHPackageSQLScriptsBackwardCompatibility -scriptsFolder $sourcePathSQL -databaseName "CONFIG"
  Import-ARCHPackageSQLScriptsBackwardCompatibility -scriptsFolder $sourcePathSQL -databaseName "DATA"
  Import-ARCHPackageSQLScriptsBackwardCompatibility -scriptsFolder $sourcePathSQL -databaseName "SCHEDULER"
  Import-ARCHPackageSQLScriptsBackwardCompatibility -scriptsFolder $sourcePathSQL -databaseName "VERSION_SERVER"
  Import-ARCHPackageSQLScriptsBackwardCompatibility -scriptsFolder $sourcePathSQL -databaseName "VIP"

	#if there (in project's folder) are only automatically generated scripts (for EDMX i DICT)
	#then we should not copy old versions to exported package; generated scripts should be enough
	#it prevents eg. adding extra fields which were deleted between versions
	#Case 280754: Paczka instalacyjna - blad skryptow

  if (Get-ChildItem -Path $sourcePathSQL -File -Recurse | Where-Object {$_.Directory -notlike "*`$auto_gen"}) 
  {
		Write-VSOFTLog "Found user scrips in SQL subfolder. Copying them to exported package"
		Copy-VSOFTFiles -SourcePath $sourcePathSQL -DestinationPath $destinationPathSQL -WithSubdirectories -PurgeDestination -NoSummary
	}
	else
	{
		Write-VSOFTLog "There is no user scripts in SQL subfolder. Ommiting copying previously automatically generated scripts"
	}

  Trace-ARCHProgressStartMinorStep -minorEndAt 0.3
	Write-VSOFTLog "Creating temporary Version Server in folder"
	$tempPathFolderVS = Join-Path -Path $tempPathFolder -ChildPath "VS"
	New-Item -ItemType Directory -Path $tempPathFolderVS -Force | Out-Null

  Trace-ARCHProgressStartMinorStep -minorEndAt 0.4
	Write-VSOFTLog "Copying project's Version Server content to temporary Version Server"
	if ($hashProject["ProjectVersionServerProvider"] -eq "FileSystem") {
		#expand from this runtime, nto from project
		Copy-VSOFTFiles -SourcePath (Join-Path -Path $hashRuntime["RuntimeFolder"] -ChildPath "VersionServer") -DestinationPath $tempPathFolderVS -WithSubdirectories -NoSummary
		#Expand-VSOFTArchive -Path (Join-Path -Path $pathProjectFolder -ChildPath "VS\*.zip") -DestinationPath $tempPathFolderVS
	} else {
		$tempPathArchiveOriginalVS = Join-Path -Path $tempPathFolder -ChildPath "vs_original.zip"
		$DatabasePassword = [VSoft.Framework.Environment.Configuration.SecurityOperation]::Decrypt($hashProject["DatabaseUserPassword"], $SecurityKey)
		$versionServerConnection = Get-ARCHDatabaseConnection -DatabaseServerInstance $hashProject["ProjectVersionServerServerInstance"] -DatabaseName $hashProject["ProjectVersionServerDatabaseName"] -DatabaseUser $hashProject["DatabaseUserLogin"] -DatabasePassword $DatabasePassword
		Export-VSOFTVersionServer -VersionServerConsoleFolder "Database\VSoft.VersionServer.Console" -Provider $hashProject["ProjectVersionServerProvider"] -Connection $versionServerConnection -Archive $tempPathArchiveOriginalVS
		Expand-VSOFTArchive -Path $tempPathArchiveOriginalVS -DestinationPath $tempPathFolderVS
	}
	if ($OptExcludeSystemFolder) {
		Write-VSOFTLog "Removing System folder from exported Version Server archive"
		$tempPathFolderVS_System = Join-Path -Path $tempPathFolderVS -ChildPath "System"
		if (Test-Path $tempPathFolderVS_System) {
			Remove-ARCHItem -Path $tempPathFolderVS_System -Recurse -Force
		}
	}
		
  Trace-ARCHProgressStartMinorStep -minorEndAt 0.5
	Write-VSOFTLog "Exporting temporary Version Server content to exported archive"
	$destinationPathVS = Join-Path -Path $tempPathFolderPKG -ChildPath "VS"
	New-Item -Path $destinationPathVS -ItemType Directory -Force
	$destinationPathVS_VSZIP = Join-Path -Path $destinationPathVS -ChildPath "vs.zip"
	
	Export-VSOFTVersionServer -VersionServerConsoleFolder "Database\VSoft.VersionServer.Console" -Provider "FileSystem" -Connection $tempPathFolderVS -Archive $destinationPathVS_VSZIP

  Trace-ARCHProgressStartMinorStep -minorEndAt 0.6
	Write-VSOFTLog "Creating automatically generated database scripts"
	$tmpVersion = [version]$hashProject["ArchITektVersion"]
	$tmpScriptsVersion = $tmpVersion.ToString(2) #generates: Major.Minor

	$createdSqlScriptsFolder = "$tmpScriptsVersion`@$UserVersionNumber`$auto_gen"
	$destinationPathSQL_DATA = Join-Path -Path $destinationPathSQL -ChildPath "DATA\SQLServer"
	
	New-Item -Path $destinationPathSQL_DATA -ItemType Directory -Force | Out-Null
	$destinationPathSQL_DATA_Scripts = Join-Path -Path $destinationPathSQL_DATA -ChildPath $createdSqlScriptsFolder
	New-Item -Path $destinationPathSQL_DATA_Scripts -ItemType Directory -Force  | Out-Null

	$archITektExePath = Join-Path -Path $hashRuntime["RuntimeFolder"] -ChildPath "APP\archITekt\archITekt.exe"
	$archITektExeArgumentsEdmx = "-console -disableMessages -GenerateSQLScriptForDomainCommand:""$destinationPathSQL_DATA_Scripts\100_EDMX.sql"""
	$archITektExeArgumentsDictionaries = "-console -disableMessages -GenerateSQLScriptForDictionariesCommand:""$destinationPathSQL_DATA_Scripts\200_DICT.sql"""

  Trace-ARCHProgressStartMinorStep -minorEndAt 0.7
	Write-VSOFTLog "Automatically generating SQL scripts for data structures"
	Start-Process $archITektExePath -argumentlist $archITektExeArgumentsEdmx -wait

  Trace-ARCHProgressStartMinorStep -minorEndAt 0.8
	Write-VSOFTLog "Automatically generating SQL scripts for dictionaries"
	Start-Process $archITektExePath -argumentlist $archITektExeArgumentsDictionaries -wait

	if ($OptOptimizeUserSQLAutoScripts) {
		Write-VSOFTLog "Optimizing automatically generated SQL scripts"

		$ToNatural = { [regex]::Replace($_, '\d+', { $args[0].Value.PadLeft(20, '0') }) }
		
		#force treat folders as array (case 267496)
		$folders = @( Get-ChildItem -Path $destinationPathSQL_DATA | Sort-Object $ToNatural -Descending )
		if ( ($folders.Count -gt 0) -and ($folders[0].Name -eq $createdSqlScriptsFolder) ) {
			for ($i = 1; ($i -lt $folders.Count) -and ($folders[$i].Name.EndsWith("`$auto_gen")) ; $i++) {
				#remove previously automatically generated script folders - but only if there wasn't any user scripts folder between them!
				$currentFolderName = $folders[$i].Name
				$currentFolderFullPath = $folders[$i].FullName

				Write-VSOFTLog "Removing unnecessary automatically generated SQL Scripts folder $currentFolderName"
				Remove-ARCHItem -Path $currentFolderFullPath -Recurse -Force 
			}
		}
	}

  Trace-ARCHProgressStartMinorStep -minorEndAt 0.9
	Write-VSOFTLog "Compressing package"
	if (Test-Path $packagePath) {
		Remove-ARCHItem -Path $packagePath -Force
	}
	Add-Type -Assembly System.IO.Compression.FileSystem
	[System.IO.Compression.ZipFile]::CreateFromDirectory("$tempPathFolderPKG", "$packagePath")
	#Compress-Archive -Path "$tempPathFolderPKG\*" -CompressionLevel Optimal -DestinationPath $packagePath -Force

  Trace-ARCHProgressStartMinorStep -minorEndAt 1
	Write-VSOFTLog "Export package procedure completed succesfully"
}

function Invoke-ARCHLocalSqlScriptsPatcher([Parameter(Mandatory=$true)] [String] $LocalSqlScriptsPatcherFolder,
										   [Parameter(Mandatory=$true)] [String] $ScriptsFolder,
                       [Parameter(Mandatory=$true)] [Hashtable] $Databases,
                       [Parameter(Mandatory=$false)] [Hashtable] $DatabaseProviders = @{},
										   [switch] $WhatIf)
{
  $SqlScriptsPatcherProgram = Join-Path $LocalSqlScriptsPatcherFolder "LocalSqlScriptsPatcher.exe"
  $SqlScriptsPatcherParams = @()
  $SqlScriptsPatcherParams += "-s" , "$ScriptsFolder"

  foreach ($database in $databases.GetEnumerator()) 
  {
    $SqlScriptsPatcherParams += "-d", "$($database.Name):$($database.Value)"
  }
  foreach ($databaseProvider in $DatabaseProviders.GetEnumerator()) 
  {
    $SqlScriptsPatcherParams += "-p", "$($databaseProvider.Name):$($databaseProvider.Value)"
  }
  if ($WhatIf) 
  {
    $SqlScriptsPatcherParams += "-w"
  }

  & "$SqlScriptsPatcherProgram" $SqlScriptsPatcherParams | Write-VSOFTLog

  if ($lastexitcode -ne 0)
  {
	  if ($WhatIf) {
		  Write-VSOFTLog "Error occured while verification before patching sql scripts. Please fix the errors manually and run upgrade again to complete the operation." Error
	  } else {
		  Write-VSOFTLog "Error occured while patching sql scripts. Please fix the errors manually and run upgrade again to complete the operation." Error
	  }
  }
  else
  {
	  if ($WhatIf) {
		Write-VSOFTLog "Sql scripts verification before patching process completed sucesfully" 
	  } else {
		Write-VSOFTLog "Sql scripts patching process completed sucesfully" 
	  }
  }
}

function Invoke-ARCHLocalXmlMerger([Parameter(Mandatory=$true)] [String] $LocalXmlMergerFolder,
							       [Parameter(Mandatory=$true)] [String] $MergeFolder){
    $LocalXmlMergerProgram = Join-Path $LocalXmlMergerFolder "LocalXmlMerger.exe"
  
	& "$LocalXmlMergerProgram" "$MergeFolder" /cleanup  | Write-VSOFTLog
	if ($lastexitcode -ne 0) {
		Write-VSOFTLog "Error occured while merging config files. Please fix the errors manually and run upgrade again to complete the operation." Error
	} else {
		Write-VSOFTLog "Merge config files operation completed sucesfully" 
	}
}

function CreateFileIfNotExist ([Parameter(Mandatory = $true)] [string]$Path, [string]$FileName, [string]$Content) {
    if (-not (Test-Path -Path (Join-Path $Path $FileName) )) {
        New-Item -path "$Path" -name $FileName -type "file" -value $Content -Force
    }
}

function Invoke-ARCHVersionServerRunUpgradeScripts($paramVersionServerProvider, $paramVersionServerCS) {
	$tmpAnyChanged = $false
   $tmpTempVSFolder = [System.IO.Path]::GetTempFileName() | %{ rm $_; mkdir $_ }
	Write-VSOFTLog "Executing Version Server upgrade procedure using temporary folder $tmpTempVSFolder"

	Write-VSOFTLog "Exporting Version Server into temporary archive"
	$tmpTempVSZipFile = Join-Path -Path $tmpTempVSFolder -ChildPath "vs.zip"
    
	Export-VSOFTVersionServer -VersionServerConsoleFolder ".\Database\VSoft.VersionServer.Console" -Provider $paramVersionServerProvider -Connection $paramVersionServerCS -Archive $tmpTempVSZipFile

	Write-VSOFTLog "Extracting Version Server temporary  archive into temporary folder"
	$tmpTempVSTempFolder = Join-Path -Path $tmpTempVSFolder -ChildPath "vs"
	#Expand-VSOFTArchive -Path "$tmpTempVSZipFile" -DestinationPath $tmpTempVSTempFolder
	mkdir "$tmpTempVSTempFolder\System\Update" -force

	$tmpZip = $null
	Add-Type -AssemblyName System.IO.Compression.FileSystem
   try {
		$tmpZip = [System.IO.Compression.ZipFile]::OpenRead($tmpTempVSZipFile)
		$tmpZip.Entries | Where-Object { $_.FullName -like "System/Update/*" } | ForEach-Object {  if ($_.Name -ne "") { [System.IO.Compression.ZipFileExtensions]::ExtractToFile($_, "$tmpTempVSTempFolder\System\Update\$($_.Name)", $true) } }
   } finally {
		if ($null -ne $tmpZip -and $tmpZip -is [System.IDisposable]) { $tmpZip.Dispose() }
   }

   CreateFileIfNotExist -Path "$tmpTempVSTempFolder\System\Update" -FileName "versionUpdatedTo.txt" -Content ""
   CreateFileIfNotExist -Path "$tmpTempVSTempFolder\System\Update" -FileName "versionUpdatedTo.txt.7ccaeb96eae64354ac1fa55383a672eb.vvs" -Content "{""Technical"":true}"
   CreateFileIfNotExist -Path "$tmpTempVSTempFolder\System\Update" -FileName "versionUpdatedLog.txt" -Content ""
   CreateFileIfNotExist -Path "$tmpTempVSTempFolder\System\Update" -FileName "versionUpdatedLog.txt.05e74aa8d18540d185ebf1a23e1262fe.vvs" -Content "{""Technical"":true}"

   $tmpVersionVS = Get-Content "$tmpTempVSTempFolder\System\Update\versionUpdatedTo.txt" -First 1
   if ($tmpVersionVS -eq $null) {
		$tmpVersionVS = ""
   }
	$tmpVersionVS = $tmpVersionVS.Trim()

	$tmpScriptsVS = Get-ChildItem ".\Database\ScriptsVS\CHANGE" -Name | Sort-Object
	foreach ($tmpScript in $tmpScriptsVS) {
		if ($tmpScript -gt $tmpVersionVS) {
			if ($tmpScript -like "*.cs") {
				Write-VSOFTLog "Upgrading Version Server with task $tmpScript"
				.\Database\VSoft.VersionServer.Console\VSoft.VersionServer.Console.exe executeTask -p $paramVersionServerProvider -s $paramVersionServerCS -t ".\Database\ScriptsVS\CHANGE\$tmpScript" | Write-VSOFTLog
				if ($lastexitcode -ne 0) {
					Write-VSOFTLog "Error occured while executing task with VSoft.VersionServer.Console.exe." Error
				}
			} elseif ($tmpScript -like "*.zip") {
				Write-VSOFTLog "Upgrading Version Server - importing $tmpScript"
				.\Database\VSoft.VersionServer.Console\VSoft.VersionServer.Console.exe import -p $paramVersionServerProvider -s $paramVersionServerCS -f ".\Database\ScriptsVS\CHANGE\$tmpScript" | Write-VSOFTLog
				if ($lastexitcode -ne 0) {
					Write-VSOFTLog "Error occured while performing import with VSoft.VersionServer.Console.exe." Error
				}
			} else {
				Write-VSOFTLog "Unknown type of version server script file: Database\ScriptsVS\CHANGE\$tmpScript" Error
			}
			$date = Get-Date -format "yyyy-MM-dd HH:mm:ss"
			Add-Content -Path "$tmpTempVSTempFolder\System\Update\versionUpdatedLog.txt" -Value "$date $tmpScript"
			New-Item -path "$tmpTempVSTempFolder\System\Update" -name "versionUpdatedTo.txt" -type "file" -value $tmpScript -Force
			if (Test-Path -Path "$tmpTempVSFolder\upgraded.zip") {
				Remove-ARCHItem -Path "$tmpTempVSFolder\upgraded.zip" -Force
			}
         $tmpAnyChanged = $true
		}
	}
	if ($tmpAnyChanged) {
		Write-VSOFTLog "Saving information in Version Server"
		[System.IO.Compression.ZipFile]::CreateFromDirectory("$tmpTempVSTempFolder", "$tmpTempVSFolder\upgraded.zip")
		#Compress-Archive -Path "$tmpTempVSTempFolder\*" -DestinationPath "$tmpTempVSFolder\upgraded.zip"
		Import-VSOFTVersionServer -VersionServerConsoleFolder ".\Database\VSoft.VersionServer.Console" -Provider $paramVersionServerProvider -Connection $paramVersionServerCS -Archive "$tmpTempVSFolder\upgraded.zip"
	}

	Write-VSOFTLog "Removing temporary VS folder '$tmpTempVSFolder'"
   Remove-ARCHItem -Path $tmpTempVSFolder -Force -Recurse 
   $tmpAnyChanged
}

function Get-ARCHWindowsTimeZone([Parameter(Mandatory = $true)] [string] $paramIanaTimeZone) {
	Add-Type -Path "InstallTools\TimeZoneConverter.dll"
	#$tempWindowsTimeZone = $null
	#$tempResult =  [TimeZoneConverter.TZConvert]::IanaToWindows($paramIanaTimeZone, [ref] $tempWindowsTimeZone)
	[TimeZoneConverter.TZConvert]::IanaToWindows($paramIanaTimeZone)
}


function Open-ARCHPSSession(
  [Parameter(Mandatory = $true)][string[]] $ComputerName,
  [Parameter(Mandatory = $false)][PSCredential] $Credential = [System.Management.Automation.PSCredential]::Empty) {

  $tempPSSession = $null 
  try
  {
    $tempPSSession = New-PSSession -ComputerName $ComputerName -Credential $Credential
  }
  catch
  {
    Start-Sleep -Seconds 1
    try
    {
      $tempPSSession = New-PSSession -ComputerName $ComputerName -Credential $Credential
    }
    catch
    {
      Start-Sleep -Seconds 2
      $tempPSSession = New-PSSession -ComputerName $ComputerName -Credential $Credential
    }
  }
  $tempPSSession
}

function Close-ARCHPSSession([Parameter(Mandatory = $true)][System.Management.Automation.Runspaces.PSSession] $Session) {
  if ($Session -ne $null) {
    if ($Session.State -eq "Closed") {
      Remove-PSSession $Session;
      $false;
    } else {
      Remove-PSSession $Session;
      $true;
    }
  } else {
    $false;
  }
}



function Invoke-ARCHCommandSmart(
	[Parameter(Mandatory = $true)] [ScriptBlock]$ScriptBlock,
	[Parameter(Mandatory = $false)] [object[]]$ArgumentList,
	[Parameter(Mandatory = $false)] [pscredential]$Credential = [System.Management.Automation.PSCredential]::Empty,
	[Parameter(Mandatory = $false)] [string]$ComputerName,
	[Parameter(Mandatory = $false)] [System.Management.Automation.Runspaces.PSSession]$Session)
{
	if ($Session -ne $null)
	{
		#execute command via PSRemoting using existing PSSession
		Invoke-Command -ScriptBlock $ScriptBlock -ArgumentList $ArgumentList -Session $Session
	} 
	elseif ( Get-ARCHIsLocalServer -ComputerName $ComputerName )
	{
		#execute command local:
		#* only this option do not require Enable-PsRemoting; 
		#* this option cannot use credentials argument, so passed credentials are ignored
		Invoke-Command -ScriptBlock $ScriptBlock -ArgumentList $ArgumentList
	}
	else
	{
		#execute command via PSRemoting.
    $tempPSSession =  Open-ARCHPSSession -ComputerName $ComputerName -Credential $Credential
		Invoke-Command -ScriptBlock $ScriptBlock -ArgumentList $ArgumentList -Session $tempPSSession  
    $tmpIgnoredResult = Close-ARCHPSSession -Session $tempPSSession
	}
}

function Get-ARCHIsLocalServer([Parameter(Mandatory = $false)] [string]$ComputerName)
{
	if ( ($ComputerName -eq "") -or ($ComputerName -eq $env:computername) -or ($ComputerName -eq "localhost") -or ($ComputerName -eq ".") )
	{
		$true
	}
	else
	{
		$false
	}
}

function Update-ARCHSecurityKey([hashtable]$hashtable, [string]$SecurityKey, [string]$NewSecurityKey) {
	foreach ($itemKey in $($hashtable.Keys)) {
		$item = $hashtable[$itemKey]
		if ($item -is [hashtable]) {
			Update-ARCHSecurityKey -hashtable $item -SecurityKey $SecurityKey -NewSecurityKey $NewSecurityKey
		} elseif ($item -is [array]) {
            #do nothing
		} elseif ($item -eq $null) {
            #do nothing
      } else {
			try {
				$tmpValue = [VSoft.Framework.Environment.Configuration.SecurityOperation]::Decrypt($item, $SecurityKey);
				if ($item -ne $tmpValue) {
					$hashtable[$itemKey] = [VSoft.Framework.Environment.Configuration.SecurityOperation]::Encrypt($tmpValue, $NewSecurityKey);
				}
			}
			catch {
				if ($SecurityKey -eq "") {
					Write-VSOFTLog "Can not load encrypted project item ($itemKey), security password is needed" ERROR;
					
				} else {
					Write-VSOFTLog "Can not load encrypted project item ($itemKey), incorrect security password provided" ERROR;
				}
			}
		}
	}
}

function Install-ARCHWindowsRequiredFeatures([Parameter(Mandatory = $true)] [ValidateSet("AppServer","WebServer","FailoverClusterManagement")] [string]$ServerKind)
{
	#previously was used Install-VSOFTWindowsRequiredFeatures

	Write-VSOFTLog "Checking and enabling standard optional Windows features required for VSoft archITekt solution - for $ServerKind."
	$ProductType = (Get-WmiObject -class Win32_OperatingSystem).ProductType
	switch -regex ($ProductType)
	{
		"1" # Workstation
		{
			if ($ServerKind -eq "AppServer") {
				Write-VSOFTLog "Windows Client detected - using DISM method (AppServer)"
				#nothing extra is needed
			} elseif ($ServerKind -eq "WebServer") {
				Write-VSOFTLog "Windows Client detected - using DISM method (WebServer)"
				$RequiredFeatures = @()

				$RequiredFeatures += "IIS-WebServer"
				#enables:
				#IIS-WebServer, IIS-ApplicationDevelopment, IIS-CommonHttpFeatures, IIS-DefaultDocument, IIS-DirectoryBrowsing, IIS-HealthAndDiagnostics, IIS-HttpCompressionStatic, 
				#IIS-HttpErrors, IIS-HttpLogging, IIS-ManagementConsole, IIS-Performance, IIS-RequestFiltering
				#IIS-Security, IIS-StaticContent, IIS-WebServerManagementTools, IIS-WebServerRole, WCF-Services45, WCF-TCP-PortSharing45

				$RequiredFeatures += "IIS-ASPNET45"
				#enables: IIS-ASPNET45, IIS-NetFxExtensibility45, NetFx4Extended-ASPNET45, IIS-ISAPIExtensions, IIS-ISAPIFilter

				$RequiredFeatures += "IIS-HttpCompressionDynamic", "IIS-WindowsAuthentication", "IIS-RequestMonitor", "WCF-HTTP-Activation45"
				

				#those features are ommited (not necessary)
				#"IIS-BasicAuthentication", "NetFx3", "WCF-TCP-Activation45"


				$InstalledFeatures = Get-WindowsOptionalFeature -online | where State -eq "Enabled" | foreach {$_.FeatureName}
				$MissingFeatures = @()
				foreach ($Feature in $RequiredFeatures)
				{
					if ($InstalledFeatures -notcontains $Feature)
					{
					  $MissingFeatures += $Feature
					}
				}

				foreach ($Feature in $MissingFeatures)
				{
					Write-VSOFTLog "Enabling missing feature: $Feature"  
					Enable-WindowsOptionalFeature -Online -All -FeatureName $Feature | Out-Null
				}
			} elseif ($ServerKind -eq "FailoverClusterManagement") {
        Write-VSOFTLog "Windows Client detected - using DISM method (FailoverClusterManagement)"

        #https://www.itechguides.com/how-to-install-rsat-in-windows-11/
        $tmpWindowsCapability = Get-WindowsCapability -Online | Where-Object {$_.Name -like "Rsat.FailoverCluster.Management.Tools*"}
        if (-not $tmpWindowsCapability) {
          Write-VSOFTLog "Windows Capability 'Rsat.FailoverCluster.Management.Tools' not found. Cannot manage failover cluster" Error
        }
        if ($tmpWindowsCapability.State -ne "Installed") {
          Write-VSOFTLog "Windows Capability 'Rsat.FailoverCluster.Management.Tools' state is $($tmpWindowsCapability.State). Installing.."
          Add-WindowsCapability -Online -Name $tmpWindowsCapability.Name | Out-Null
        }
      }
		}
		"2|3" # Domain controler and Regular server
		{
			
			if ($ServerKind -eq "AppServer") {
				Write-VSOFTLog "Windows Server detected - using ServerManager method (AppServer)"
				#nothing extra is needed
			} elseif ($ServerKind -eq "WebServer") {
				Write-VSOFTLog "Windows Server detected - using ServerManager method (WebServer)"
				install-windowsfeature -name Web-Server | Out-Null
				Install-WindowsFeature -name Web-Asp-Net45 | Out-Null
				install-WindowsFeature -name Web-Dyn-Compression | Out-Null # HTML pages - dynamic compression
				install-windowsfeature -name NET-WCF-HTTP-Activation45 | Out-Null # forms & lists preview from Studio
				install-windowsfeature -name Web-Windows-Auth | Out-Null
				install-windowsfeature -name Web-Request-Monitor | Out-Null
				install-windowsfeature -name Web-Mgmt-Tools | Out-Null
				install-windowsfeature -name Web-Mgmt-Console | Out-Null

				#those will be installed as depoendencies:
				#Web-Server, Web-WebServer, Web-Common-Http, Web-Default-Doc, Web-Dir-Browsing, Web-Http-Errors, Web-Static-Content, Web-Health, Web-Http-Logging, Web-Performance, Web-Stat-Compression, Web-Dyn-Compression
				#Web-Security, Web-Filtering, Web-Windows-Auth, Web-App-Dev, Web-Net-Ext45, Web-Asp-Net45, Web-ISAPI-Ext, Web-ISAPI-Filter, Web-Mgmt-Tools, Web-Mgmt-Console,
				#NET-Framework-45-ASPNET, NET-WCF-HTTP-Activation, WAS, WAS-Process-Model, WAS-Config-APIs

				#those are ommited
				#Web-Basic-Auth
				#NET-Framework-Features,NET-Framework-Core, (.NET 3.5)
				#NET-Framework-45-Features,NET-Framework-45-Core (already installed by instalator)
				#NET-WCF-TCP-Activation45, NET-WCF-Services45, 
				#NET-WCF-TCP-PortSharing45 (already installed - by default is enabled on win 2019)
			} elseif  ($ServerKind -eq "FailoverClusterManagement") {
        Write-VSOFTLog "Windows Server detected - using ServerManager method (FailoverClusterManagement)"
        Install-WindowsFeature RSAT-Clustering-PowerShell | Out-Null
      }
		} 
	}
}

#utility
Export-ModuleMember -Function Test-ARCHSecurityKey
Export-ModuleMember -Function Get-VSOFTRandomCharacters
Export-ModuleMember -Function Get-ARCHRandomPassword
Export-ModuleMember -Function Get-ARCHDatabaseConnection
Export-ModuleMember -Function Invoke-ARCHCommandSmart
Export-ModuleMember -Function Get-ARCHIsLocalServer
Export-ModuleMember -Function Remove-ARCHItem
Export-ModuleMember -Function Remove-ARCHItemAsScript
Export-ModuleMember -Function Open-ARCHSQLConnection
Export-ModuleMember -Function Open-ARCHPSSession
Export-ModuleMember -Function Close-ARCHPSSession
Export-ModuleMember -Function Update-ARCHDBConfigKey
Export-ModuleMember -Function Invoke-ARCHSQLUpdate

#user Management
Export-ModuleMember -Function New-ARCHVipUser
Export-ModuleMember -Function Set-ARCHVipPassword


#files
Export-ModuleMember -Function Import-ARCHProjectFile
Export-ModuleMember -Function Export-ARCHProjectFile
Export-ModuleMember -Function Import-ARCHRuntimeFile
Export-ModuleMember -Function Export-ARCHRuntimeFile
Export-ModuleMember -Function Import-ARCHImageVersionFile
Export-ModuleMember -Function Import-ARCHUninstallInfoFile
Export-ModuleMember -Function Export-ARCHUninstallInfoFile

#version server
Export-ModuleMember -Function Import-VSOFTVersionServer
Export-ModuleMember -Function Export-VSOFTVersionServer
Export-ModuleMember -Function Invoke-ARCHVersionServerRunUpgradeScripts

#packages
Export-ModuleMember -Function Import-ARCHPackage
Export-ModuleMember -Function Export-ARCHPackage
Export-ModuleMember -Function Import-ARCHPackageSQLScriptsBackwardCompatibility

#project

Export-ModuleMember -Function Test-ARCHCorrectProjectVersion
Export-ModuleMember -Function New-ARCHProject 
#Export-ModuleMember -Function Initialize-ARCHProject
Export-ModuleMember -Function Remove-ARCHProject
Export-ModuleMember -Function Update-ARCHUninstallPackage

#runtime
Export-ModuleMember -Function New-ARCHRuntimeDeveloper
Export-ModuleMember -Function New-ARCHRuntimeContainers
Export-ModuleMember -Function New-ARCHRuntimeOnPremises
Export-ModuleMember -Function Remove-ARCHRuntimeDeveloper
Export-ModuleMember -Function Remove-ARCHRuntimeOnPremises
Export-ModuleMember -Function Get-ARCHRuntimeDeveloperFolder
Export-ModuleMember -Function Invoke-ARCHLocalSqlScriptsPatcher
Export-ModuleMember -Function Invoke-ARCHLocalXmlMerger

#trace progress
Export-ModuleMember -Function Trace-ARCHProgressWrite
Export-ModuleMember -Function Trace-ARCHProgressStartMajorStep
Export-ModuleMember -Function Trace-ARCHProgressStartMinorStep

#state file
Export-ModuleMember -Function Import-ARCHStateFile
Export-ModuleMember -Function Export-ARCHStateFile

#datetime
Export-ModuleMember -Function Get-ARCHWindowsTimeZone

#security
Export-ModuleMember -Function Update-ARCHSecurityKey

#Server management
Export-ModuleMember -Function Install-ARCHWindowsRequiredFeatures

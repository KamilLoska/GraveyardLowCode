﻿Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

Add-Type -ReferencedAssemblies @("System.IO.Compression", "System.IO.Compression.FileSystem") -TypeDefinition @"
using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;

namespace VSoft.ZipTools
{
   public static class Compressor
   {
      public static void Create(string archivePath, string rootPath, string[] filePaths, bool verbose = false)
      {
         using (ZipArchive archive = ZipFile.Open(archivePath, ZipArchiveMode.Create))
         {
            foreach (string filePath in filePaths)
            {
               string entryPath = filePath;
               if (entryPath.StartsWith(rootPath))
                  entryPath = entryPath.Substring(rootPath.Length).TrimStart('\\');

               if (verbose)
                  Console.WriteLine(entryPath + "  <- " + filePath);

               archive.CreateEntryFromFile(filePath, entryPath, CompressionLevel.Optimal);
            }
         }
      }
   }

   public static class Extractor
   {
      public static void Extract(string zipPath, string extractTo, bool purge)
      {
         extractTo = DestinationEntry.NormalizePath(extractTo);
         extractTo = Path.GetFullPath(extractTo);

         zipPath = Path.GetFullPath(zipPath);
         
         using (ZipArchive archive = ZipFile.OpenRead(zipPath))
         {
            DestinationEntryDirectory rootEntry = new DestinationEntryDirectory(extractTo, string.Empty);

            LoadZipArchive(archive, rootEntry);

            rootEntry.Extract(purge);
         }
      }
      
      private static void AddZipArchiveEntry(DestinationEntryDirectory rootEntry, Dictionary<string, DestinationEntry> entries, ZipArchiveEntry source)
      {
         string rootFullPath = rootEntry.FullPath;

         DestinationEntry destination = DestinationEntry.CreateEntry(rootFullPath, source);
         
         string destinationFullPath = destination.FullPath;

         DestinationEntry other;
         if (entries.TryGetValue(destinationFullPath, out other))
         {
            DestinationEntryDirectory otherDirectory = other as DestinationEntryDirectory;
            if (otherDirectory == null)
               throw new InvalidOperationException("Duplicate file entry: " + destinationFullPath);
            if (otherDirectory.Source != null)
               throw new InvalidOperationException("Duplicate directory entry: " + destinationFullPath);

            otherDirectory.AttachSource(source);
            return;
         }

         Stack<string> parents = new Stack<string>();
         string parentDirectoryPath = GetParentFolder(destinationFullPath);
         do
         {
            if (parentDirectoryPath == null)
               throw new InvalidOperationException("Path " + destinationFullPath + " is not subpath of " + rootFullPath);

            if (!entries.TryGetValue(parentDirectoryPath, out other))
            {
               parents.Push(parentDirectoryPath);
               parentDirectoryPath = GetParentFolder(parentDirectoryPath);
            }
         }
         while (other == null);

         DestinationEntryDirectory parent = other as DestinationEntryDirectory;
         if (parent == null)
            throw new InvalidOperationException("Directory entry " + parentDirectoryPath + " is file");


         DestinationEntryDirectory newDirectory;
         while (parents.Count > 0)
         {
            newDirectory = new DestinationEntryDirectory(rootFullPath, parents.Pop());
            parent.AddChild(newDirectory);
            entries.Add(newDirectory.FullPath, newDirectory);
            parent = newDirectory;
         }

         parent.AddChild(destination);
         entries.Add(destinationFullPath, destination);
      }

      private static string GetParentFolder(string path)
      {
         int lastIndexOf = path.LastIndexOf(Path.DirectorySeparatorChar);
         if (lastIndexOf >= 0)
            return path.Substring(0, lastIndexOf);
         return null;
      }

      private static void LoadZipArchive(ZipArchive archive, DestinationEntryDirectory rootEntry)
      {
         Dictionary<string, DestinationEntry> entries = new Dictionary<string, DestinationEntry>(StringComparer.OrdinalIgnoreCase);
         entries.Add(rootEntry.FullPath, rootEntry);

         foreach (ZipArchiveEntry entry in archive.Entries)
         {
            AddZipArchiveEntry(rootEntry, entries, entry);
         }
      }
   }

   internal abstract class DestinationEntry
   {
      public static string NormalizePath(string path)
      {
         path = path.Replace(Path.AltDirectorySeparatorChar, Path.DirectorySeparatorChar);
         path = path.TrimEnd(Path.DirectorySeparatorChar);

         return path;
      }
      public static DestinationEntry CreateEntry(string rootPath, ZipArchiveEntry source)
      {
         if (String.IsNullOrEmpty(source.Name))
            return new DestinationEntryDirectory(rootPath, source);

         return new DestinationEntryFile(rootPath, source);
      }

      public string FullPath { get; protected set; }
      public ZipArchiveEntry Source { get; protected set; }

      protected DestinationEntry(string rootPath, string realtivePath)
      {
         realtivePath = NormalizePath(realtivePath);

         FullPath = Path.Combine(rootPath, realtivePath);
         if (!FullPath.StartsWith(rootPath, StringComparison.OrdinalIgnoreCase))
            throw new ArgumentException(FullPath + " do not starts with " + rootPath);
      }

      public abstract void Extract(bool purge);
   }

   internal class DestinationEntryFile : DestinationEntry
   {
      public DestinationEntryFile(string rootPath, ZipArchiveEntry source)
         : base(rootPath, source.FullName)
      {
         Source = source;
      }
      public override void Extract(bool purge)
      {
         FileInfo dst = new FileInfo(FullPath);

         if (dst.Exists)
         {
            if (Source.Length == dst.Length && Source.LastWriteTime.UtcDateTime == dst.LastWriteTimeUtc)
               return;

            dst.Delete();
         }
         Source.ExtractToFile(FullPath);
      }
   }

   internal class DestinationEntryDirectory : DestinationEntry
   {
      private Dictionary<string, DestinationEntry> _children;

      public DestinationEntryDirectory(string rootPath, ZipArchiveEntry source)
         : base(rootPath, source.FullName)
      {
         _children = new Dictionary<string, DestinationEntry>(StringComparer.OrdinalIgnoreCase);
         Source = source;
      }

      public DestinationEntryDirectory(string rootPath, string realtivePath)
         : base(rootPath, realtivePath)
      {
         _children = new Dictionary<string, DestinationEntry>(StringComparer.OrdinalIgnoreCase);
         Source = null;
      }

      public void AttachSource(ZipArchiveEntry source)
      {
         if (Source != null)
            throw new InvalidOperationException("Source is already attached");
         Source = source;
      }

      public void AddChild(DestinationEntry child)
      {
         _children.Add(child.FullPath, child);
      }

      public override void Extract(bool purge)
      {
         Directory.CreateDirectory(FullPath);
         DirectoryInfo dst = new DirectoryInfo(FullPath);

         if (purge)
         {
            foreach (FileInfo file in dst.GetFiles())
            {
               if (!_children.ContainsKey(file.FullName))
                  file.Delete();
            }
            foreach (DirectoryInfo dir in dst.GetDirectories())
            {
               if (!_children.ContainsKey(dir.FullName))
                  dir.Delete(true);
            }
         }
         foreach (DestinationEntry child in _children.Values)
         {
            child.Extract(purge);
         }

         if (Source == null)
            return;

         dst.Refresh();
         dst.LastWriteTimeUtc = Source.LastWriteTime.UtcDateTime;
      }
   }
}
"@
param(
    [parameter(Position=0,Mandatory=$false)][string]$paramInstallToolsLogFileName
)
#can override log file by importing as import-module .\InstallTools.psm1 -ArgumentList 'my file names'

#All fuctions in this module this stop on first error
$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

#Next line is updated by TFS build with unique build number
$InstallToolsModuleVersion = "21.1.0"

<#
.SYNOPSIS
Log level definition
#>
Add-Type -TypeDefinition @"
   public enum LogLevel
   {
     Debug,
     Info,
     Warning,
     Error
   }
"@



function Show-VSOFTLogForTFS()
{
  if ((Get-Host).Name -eq "Default Host")   #script works inside TFS build agent
  {
    try
    {
      foreach($line in Get-Content $InstallToolsLogFileName) 
      {
         # This assumes that each line of log is written in format date <tab> Level <tab> message
         $ArrayTemp = $line.Split("`t",3,[System.StringSplitOptions]::RemoveEmptyEntries)
         if ($ArrayTemp.Count -ne 3) # We have line that does not match intended format so we need to convert it to right one.
         {
            $ArrayTemp = @("", "Info", $line)
         }
         switch ($ArrayTemp[1])
         {
            "Debug"    { "##[debug] $($ArrayTemp[2])" }
            "Info"     { "$($ArrayTemp[2])"           }
            "Warning"  { "##vso[task.logissue type=warning;] $($ArrayTemp[2])" }
            "Error"    {
                         "##vso[task.logissue type=error;] $($ArrayTemp[2])"  
                         "##vso[task.logissue type=error;] Error while executing script - consult logs for details." 
                         "##vso[task.complete result=Failed;] Error while executing script - consult logs for details." 
                       }
        }
      }
    }
    catch
    {
       "##vso[task.logissue type=error;] Error while transfering processing log to TFS"  
       "##vso[task.logissue type=error;] $_.Exception.Message" 
    }
  }
}



[string]$InstallToolsLogFileName = $paramInstallToolsLogFileName;
<#
.SYNOPSIS
Writes message to log file
#>
function Write-Log ([string]$Message,[Parameter(Mandatory = $true)] [loglevel]$Level = "Info")
{
  #Calculate name of the log if not set before
  if (!$script:InstallToolsLogFileName)
  {
    $FileDate = Get-Date -Format "yyyy-MM-dd HH-mm-ss"
    $script:InstallToolsLogFileName = "Setup execution log $env:computername $FileDate.log"
  }

  #Write entry to the log
  try
  {
    $EntryDate = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $EntryContent = "$EntryDate`t$Level`t$Message"
    $EntryContent | Out-File -FilePath $script:InstallToolsLogFileName -Append -Encoding UTF8
  }
  catch
  {
    # we need to ignore this error :(
  }

}





<#
.SYNOPSIS
Function writes message to the diagnostic log.

.DESCRIPTION

.PARAMETER Message
Text of the message to be written to the log.

.PARAMETER Level
Severity level of the message.
When "Error" is used then message is written to log and then script execution is terminated.

.EXAMPLE
Write-VSOFTLog "Start processing."
Write-VSOFTLog "File $file not found." Error
Dir | Write-VSOFTLog
#>
function Write-VSOFTLog ([Parameter(ValueFromPipeline = $true)][string]$Message, [loglevel]$Level = "Info")
{
  process
  {
    if (-not $Message)
    {
      return;
    }
    $hostName = (Get-Host).Name
    switch ($hostName)
    {
      "Default Host" #script works inside TFS build agent
      {
        switch ($Level)
        {
          Debug
          {
            #Write-Verbose "##[debug] $Message" -Verbose
            Write-Log $Message $Level
            continue
          }
          Info
          {
            #Write-Verbose "$Message"           -Verbose
            Write-Log $Message $Level
            continue
          }
          Warning
          {
            #Write-Verbose "##vso[task.logissue type=warning;] $Message"  -Verbose
            Write-Log $Message $Level
            continue
          }
          Error
          {
            #Write-Verbose "##vso[task.logissue type=error;] $Message"  -Verbose
            #Write-Verbose "##vso[task.logissue type=error;] Error while executing script - consult logs for details." -Verbose
            #Write-Verbose "##vso[task.complete result=Failed;] Error while executing script - consult logs for details." -Verbose
            Write-Log $Message $Level
            Show-VSOFTLogForTFS
            Write-Log "Exiting script with code 1" $Level
            exit 1
          }
        }
        continue
      }
      "ServerRemoteHost" #script works in Remote PowerShell 
      {
        switch ($Level)
        {
          Debug
          {
            Write-Verbose "$env:computername Debug $Message" -Verbose
            continue
          }
          Info
          {
            Write-Verbose "$env:computername Info $Message" -Verbose
            continue
          }
          Warning
          {
            Write-Verbose "$env:computername Warn $Message" -Verbose
            continue
          }
          Error
          {
            Write-Verbose "$env:computername Error $Message" -Verbose
            throw $Message
            Write-Verbose "$env:computername Error Exiting script with code 1" -Verbose
            exit 1
          }
        }
        continue
      }
      default
      {
        switch ($Level)
        {
          Debug
          {
            Write-Host $Message -ForegroundColor Gray
            Write-Log $Message $Level
            continue
          }
          Info
          {
            Write-Host $Message -ForegroundColor White
            Write-Log $Message $Level
            continue
          }
          Warning
          {
            Write-Host $Message -ForegroundColor Yellow
            Write-Log $Message $Level
            continue
          }
          Error
          {
            Write-Host $Message -ForegroundColor Red
            Write-Log $Message $Level
            Write-Host "Exiting script with code 1" -ForegroundColor Red
            Write-Log "Exiting script with code 1" $Level
            exit 1
          }
        }
      }
    }
  }
}


<#
.SYNOPSIS
Function writes message to the diagnostic log which look like visual header for better readability of the log.

.DESCRIPTION

.PARAMETER Message
Text of the message header to be written to the log.

.PARAMETER HeaderLevel
Level of the header to be used. Smaller level makes bigger header.

.EXAMPLE
Write-VSOFTLogHeader "Start copying files" 1
#>
function Write-VSOFTLogHeader ([Parameter(Mandatory = $true)] [string]$Message,[ValidateSet(1,2,3)] [int]$HeaderLevel = 3)
{
  switch ($HeaderLevel)
  {
    1
    {
      Write-VSOFTLog "==================================================================="
      Write-VSOFTLog "==================================================================="
      Write-VSOFTLog "$Message"
      Write-VSOFTLog "==================================================================="
      Write-VSOFTLog "==================================================================="
    }
    2
    {
      Write-VSOFTLog "==================================================================="
      Write-VSOFTLog "$Message"
      Write-VSOFTLog "==================================================================="
    }
    3
    {
      Write-VSOFTLog "-------------------------------------------------------------------"
      Write-VSOFTLog "$Message"
      Write-VSOFTLog "-------------------------------------------------------------------"
    }
  }
}


function Test-VSOFTIsElevated ()
{
  # Check if Elevated
  $WindowsIdentity = [system.security.principal.windowsidentity]::GetCurrent()
  $Principal = New-Object System.Security.Principal.WindowsPrincipal($WindowsIdentity)
  $AdminRole = [System.Security.Principal.WindowsBuiltInRole]::Administrator
  if ($Principal.IsInRole($AdminRole))
  {
    return $true
  }
  else 
  {
    return $false    
  }
}



<#
.SYNOPSIS
Function initializes InstallTools module 
#>
function Initialize-VSOFTInstallTools ()
{
  Write-VSOFTLog "Initialization of VSoft InstallTools module version $InstallToolsModuleVersion"
  Write-VSOFTLog "PowerShell host name:  $((Get-Host).Name)"
  if ([System.IntPtr]::Size -eq 4)
  {
    Write-VSOFTLog "Running inside 32-bit Powershell version $($psversiontable.psversion)"
  }
  else
  {
    Write-VSOFTLog "Running inside 64-bit Powershell version $($psversiontable.psversion)"
  }

  if (!(Get-Module -Name "WebAdministration"))
  {
    Write-VSOFTLog "Loading WebAdministration module"
    if ((Get-Module -ListAvailable "WebAdministration") -and ((Get-PSVersion) -ge 3) -and (Test-VSOFTIsElevated))
    {
      Import-Module WebAdministration
      Write-VSOFTLog "Loaded WebAdministration version: $((Get-Module WebAdministration).Version)"
    }
    else
    {
      Write-VSOFTLog "WebAdministration module is not available so it is not loaded" Warning
    }
  }
  Test-VSOFTFileEncodingIsUTF8 $script:MyInvocation.MyCommand.Definition
}



<#
.SYNOPSIS
Function gets IIS version
#>
function Get-IISVersion ()
{
  try
  {
    $localIISVersion = Get-ItemProperty -Path registry::HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\InetStp\ -ErrorAction SilentlyContinue | Select-Object VersionString
    $localIISVersion = $localIISVersion.VersionString.Substring(8,$localIISVersion.VersionString.Length - 8) -as [double]
  }
  catch
  {
    Write-VSOFTLog ($_.Exception.Message) Error
  }
  return $localIISVersion
}

<#
.SYNOPSIS
Gets PowerShell version
#>
function Get-PSVersion ()
{
  $psVersion = $psversiontable.psversion.major -as [string]
  $psVersion = ($psVersion + "." + $psversiontable.psversion.minor -as [string]) -as [double]
  return $psVersion
}


<#
.SYNOPSIS
Function verifies if TCP port is free
#>
function Test-PortIsFree ([Parameter(Mandatory = $true)] [int]$portNumber)
{
  Write-VSOFTLog "Testing availability of port $portNumber"
  #this check requires Windows 2012
  #$result = Get-NetTCPConnection -LocalPort $portNumber -ErrorAction SilentlyContinue

  #this check should work on earlier versions of Windows
  $result = ([Net.NetworkInformation.IPGlobalProperties]::GetIPGlobalProperties()).GetActiveTcpListeners() | Where Port -EQ $portNumber
  if ($result)
  {
    Write-VSOFTLog "Port $portNumber is not available"
    return $false
  }
  else
  {
    Write-VSOFTLog "Port $portNumber is available"
    return $true
  }
}




<#
.SYNOPSIS
Function verifies if IIS role is installed
#>
function Test-VSOFTIISisInstalled ()
{
  Write-VSOFTLog "Checking installation of Server IIS role"
  $iis = Get-Service W3SVC -ErrorAction SilentlyContinue
  if ($iis -eq $NULL)
  {
    Write-VSOFTLog "Server IIS role is not installed in system. Install IIS role and start installation again" Error
  }
}

<# detecting .Net versions
https://docs.microsoft.com/en-us/dotnet/framework/migration-guide/how-to-determine-which-versions-are-installed#net_b

Relase numbers:
378389	.NET Framework 4.5
378675	.NET Framework 4.5.1 installed with Windows 8.1 or Windows Server 2012 R2
378758	.NET Framework 4.5.1 installed on Windows 8, Windows 7 SP1, or Windows Vista SP2
379893	.NET Framework 4.5.2

393295  .NET Framework 4.6 On Windows 10 systems
393297	.NET Framework 4.6 On all other OS versions 

394254  .NET Framework 4.6.1 On Windows 10 November Update systems 
394271  .NET Framework 4.6.1 On all other OS versions

394802  .NET Framework 4.6.2 On Windows 10 Anniversary Update 
394806  .NET Framework 4.6.2 On all other OS versions 	

460798  .NET Framework 4.7 On Windows 10 Creators Update
460805  .NET Framework 4.7 On all other OS versions 

461308  .NET Framework 4.7.1 On Windows 10 Fall Creators Update
461310  .NET Framework 4.7.1 On all other OS version 
#>

<#
.SYNOPSIS
Function verifies if .net 4.8 is installed
#>
function Test-VSOFTdotNET48isInstalled ()
{
  Write-VSOFTLog "Checking installation of .NET 4.8"
  $ndpDirectory = 'hklm:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full'
  if (Test-Path $ndpDirectory)
  {
    $Value = Get-ItemProperty -Path $ndpDirectory
    if ($Value.Release -ge 528040)
    {
      Write-VSOFTLog "Found .NET version: $($Value.Version) Release: $($Value.Release)" 
      return
    }
  }
  Write-VSOFTLog ".NET 4.8 or newer is not installed. Install .NET 4.8 and start installation again" Error
}


<#
.SYNOPSIS
Function verifies if .net 4.7.2 is installed
#>
function Test-VSOFTdotNET472isInstalled ()
{
  Write-VSOFTLog "Checking installation of .NET 4.7.2"
  $ndpDirectory = 'hklm:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full'
  if (Test-Path $ndpDirectory)
  {
    $Value = Get-ItemProperty -Path $ndpDirectory
    if ($Value.Release -ge 461808)
    {
      Write-VSOFTLog "Found .NET version: $($Value.Version) Release: $($Value.Release)" 
      return
    }
  }
  Write-VSOFTLog ".NET 4.7.2 or newer is not installed. Install .NET 4.7.2 and start installation again" Error
}

<#
.SYNOPSIS
Function verifies if .net 4.7.1 is installed
#>
function Test-VSOFTdotNET471isInstalled ()
{
  Write-VSOFTLog "Checking installation of .NET 4.7.1"
  $ndpDirectory = 'hklm:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full'
  if (Test-Path $ndpDirectory)
  {
    $Value = Get-ItemProperty -Path $ndpDirectory
    if ($Value.Release -ge 461308)
    {
      Write-VSOFTLog "Found .NET version: $($Value.Version) Release: $($Value.Release)" 
      return
    }
  }
  Write-VSOFTLog ".NET 4.7.1 or newer is not installed. Install .NET 4.7.1 and start installation again" Error
}

<#
.SYNOPSIS
Function verifies if .net 4.7 is installed
#>
function Test-VSOFTdotNET47isInstalled ()
{
  Write-VSOFTLog "Checking installation of .NET 4.7"
  $ndpDirectory = 'hklm:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full'
  if (Test-Path $ndpDirectory)
  {
    $Value = Get-ItemProperty -Path $ndpDirectory
    if ($Value.Release -ge 460798)
    {
      Write-VSOFTLog "Found .NET version: $($Value.Version) Release: $($Value.Release)" 
      return
    }
  }
  Write-VSOFTLog ".NET 4.7 or newer is not installed. Install .NET 4.7 and start installation again" Error
}


<#
.SYNOPSIS
Function verifies if .net 4.6.2 is installed
#>
function Test-VSOFTdotNET462isInstalled ()
{
  Write-VSOFTLog "Checking installation of .NET 4.6.2"
  $ndpDirectory = 'hklm:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full'
  if (Test-Path $ndpDirectory)
  {
    $Value = Get-ItemProperty -Path $ndpDirectory
    if ($Value.Release -ge 394802 )
    {
      Write-VSOFTLog "Found .NET version: $($Value.Version) Release: $($Value.Release)" 
      return
    }
  }
  Write-VSOFTLog ".NET 4.6.2 or newer is not installed. Install .NET 4.6.2 and start installation again" Error
}


<#
.SYNOPSIS
Function verifies if .net 4.6 is installed
#>
function Test-VSOFTdotNET46isInstalled ()
{
  Write-VSOFTLog "Checking installation of .NET 4.6"
  $ndpDirectory = 'hklm:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full'
  if (Test-Path $ndpDirectory)
  {
    $Value = Get-ItemProperty -Path $ndpDirectory
    if ($Value.Release -ge 393295 )
    {
      Write-VSOFTLog "Found .NET version: $($Value.Version) Release: $($Value.Release)" 
      return
    }
  }
  Write-VSOFTLog ".NET 4.6 or newer is not installed. Install .NET 4.6 and start installation again" Error
}



<#
.SYNOPSIS
Function verifies if .net 4.5 is installed
#>
function Test-VSOFTdotNET45isInstalled ()
{
  Write-VSOFTLog "Checking installation of .NET 4.5"
  $ndpDirectory = 'hklm:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full'
  if (Test-Path $ndpDirectory)
  {
    $Value = Get-ItemProperty -Path $ndpDirectory
    if ($Value.Release -ge 378389 )
    {
      Write-VSOFTLog "Found .NET version: $($Value.Version) Release: $($Value.Release)" 
      return
    }
  }
  Write-VSOFTLog ".NET 4.5 or newer is not installed. Install .NET 4.5 and start installation again" Error
}

<#
.SYNOPSIS
Function verifies if .net 4 is installed
#>
function Test-VSOFTdotNET40isInstalled ()
{
  Write-VSOFTLog "Checking installation of .NET 4.0"
  $ndpDirectory = 'hklm:\SOFTWARE\Microsoft\NET Framework Setup\NDP'

  if (!(Test-Path "$ndpDirectory\v4.0"))
  {
    Write-VSOFTLog ".NET 4.0 is not installed. Install .NET 4.0 and start installation again" Error
  }
}

<#
.SYNOPSIS
Function verifies if .net 3.5 is installed
#>
function Test-VSOFTdotNET35isInstalled ()
{
  Write-VSOFTLog "Checking installation of .NET 3.5"
  $ndpDirectory = 'hklm:\SOFTWARE\Microsoft\NET Framework Setup\NDP'

  if (!(Test-Path "$ndpDirectory\v3.5"))
  {
    Write-VSOFTLog ".NET 3.5 is not installed. Install .NET 3.5 and start installation again" Error
  }
}

<#
.SYNOPSIS
Function verifies if .net 3 is installed
#>
function Test-VSOFTdotNET30isInstalled ()
{
  Write-VSOFTLog "Checking installation of .NET 3.0"
  $ndpDirectory = 'hklm:\SOFTWARE\Microsoft\NET Framework Setup\NDP'

  if (!(Test-Path "$ndpDirectory\v3.0"))
  {
    Write-VSOFTLog ".NET 3.0 is not installed. Install .NET 3.0 and start installation again" Error
  }
}

<#
.SYNOPSIS
Function verifies if .net 2.0.50727 is installed
#>
function Test-VSOFTdotNET20isInstalled ()
{
  Write-VSOFTLog "Checking installation of .NET 2.0"
  $ndpDirectory = 'hklm:\SOFTWARE\Microsoft\NET Framework Setup\NDP'

  if (!(Test-Path "$ndpDirectory\v2.0.50727"))
  {
    Write-VSOFTLog ".NET 2.0 is not installed. Install .NET 2.0 and start installation again" Error
  }
}


<#
.SYNOPSIS
Function verifies if Visual C++ 2010 Redistributable Package (x64) is installed
#>
function Test-VSOFTVCRedist2010x64isInstalled ()
{
  Write-VSOFTLog "Checking installation of Visual C++ 2010 Redistributable Package (x64)"
  $VC2010Key = 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\VisualStudio\10.0\VC\VCRedist\x64'
  if (Test-Path $VC2010Key)
  {
    $Value = Get-ItemProperty -Path $VC2010Key
    if ($Value.Installed -eq 1)
    {
      Write-VSOFTLog "Found Visual C++ 2010 Redistributable Package (x64) version: $($Value.Version)" 
      return
    }
  }
  Write-VSOFTLog "Visual C++ 2010 Redistributable Package (x64) is not installed. Please install this prerequisite and start installation again." Error
}



<#
.SYNOPSIS
Function verifies if Visual C++ 2013 Redistributable Package (x64) is installed
#>
function Test-VSOFTVCRedist2013x64isInstalled ()
{
  Write-VSOFTLog "Checking installation of Visual C++ 2013 Redistributable Package (x64)"
  $VC2013Key = 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\VisualStudio\12.0\VC\Runtimes\x64'
  if (Test-Path $VC2013Key)
  {
    $Value = Get-ItemProperty -Path $VC2013Key
    if ($Value.Installed -eq 1)
    {
      Write-VSOFTLog "Found Visual C++ 2013 Redistributable Package (x64) version: $($Value.Version)" 
      return
    }
  }
  Write-VSOFTLog "Visual C++ 2013 Redistributable Package (x64) is not installed. Please install this prerequisite and start installation again." Error
}




<#
.SYNOPSIS
Function checks if file is encoded in UTF8.

.PARAMETER Path
Path to the file to be checked. Wildcards can be used to check multiple files.

.EXAMPLE
Test-VSOFTFileEncodingIsUTF8 c:\Scripts\*.sql

#>
function Test-VSOFTFileEncodingIsUTF8([Parameter(Mandatory = $true)] [string] $Path)
{
  $CSSource = @"
    using System;
    using System.Text;
    using System.IO;
    public class UTF8Checker
    {
    private static readonly Encoding UTF8_NO_MERCY_ENCODING = Encoding.GetEncoding(Encoding.UTF8.CodePage, new EncoderExceptionFallback(), new DecoderExceptionFallback());

      static public bool IsFileReadableAsUTF8(string filePath, out string warnings)
      {
         try
         {
            File.ReadAllText(filePath, UTF8_NO_MERCY_ENCODING);
            warnings = null;
            return true;
         }
         catch (DecoderFallbackException ex)
         {
            warnings = "File is not encoded in UTF8: " + ex.Message;
            return false;
         }
         catch (Exception ex)
         {
            warnings = "Error reading the file: " + ex.Message;
            return false;
         }
      }
    }
"@
  try
  {
    Add-Type -TypeDefinition $CSSource
    $files=Get-ChildItem $Path -File
    foreach ($file in $files)
    {
      Write-VSOFTLog "Checking UTF8 encoding for file: $File"
      $error = ""
      if (![UTF8Checker]::IsFileReadableAsUTF8($file, [ref] $error))
      {
          Write-VSOFTLog "$error" Error
      }
    }
  }
  catch
  {
    Write-VSOFTLog ($_.Exception.Message) Error
  }
}



<#
.SYNOPSIS
Function checks and enables as necessary all standard optional Windows features that are required by VSoft solution.
.DESCRIPTION
This function enables well known standard features only. If specific solution requires additional features then they must be enabled is the mail script.

More information:
https://peter.hahndorf.eu/blog/WindowsFeatureViaCmd.html

.EXAMPLE
Invoke this function to enable standard features:
Install-VSOFTWindowsRequiredFeatures
.EXAMPLE
Get list of "InstallNames" of currently installed features using Server-Manager commands (works only on server):
Get-WindowsFeature | Where Installed |% { $_.AdditionalInfo.InstallName } | Sort

Get list of display and "InstallNames" of currently installed features using Server-Manager commands (works only on server):
Get-WindowsFeature | Where Installed | select DisplayName, Name,  @{Name="InstallName"; Expression={ $_.AdditionalInfo.InstallName}}

Get list of currently installed features using DISM (works on servers and workstations):
Get-WindowsOptionalFeature -Online | Where State -eq "Enabled" | select FeatureName  | Sort -Property FeatureName

#>
function Install-VSOFTWindowsRequiredFeatures()
{
  Write-VSOFTLog "Checking and enabling standard optional Windows features required for VSoft solution."
  $ProductType = (Get-WmiObject -class Win32_OperatingSystem).ProductType
  switch -regex ($ProductType)
  {
    "1" # Workstation
    {
       Write-VSOFTLog "Windows Client detected - using DISM method"
       $RequiredFeatures = @()
       $RequiredFeatures += "IIS-ApplicationDevelopment", "IIS-ASPNET45", "IIS-BasicAuthentication", "IIS-CommonHttpFeatures", "IIS-DefaultDocument", "IIS-DirectoryBrowsing", "IIS-HealthAndDiagnostics", "IIS-HttpCompressionDynamic", "IIS-HttpCompressionStatic", "IIS-HttpErrors", "IIS-HttpLogging", "IIS-ISAPIExtensions", "IIS-ISAPIFilter", "IIS-ManagementConsole", "IIS-NetFxExtensibility45", "IIS-Performance", "IIS-RequestFiltering", "IIS-RequestMonitor", "IIS-Security", "IIS-StaticContent", "IIS-WebServer", "IIS-WebServerManagementTools", "IIS-WebServerRole", "IIS-WindowsAuthentication"
       $RequiredFeatures += "NetFx3", "NetFx4Extended-ASPNET45"
       $RequiredFeatures += "WCF-HTTP-Activation45", "WCF-TCP-Activation45", "WCF-Services45", "WCF-TCP-PortSharing45"
       $InstalledFeatures = Get-WindowsOptionalFeature -online | where State -eq "Enabled" | foreach {$_.FeatureName}
       $MissingFeatures = @()
       foreach ($Feature in $RequiredFeatures)
       {
         if ($InstalledFeatures -notcontains $Feature)
         {
           $MissingFeatures += $Feature
         }
       }

       foreach ($Feature in $MissingFeatures)
       {
         Write-VSOFTLog "Enabling missing feature: $Feature"  
         Enable-WindowsOptionalFeature -Online -All -FeatureName $Feature   | Out-Null
       } 
    }
    "2|3" # Domain controler and Regular server
    {
      Write-VSOFTLog "Windows Server detected - using ServerManager method"
      install-windowsfeature Web-Server,Web-WebServer,Web-Common-Http,Web-Default-Doc,Web-Dir-Browsing,Web-Http-Errors,Web-Static-Content,Web-Health,Web-Http-Logging,Web-Request-Monitor,Web-Performance,Web-Stat-Compression,Web-Dyn-Compression,Web-Security,Web-Filtering,Web-Basic-Auth,Web-Windows-Auth,Web-App-Dev,Web-Net-Ext45,Web-Asp-Net45,Web-ISAPI-Ext,Web-ISAPI-Filter,Web-Mgmt-Tools,Web-Mgmt-Console | Write-VSOFTLog
      install-windowsfeature NET-Framework-Features,NET-Framework-Core,NET-Framework-45-Features,NET-Framework-45-Core,NET-Framework-45-ASPNET      | Write-VSOFTLog 
      install-windowsfeature NET-WCF-HTTP-Activation45, NET-WCF-TCP-Activation45, NET-WCF-Services45,NET-WCF-TCP-PortSharing45                      | Write-VSOFTLog
    } 
  }
}



<#
.SYNOPSIS
Copies files from source to target directory.

.DESCRIPTION
Internally function uses ROBOCOPY to copy files.

.PARAMETER SourcePath
Path to the source folder that contains files to be copied.

.PARAMETER DestinationPath
Path to the destination folder.

.PARAMETER FileNames
Name(s) of the files to be copied. If not specified then all files are copied.
Supports wildcards.

.PARAMETER ExcludeFileNames
Name(s) of the files to be excluded from coping. If not specified then all files are copied.
Supports wildcards. Multiple file names can be provided in an array.

.PARAMETER ExcludeDirectories
Name(s) of the directories to be excluded from coping. If not specified then all directories are copied.
Supports wildcards. Multiple directories names can be provided in an array.

.PARAMETER WithSubdirectories
Use this switch to enable coping recursively with subfolders.

.PARAMETER PurgeDestination
Use switch delete all excessive files in destination folder that do not match files in source folder.

.EXAMPLE
Copy-VSOFTFiles -SourcePath D:\sourceDir -DestinationPath D:\TargetDir -ExcludeFileNames *.ini -WithSubdirectories -PurgeDestination
#>
function Copy-VSOFTFiles ([Parameter(Mandatory = $true)] [string]$SourcePath,
                          [Parameter(Mandatory = $true)] [string]$DestinationPath,
                                                         [string]$FileNames,
                                                         [string[]]$ExcludeFileNames,
                                                         [string[]]$ExcludeDirectories,
                                                         [switch]$WithSubdirectories,
                                                         [switch]$PurgeDestination,
                                                         [switch]$NoParallelCopy,
                                                         [switch]$NoSummary
)
{
  if (!($FileNames))
  {
    $FileNames = "*"
  }
  Write-VSOFTLog "Copying files from: $SourcePath to: $DestinationPath, files: $FileNames, file exclusions: $ExcludeFileNames, directory exclusions: $ExcludeDirectories, with subdirectories: $WithSubdirectories, purge: $PurgeDestination"

  $RobocopyParams = @()
  $RobocopyParams += $SourcePath
  $RobocopyParams += $DestinationPath
  $RobocopyParams += $FileNames

  if ($ExcludeFileNames)
  {
    foreach ($ExcludedFile in $ExcludeFileNames)
    {
      $RobocopyParams  += "/XF", $ExcludedFile
    }  
  }
  if ($ExcludeDirectories)
  {
    foreach ($ExcludedDir in $ExcludeDirectories)
    {
       $RobocopyParams  += "/XD", $ExcludedDir
    }
  }
  if ($WithSubdirectories)
  {
    $RobocopyParams  +=  "/E"
  }
  if ($PurgeDestination)
  {
    $RobocopyParams  += "/Purge"
  }
  if (!$NoParallelCopy)
  {
    $RobocopyParams  += "/MT:32"
    $RobocopyParams  += "/NP"          # no progress
  }
  $RobocopyParams  += "/NFL"           # No File List - don't log file names.
  $RobocopyParams  += "/A-:R"          # Remove the Read Only attribute from copied files  
  $RobocopyParams  += "/NJH"           # No job header
  if ($NoSummary)
  {
    $RobocopyParams  += "/NJS"         # No job summary
  }
  
  ROBOCOPY $RobocopyParams | Write-VSOFTLog

  if ($lastexitcode -lt 8)
  {
    Write-VSOFTLog "Robocopy succeeded with exit code: $lastexitcode | setting to exit code 0"
    $global:LASTEXITCODE = 0
  }
  else
  {
    Write-VSOFTLog "Robocopy failed with exit code: $lastexitcode" Error
  }
}


<#
.SYNOPSIS
Extracts content of the .zip archive into folder.

.DESCRIPTION
This function can be used to extract multiple archives into same destination folder.
Function returns error when attempting to overwrite existing file. You should delete destination folder before calling this function to avoid 'file already exists' error. 

This function requires .Net 4.5.

.PARAMETER $Path
Path to the archive file(s) that should be extracted.
Wildcard characters are supported.

.PARAMETER $DestinationPath
Path to the folder where extracted files should be stored.

.EXAMPLE
Expand-VSOFTArchive archive.zip C:\Target\

.EXAMPLE
Remove-Item C:\Target\ -Recurse 
Expand-VSOFTArchive archives\*.zip C:\Target\

#>
function Expand-VSOFTArchive (
    [Parameter(Mandatory = $true)] [string] $Path, 
    [Parameter(Mandatory = $true)] [string] $DestinationPath) 
{
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $Archives = @()    
    if (Test-Path -Path $Path -PathType Leaf) {
        $Archives = @(Get-Item -Path $Path)
    } else {
    	$Archives = @(Get-ChildItem -Path $Path -Recurse)
    }
	foreach ($Archive in $Archives.GetEnumerator()) {
        Write-VSOFTLog "Extracting content of $Archive into $DestinationPath"
		#Podajemy encodig ponieważ inaczej bywają kłopoty z polskimi literami w nazwach plików i katalogów
		[System.IO.Compression.ZipFile]::ExtractToDirectory($Archive, $DestinationPath, [System.Text.Encoding]::GetEncoding([System.Threading.Thread]::CurrentThread.CurrentCulture.TextInfo.OEMCodePage))
	}
}




<#
.SYNOPSIS
Function starts web application pool in IIS.

.DESCRIPTION

.PARAMETER AppPoolName
Name of the web application pool to be started.

.EXAMPLE
Start-VSOFTWebAppPool -AppPoolName "MyPool"

#>
function Start-VSOFTWebAppPool ([Parameter(Mandatory = $true)] [string]$AppPoolName)
{
  Write-VSOFTLog "Starting IIS Application Pool $appPoolName"
  if ((Get-IISVersion) -ge 7)
  {
    try
    {
      if (Test-Path "IIS:\AppPools\$appPoolName")
      {
        Start-WebAppPool $appPoolName
      }
      else
      {
        Write-VSOFTLog "Application pool $appPoolName not found" Error
      }
    }
    catch
    {
      Write-VSOFTLog ($_.Exception.Message) Error
    }
  }
  else
  {
    Write-VSOFTLog "IIS older than 7 is not currently supported by Start-VSOFTWebAppPool function" Error
  }
}




<#
.SYNOPSIS
Function stops web application pool in IIS.

.DESCRIPTION

.PARAMETER AppPoolName
Name of the web application pool to be stopped.

.EXAMPLE
Stop-VSOFTWebAppPool -AppPoolName "MyPool"
#>
function Stop-VSOFTWebAppPool ([Parameter(Mandatory = $true)] [string]$AppPoolName)
{
  Write-VSOFTLog "Stopping IIS Application Pool $appPoolName"
  if ((Get-IISVersion) -ge 7)
  {
    try
    {
      if (Test-Path "IIS:\AppPools\$appPoolName")
      {
        if ((Get-WebAppPoolState $appPoolName).Value -ne 'Stopped') 
        {
          Stop-WebAppPool -Name $appPoolName | Out-Null 
          
        }
      }
    }
    catch
    {
      Write-VSOFTLog ($_.Exception.Message) Error
    }
  }
  else
  {
    Write-VSOFTLog "IIS older than 7 is not currently supported by Stop-VSOFTWebAppPool function" Error
  }
}




<#
.SYNOPSIS
Function creates new web application pool in IIS.

.DESCRIPTION
Web application pool to be created cannot already exist.

.PARAMETER AppPoolName
Name of the web application pool to be created.

.PARAMETER DotNetVersion
Name of the .Net version to be used by the application.
If not provided then .Net 4.0 will be used.

.PARAMETER PipelineMode
Type of the pipeline to be used by the web application pool.
If not provided then Integrated will be used.

.PARAMETER Credential
Credential of the user to be used by web application pool.
If not provided then default ApplicationPoolIdentity wil be used.

.EXAMPLE
Add-VSOFTAppPool -AppPoolName "MyPool"
#>

function Add-VSOFTAppPool ([Parameter(Mandatory = $true)] [Alias("WebPoolName")] [string] $AppPoolName,
                                             [ValidateSet("v1.1","v2.0","v4.0")] [string] $DotNetVersion,
                                           [ValidateSet("Classic","Integrated")] [string] $PipelineMode,
                                              [System.Management.Automation.Credential()]
                                              [System.Management.Automation.PSCredential] $Credential = [System.Management.Automation.PSCredential]::Empty)
{
  Write-VSOFTLog "Begining of adding IIS Application Pool $AppPoolName"

  if ((Get-IISVersion) -lt 7)
  {
      Write-VSOFTLog "IIS earlier than 7 is not supported." Error
  }
  try
  {
    $newPool = New-WebAppPool -Name $AppPoolName
    if (!($dotNetVersion))
    {
      Write-VSOFTLog ".NET version was not provided. Default value 4.0 will be used" Debug
      $dotNetVersion = "v4.0"
    }

    # pipeline mode validation
    if (("Integrated") -contains $pipelineMode) {
      $localManagedPipelineMode = 0
    }
    elseif (("Classic") -contains $pipelineMode) {
      $localManagedPipelineMode = 1
    }
    else
    {
      Write-VSOFTLog "Pipeline mode was not provided. Default value Integrated will be used" Debug
      $localManagedPipelineMode = 0
    }

    $newPool.managedRuntimeVersion = $dotNetVersion
    $newPool.managedPipeLineMode = $localManagedPipelineMode

    if (($Credential) -and ($Credential -ne [System.Management.Automation.PSCredential]::Empty))
    {
      $newPool.processModel.userName = $Credential.userName
      $newPool.processModel.password = $Credential.GetNetworkCredential().password
      $newPool.processModel.identityType = 3 #https://www.iis.net/configreference/system.applicationhost/applicationpools/add/processmodel
    }
    else
    {
      $newPool.processModel.identityType = 4
    }
    $newPool | Set-Item
    Write-VSOFTLog "App pool $AppPoolName created successfully"
  }
  catch
  {
    Write-VSOFTLog ($_.Exception.Message) Error
  }
}




<#
.SYNOPSIS
Function removes web application pool from IIS.

.DESCRIPTION
If such web application pool to be removed does not exist function will log such fact and return success.


.PARAMETER AppPoolName
Name of the web application pool to be removed.


.EXAMPLE
Remove-VSOFTWebAppPool -AppPoolName "MyAppPool"
#>

function Remove-VSOFTWebAppPool ([Parameter(Mandatory = $true)] [string]$AppPoolName)
{
  Write-VSOFTLog "Begining of removing IIS Application Pool $AppPoolName"
  if ((Get-IISVersion) -lt 7)
  {
      Write-VSOFTLog "IIS earlier than 7 is not supported." Error
  }
  try
  {
      Write-VSOFTLog "Removing IIS Application Pool $AppPoolName"
      if (Test-Path "IIS:\AppPools\$AppPoolName")
      {
        Remove-WebAppPool $AppPoolName
        Write-VSOFTLog "ISS Application pool $AppPoolName successfully deleted"
      }
      else
      {
        Write-VSOFTLog "IIS Application Pool $AppPoolName not found" Debug
      }
  }
  catch
  {
    Write-VSOFTLog ($_.Exception.Message) Error
  }
}



<#
.SYNOPSIS
Function creates new web site.

.DESCRIPTION
Function verifies existence of web site with provided name if such web site already exists it will not create new one and will not modify the existing one.
This function can also create web site that is a web application is the same time. In such case WebSitePath must point to the root folder of the application.

.PARAMETER  WebSiteName
Name of the web site to be created.

.PARAMETER  WebSitePort
Port number to be used by the web site.
 
.PARAMETER  Protocol
Protocol to be used by the binding. Usually http or https

.PARAMETER WebSitePath
Path on the disk to the root folder of the web site.

.PARAMETER  IPAddress
IP address to be used by the binding. If not provided '*' will be used.
 
.PARAMETER  AppPoolName
Name of the aplication pool to be used by the web site.

.PARAMETER  HostHeader
Host header to be used by the binding.

.PARAMETER  CertThumbprint
Thumbprint of the certificate to be used by the web site for HTTPS protocol.

.EXAMPLE
Add-VSOFTWebSite -WebSiteName "MySite" -WebSitePort 90 

#> 
function Add-VSOFTWebSite ([Parameter(Mandatory = $true)] [string]$WebSiteName,
                           [Parameter(Mandatory = $true)] [string]$WebSitePort,
                                                          [string]$Protocol = "http",
                                                          [string]$WebSitePath,
                                                          [string]$AppPoolName,
                                                          [string]$IPAddress,
                                                          [string]$HostHeader,
                                                          [string]$CertThumbprint)
{
  Write-VSOFTLog "Begining of adding web site $webSiteName"
  if ((Get-IISVersion) -lt 7)
  {
      Write-VSOFTLog "IIS earlier than 7 is not supported." Error
  }
  try
  {
      if (!$AppPoolName)
      {
        Write-VSOFTLog "Application pool name was not provided. Default value DefaultAppPool will be used" Debug
        $AppPoolName = "DefaultAppPool"
      }
      if (!$webSitePath)
      {
        Write-VSOFTLog "Site path was not provided. Default value C:\InetPub\wwwroot will be used" Debug
        $webSitePath = "C:\InetPub\wwwroot"
      }
      if (!$IPAddress)
      {
        Write-VSOFTLog "IPAddress parameter is empty - using '*'" Debug
        $IPAddress = "*"
      }
      if ($Protocol -eq "https")
      {
        $SSL = $true
      }
      else
      {
        $SSL = $false
      }

      Write-VSOFTLog "Creating new web site $WebSiteName on port $WebSitePort using application pool $AppPoolName"
      if ((Test-Path "IIS:\Sites\$WebSiteName"))
      {
        Write-VSOFTLog "Web Site $WebSiteName already exists"
        return
      }
      Write-VSOFTLog "Checking existence of binding with paramaters port: $WebSitePort, Protocol: $Protocol, IP: $IPAddress, HostHeader: $HostHeader"
      $binding = Get-WebBinding -Port $WebSitePort -Protocol $Protocol -IP $IPAddress -HostHeader $HostHeader
      if ($binding)
      {
         Write-VSOFTLog "Binding requested for new web site is already used by other web site." Error
      }
      New-Website -Name $WebSiteName -Port $WebSitePort -PhysicalPath $WebSitePath -ApplicationPool $AppPoolName -IPAddress $IPAddress -HostHeader $HostHeader -Ssl:$SSL
      if ($CertThumbprint)
      {
        $binding = Get-WebBinding -Name $webSiteName -Port $webSitePort -Protocol $Protocol -IP $IPAddress -HostHeader $HostHeader
        $CertThumbprint = $CertThumbprint.Replace(" ","")
        Write-VSOFTLog "Getting certificate by Thumbprint $CertThumbprint" Debug
        $cert = Get-ChildItem cert:\localmachine\my | Where-Object { $_.Thumbprint -eq $CertThumbprint }
        if (!$cert)
        {
          Write-VSOFTLog "Unable to find certificate with Thumbprint $CertThumbprint" Error
        }
        Write-VSOFTLog "Adding certificate to the site binding"
        $binding.AddSslCertificate($cert.GetCertHashString(),"my")
      }
      Write-VSOFTLog "Successfully created new web site $WebSiteName on port $WebSitePort using application pool $AppPoolName"
      Write-VSOFTLog "Stating new Web Site $WebSiteName"
      Start-Website -Name "$WebSiteName"
  }
  catch
  {
    Write-VSOFTLog ($_.Exception.Message) Error
  }
}

<#
.SYNOPSIS
Function removes web site from IIS.

.DESCRIPTION
If such web site to be removed does not exist function will log such fact and return success.


.PARAMETER WebSiteName
Name of the web site to be removed.


.EXAMPLE
Remove-VSOFTWebSite -WebSiteName "MySite"
#>
function Remove-VSOFTWebSite ([Parameter(Mandatory = $true)] [string]$WebSiteName)
{
  Write-VSOFTLog "Begining of removing web site $webSiteName"
  if ((Get-IISVersion) -lt 7)
  {
      Write-VSOFTLog "IIS earlier than 7 is not supported." Error
  }
  try
  {
      if (!(Test-Path "IIS:\Sites\$webSiteName"))
      {
        Write-VSOFTLog "Cannot delete web site $webSiteName. Web site doesn't exist" Warning
        return
      }
      $getWebApplicationResult = Get-WebApplication -Site $webSiteName #check if Web Site contains any applications 
      if ($getWebApplicationResult)
      {
        Write-VSOFTLog "Cannot delete web wite $webSiteName. Web site contains other applications" Error
      }
      Remove-Website -Name $webSiteName
      Write-VSOFTLog "Web wite $webSiteName successfully deleted"
  }
  catch
  {
    Write-VSOFTLog ($_.Exception.Message) Error
  }
}



<#
.SYNOPSIS
Function creates new binding for IIS web site.

.DESCRIPTION
Function verifies existence of binding with required parameters and if such binding already exist it will not create new one.
Binding is identified by following 4 parameters: Port, Protocol, IPAddress, HostHeader.

.PARAMETER  Port
Port number to be used by the binding.
 
.PARAMETER  SiteName
Site name for the binding. If not provided then Default Web Site will be used.

.PARAMETER  Protocol
Protocol to be used by the binding. Usually http or https

.PARAMETER  IPAddress
IP address to be used by the binding. If not provided '*' will be used.
 
.PARAMETER  HostHeader
Host header to be used by the binding.

.PARAMETER  $CertThumbprint
Thumbprint of the certificate to be used by the binding for HTTPS protocol.

.EXAMPLE
Add-VSOFTWebBinding -Port 443 -Protocol "https" -CertThumbprint "xxxxx"

#> 
function Add-VSOFTWebBinding  ([Parameter(Mandatory = $true)] [int]    $Port,
                                                              [string] $SiteName,
                               [Parameter(Mandatory = $true)] [string] $Protocol,
                                                              [string] $IPAddress,
                                                              [string] $HostHeader,
                                                              [string] $CertThumbprint)
{
  Write-VSOFTLog "Adding new web binding on port: $Port, protocol: $Protocol"
  if (!$SiteName)
  {
    Write-VSOFTLog "Web Site parameter is empty - using 'Default Web Site'" Debug
    $SiteName = "Default Web Site"
  }
  if (!$IPAddress)
  {
    Write-VSOFTLog "IPAddress parameter is empty - using '*'" Debug
    $IPAddress = "*"
  }
  try
  {
    Write-VSOFTLog "Checking existence of binding with paramaters port: $Port, Protocol: $Protocol, IP: $IPAddress, HostHeader: $HostHeader"
    $binding = Get-WebBinding -Port $Port -Protocol $Protocol -IP $IPAddress -HostHeader $HostHeader
    if ($binding)
    {
       Write-VSOFTLog "Binding already exists - new one will not be created."
       return
    }
    Write-VSOFTLog "Creating new binding with following parameters site: $SiteName, port: $Port, Protocol: $Protocol, IP: $IPAddress, HostHeader: $HostHeader"
    New-WebBinding -Name $SiteName -Port $Port -Protocol $Protocol -IP $IPAddress -HostHeader $HostHeader 
    $binding = Get-WebBinding -Name $SiteName -Port $Port -Protocol $Protocol -IP $IPAddress -HostHeader $HostHeader
    if ($CertThumbprint)
    {
      $CertThumbprint = $CertThumbprint.Replace(" ","")
      Write-VSOFTLog "Getting certificate by Thumbprint $CertThumbprint" Debug
      $cert = Get-ChildItem cert:\localmachine\my | Where-Object { $_.Thumbprint -eq $CertThumbprint }
      if (!$cert)
      {
        Write-VSOFTLog "Unable to find certificate with Thumbprint $CertThumbprint" Error
      }
      Write-VSOFTLog "Adding certificate to the newly created binding"
      $binding.AddSslCertificate($cert.GetCertHashString(),"my") | Out-Null
    }
  }
  catch
  {
    Write-VSOFTLog ($_.Exception.Message) Error
  }
}


 
<#
.SYNOPSIS
Function removes binding from IIS web site.

.DESCRIPTION
Binding is identified by following parameters: Port

.PARAMETER  Port
Port number used by binding to bew removed.
 
.PARAMETER  SiteName
Site name for the binding. If not provided then Default Web Site will be used.

.EXAMPLE
Remove-VSOFTWebBinding -Port 443 

#> 
function Remove-VSOFTWebBinding ([Parameter(Mandatory = $true)] [int]    $Port,
                                                                [string] $SiteName)
{
  Write-VSOFTLog "Begining removing web binding on port $Port"
  if (!$SiteName)
  {
    Write-VSOFTLog "Web Site parameter is empty - using 'Default Web Site'" Debug
    $SiteName = "Default Web Site"
  }
  try
  {
    $binding = Get-WebBinding -Name $SiteName -Port $Port
    if ($binding)
    {
      Write-VSOFTLog "Found exiting binding on port $Port in site $SiteName - removing"
      Remove-WebBinding -Port $Port -Name $SiteName
    }
    else
    {
      Write-VSOFTLog "Binding on port $Port in site $SiteName not found" Debug
    }
  }
  catch
  {
    Write-VSOFTLog ($_.Exception.Message) Error
  }
}
 





<#
.SYNOPSIS
Function creates new web application in IIS.

.DESCRIPTION
Application to be created cannot already exist.

.PARAMETER WebAppName
Name of the web application to be created.

.PARAMETER WebAppPath
Path on the disk where application files are located.

.PARAMETER WebPoolName
Name of the web pool to be used by the application. 
If not provided then DefaultAppPool will be used.

.PARAMETER WebSiteName
Name of the web site into which newly created application should be added.
If not provided web application will be created in Default Web Site,

.EXAMPLE
Add-VSOFTWebApp -WebAppName "MyApp" -WebAppPath "D:\web\MyApp"
#>
function Add-VSOFTWebApp ([Parameter(Mandatory = $true)] [string]$WebAppName,
                          [Parameter(Mandatory = $true)] [string]$WebAppPath,
                                                         [string]$WebPoolName,
                                                         [string]$WebSiteName)
{
  Write-VSOFTLog "Begining adding Web Application $webAppName"
  if (!$webSiteName)
  {
    Write-VSOFTLog "Web Site name was not provided. Default 'Default Web Site' will be used" Debug
    $webSiteName = "Default Web Site"
  }
  if (!$webPoolName)
  {
    Write-VSOFTLog "Application pool name was not provided. Default value DefaultAppPool will be used" Debug
    $webPoolName = "DefaultAppPool"
  }
  Write-VSOFTLog "Adding IIS Web Application $webAppName with Aplication Pool $webPoolName in Web Site $webSiteName"

  if ((Get-IISVersion) -lt 7)
  {
      Write-VSOFTLog "IIS earlier than 7 is not supported." Error
  }
  try
  {
      Write-VSOFTLog "Creating new application $webAppName in web site $webSiteName"
      if (!(Test-Path "IIS:\Sites\$webSiteName")) # Web Site doest not exist 
      {
        Write-VSOFTLog "Web Site $webSiteName does not exist" Error
      }

      $app = New-WebApplication -Site $webSiteName -Name $webAppName -PhysicalPath $webAppPath -ApplicationPool $webPoolName 
      Write-VSOFTLog "Application $webAppName was successfully added to $webSiteName"
  }
  catch
  {
    Write-VSOFTLog ($_.Exception.Message) Error
  }
}




<#
.SYNOPSIS
Function removes web application from IIS.

.DESCRIPTION
If such web application to be removed does not exist function will log such fact and return success.


.PARAMETER WebAppName
Name of the web application to be removed.

.PARAMETER WebSiteName
Name of the web site that contains web application to be removed. If not provided web application will be removed from Default Web Site,

.EXAMPLE
Remove-VSOFTWebApp -WebAppName "MyApp" -WebSiteName "MySite"
#>

function Remove-VSOFTWebApp ([Parameter(Mandatory = $true)] [string]$WebAppName,
                                                            [string]$WebSiteName)
{
  Write-VSOFTLog "Begining removing Web Application $webAppName"
  if (!$webSiteName)
  {
    Write-VSOFTLog "Web Site name was not provided. Default 'Default Web Site' will be used" Debug
    $webSiteName = "Default Web Site"
  }
  if ((Get-IISVersion) -lt 7)
  {
      Write-VSOFTLog "IIS earlier than 7 is not supported." Error
  }
  try
    {
      Write-VSOFTLog "Removing IIS application $webAppName from web site $webSiteName"
      if ((Test-Path "IIS:\Sites\$webSiteName\$webAppName"))
      {
        Remove-WebApplication -Name $webAppName -Site $webSiteName 
        Write-VSOFTLog "Application $webAppName was successfully deleted from Web Site $webSiteName"
      }
      else
      {
        Write-VSOFTLog "Cannot delete application $webAppName from Web Site $webSiteName. Application doesn't exist" Debug
      }
  }
  catch
  {
    Write-VSOFTLog ($_.Exception.Message) Error
  }
}


<#
.SYNOPSIS
Function configures IIS to use SSL/TLS Best Practices

.DESCRIPTION
The function perform several registry modifications to make following configuration changes:
Disable Multi-Protocol Unified Hello 
Disable PCT 1.0 
Disable SSL 2.0 (PCI Compliance) 
Disable SSL 3.0 (PCI Compliance) and enable "Poodle" protection 
Add and Enable TLS 1.2 for client and server SCHANNEL communications 

.EXAMPLE
Update-VSOFTIISConfigurationForTLS
#>
function Update-VSOFTIISConfigurationForTLS
{

  Write-VSOFTLog 'Configuring IIS with SSL/TLS Deployment Best Practices...'
 
  # Disable Multi-Protocol Unified Hello
  New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\Multi-Protocol Unified Hello\Server' -Force | Out-Null
  New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\Multi-Protocol Unified Hello\Server' -name Enabled -value 0 -PropertyType 'DWord' -Force | Out-Null
  New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\Multi-Protocol Unified Hello\Server' -name 'DisabledByDefault' -value 1 -PropertyType 'DWord' -Force | Out-Null
  New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\Multi-Protocol Unified Hello\Client' -Force | Out-Null
  New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\Multi-Protocol Unified Hello\Client' -name Enabled -value 0 -PropertyType 'DWord' -Force | Out-Null
  New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\Multi-Protocol Unified Hello\Client' -name 'DisabledByDefault' -value 1 -PropertyType 'DWord' -Force | Out-Null
  Write-VSOFTLog 'Multi-Protocol Unified Hello has been disabled.'
 
  # Disable PCT 1.0
  New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\PCT 1.0\Server' -Force | Out-Null
  New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\PCT 1.0\Server' -name Enabled -value 0 -PropertyType 'DWord' -Force | Out-Null
  New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\PCT 1.0\Server' -name 'DisabledByDefault' -value 1 -PropertyType 'DWord' -Force | Out-Null
  New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\PCT 1.0\Client' -Force | Out-Null
  New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\PCT 1.0\Client' -name Enabled -value 0 -PropertyType 'DWord' -Force | Out-Null
  New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\PCT 1.0\Client' -name 'DisabledByDefault' -value 1 -PropertyType 'DWord' -Force | Out-Null
  Write-VSOFTLog 'PCT 1.0 has been disabled.'
 
  # Disable SSL 2.0 (PCI Compliance)
  New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Server' -Force | Out-Null
  New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Server' -name Enabled -value 0 -PropertyType 'DWord' -Force | Out-Null
  New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Server' -name 'DisabledByDefault' -value 1 -PropertyType 'DWord' -Force | Out-Null
  New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Client' -Force | Out-Null
  New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Client' -name Enabled -value 0 -PropertyType 'DWord' -Force | Out-Null
  New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Client' -name 'DisabledByDefault' -value 1 -PropertyType 'DWord' -Force | Out-Null
  Write-VSOFTLog 'SSL 2.0 has been disabled.'
 
  # NOTE: If you disable SSL 3.0 the you may lock out some people still using
  # Windows XP with IE6/7. Without SSL 3.0 enabled, there is no protocol available
  # for these people to fall back. Safer shopping certifications may require that
  # you disable SSLv3.
  #
  # Disable SSL 3.0 (PCI Compliance) and enable "Poodle" protection
  New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Server' -Force | Out-Null
  New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Server' -name Enabled -value 0 -PropertyType 'DWord' -Force | Out-Null
  New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Server' -name 'DisabledByDefault' -value 1 -PropertyType 'DWord' -Force | Out-Null
  New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Client' -Force | Out-Null
  New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Client' -name Enabled -value 0 -PropertyType 'DWord' -Force | Out-Null
  New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Client' -name 'DisabledByDefault' -value 1 -PropertyType 'DWord' -Force | Out-Null
  Write-VSOFTLog 'SSL 3.0 has been disabled.'

  <# 
  # Add and Enable TLS 1.0 for client and server SCHANNEL communications
  New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Server' -Force | Out-Null
  New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Server' -name 'Enabled' -value '0xffffffff' -PropertyType 'DWord' -Force | Out-Null
  New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Server' -name 'DisabledByDefault' -value 0 -PropertyType 'DWord' -Force | Out-Null
  New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Client' -Force | Out-Null
  New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Client' -name 'Enabled' -value '0xffffffff' -PropertyType 'DWord' -Force | Out-Null
  New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Client' -name 'DisabledByDefault' -value 0 -PropertyType 'DWord' -Force | Out-Null
  Write-VSOFTLog 'TLS 1.0 has been enabled.'
 
  # Add and Enable TLS 1.1 for client and server SCHANNEL communications
  New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Server' -Force | Out-Null
  New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Server' -name 'Enabled' -value '0xffffffff' -PropertyType 'DWord' -Force | Out-Null
  New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Server' -name 'DisabledByDefault' -value 0 -PropertyType 'DWord' -Force | Out-Null
  New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Client' -Force | Out-Null
  New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Client' -name 'Enabled' -value '0xffffffff' -PropertyType 'DWord' -Force | Out-Null
  New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Client' -name 'DisabledByDefault' -value 0 -PropertyType 'DWord' -Force | Out-Null
  Write-VSOFTLog 'TLS 1.1 has been enabled.'
  #>
 
  # Add and Enable TLS 1.2 for client and server SCHANNEL communications
  New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Server' -Force | Out-Null
  New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Server' -name 'Enabled' -value '0xffffffff' -PropertyType 'DWord' -Force | Out-Null
  New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Server' -name 'DisabledByDefault' -value 0 -PropertyType 'DWord' -Force | Out-Null
  New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Client' -Force | Out-Null
  New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Client' -name 'Enabled' -value '0xffffffff' -PropertyType 'DWord' -Force | Out-Null
  New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Client' -name 'DisabledByDefault' -value 0 -PropertyType 'DWord' -Force | Out-Null
  Write-VSOFTLog 'TLS 1.2 has been enabled.'
}




<#
.SYNOPSIS
Function starts Windows service

.DESCRIPTION

.PARAMETER  ServiceName
Name of the service to be started. 

.PARAMETER  Timeout
Amount of time to wait for the service to be started. 
Default value 00:00:30

.EXAMPLE
Start-VSOFTService -ServiceName "MyService" 

#>
function Start-VSOFTService ([Parameter(Mandatory = $true)] [string]$ServiceName, [Parameter(Mandatory = $false)] [string]$Timeout = '00:00:30')
{
  Write-VSOFTLog "Starting service $serviceName"
  try
  {
    $service = Get-Service -Name $serviceName
    Start-Service $serviceName
    $service.WaitForStatus("Running",$Timeout)
    Write-VSOFTLog "Service was started successfully"
  }
  catch
  {
    Write-VSOFTLog ($_.Exception.Message) Error
  }
}


<#
.SYNOPSIS
Function stops Windows service

.DESCRIPTION

.PARAMETER  ServiceName
Name of the service to be stopped. 

.PARAMETER  Timeout
Amount of time to wait for the service to be stopped. 
Default value 00:00:30


.EXAMPLE
Stop-VSOFTService -ServiceName "MyService" 

#>
function Stop-VSOFTService ([Parameter(Mandatory = $true)] [string]$ServiceName, [Parameter(Mandatory = $false)] [string]$Timeout = '00:00:30')
{
  Write-VSOFTLog "Stopping service $serviceName"
  try
  {
    $service = Get-Service -Name $serviceName -ErrorAction SilentlyContinue
    if ($service)
    {
      Stop-Service $serviceName
      $service.WaitForStatus("Stopped",$Timeout)
      Write-VSOFTLog "Service was stopped successfully"
    }
    else
    {
      Write-VSOFTLog "Service $serviceName not found" Warn
    }
  }
  catch
  {
    Write-VSOFTLog ($_.Exception.Message) Error
  }

}


<#
.SYNOPSIS
Function installs new Windows service.

.DESCRIPTION

.PARAMETER  ServiceName
Name of the service.
 
.PARAMETER  ExePath
Path to the executable that should run as service

.PARAMETER  Parameters
Parameters of the executable.

.PARAMETER  DisplayName
Display name of the service.

.PARAMETER  Description
Description of the service.
 
.PARAMETER  StartupType
Startup type of the service.

.PARAMETER  Credential
Credential of the user to be used to run the service.
 
.PARAMETER  DependsOn
List of service names that should be added as service dependencies.

.PARAMETER  AllowInteractWithDesktop
Configures service to be interactive with deskop. This can only be used with LocalSystem account so Credential parameter must be empty.

.PARAMETER  AddServiceNameParameter
If provided special parameter is added to service: -servicename:<ServiceName>. This may be required for some services.

.EXAMPLE
Install-VSOFTService -ServiceName "MyService" -ExePath "C:\MyService\MyService.exe" 
#> 
function Install-VSOFTService ([Parameter(Mandatory = $true)] [string] $ServiceName,
                               [Parameter(Mandatory = $true)] [string] $ExePath,
                                                              [string] $Parameters,
                                                              [string] $DisplayName,
                                                              [string] $Description,
                                                              [string] $StartupType,
                           [System.Management.Automation.Credential()] 
                           [System.Management.Automation.PSCredential] $Credential = [System.Management.Automation.PSCredential]::Empty, 
                                                            [string[]] $DependsOn, 
                                                              [switch] $AllowInteractWithDesktop,
                                                              [switch] $AddServiceNameParameter)
{
  Write-VSOFTLog "Installing service $ServiceName"
  if (!$StartUpType)
  {
    Write-VSOFTLog "Service startup type was not provided. Service will install with Automatic startup type" Debug
    $StartupType = "Automatic"
  }
  $StartUpTypeAutomaticDelayed = $false
  if ($StartUpType -eq "AutomaticDelayedStart") {
    $StartUpTypeAutomaticDelayed = $true
    $StartUpType = "Automatic"
  }
  if (!$DisplayName)
  {
    Write-VSOFTLog "Service display name was not provided. Service will install with Service Name" Debug
    $DisplayName = $ServiceName
  }
  if (!$Description)
  {
    $Description = $DisplayName
  }
  if ($DependsOn)
  {
    try
    {
       Get-Service $DependsOn | Out-Null
    }
    catch
    {
       Write-VSOFTLog ($_.Exception.Message) Warning
       Write-VSOFTLog "Unable to find service to create service dependency" Error
    }

  }
  # tutaj dodac sprawdzanie czy istnieje plik $ExePath
  if (!(Test-Path $ExePath -PathType Leaf))
  {
     Write-VSOFTLog "File $ExePath not found" Error
  }
  try
  {
    $BinaryPathName = "$ExePath $Parameters"
    if ($AddServiceNameParameter)
    {
      $BinaryPathName += " -servicename:$ServiceName"
    }
    if (($Credential) -and ($Credential -ne [System.Management.Automation.PSCredential]::Empty))
    {
      $service = New-Service -Name $ServiceName -BinaryPathName $BinaryPathName -DisplayName $DisplayName -Description $Description -DependsOn $DependsOn -StartupType $StartupType -Credential $Credential
    }
    else
    {
      $service = New-Service -Name $ServiceName -BinaryPathName $BinaryPathName -DisplayName $DisplayName -Description $Description -DependsOn $DependsOn -StartupType $StartupType 
    }
    if ($StartUpTypeAutomaticDelayed) {
      sc.exe config $ServiceName start= "delayed-auto"
    }
    if ($AllowInteractWithDesktop)
    {
       if (($Credential) -and ($Credential -ne [System.Management.Automation.PSCredential]::Empty))
       {
          Write-VSOFTLog "AllowInteractWithDesktop paramater cannot be used together with Credential" Error
       }
       $svcRegKey = Get-Item "HKLM:\SYSTEM\CurrentControlSet\Services\$ServiceName"
       #Ustawiamy odpowiedni bit zmieniajac typ serwisu as w enum System.ServiceProcess.ServiceType
       $newType = $svcRegKey.GetValue('Type') -bor 0x100
       Set-ItemProperty $svcRegKey.PSPath -Name Type -Value $newType
    }
  }
  catch
  {
    Write-VSOFTLog ($_.Exception.Message) Error
  }

  Write-VSOFTLog "Service $serviceName successfully installed"

}



<#
.SYNOPSIS
Function removes existing Windows service.

.DESCRIPTION
Service is first stopped and then removed.

.PARAMETER  ServiceName
Name of the service to be removed.

.EXAMPLE
Remove -VSOFTService -ServiceName "MyService"  

#> 
function Remove-VSOFTService ([Parameter(Mandatory = $true)] [string]$ServiceName)
{
  Write-VSOFTLog "Removing service $serviceName"

  try
  {
    $service = Get-Service -Name $serviceName -ErrorAction SilentlyContinue
    if ($service)
    {
      Stop-VSOFTService $serviceName
      $serviceWMI = Get-WmiObject -Class Win32_Service -Filter "Name='$serviceName'"
      $serviceWMI.Delete() | Out-Null
      Write-VSOFTLog "Service $serviceName was successfully deleted"
    }
    else
    {
      Write-VSOFTLog "Service $serviceName cannot be deleted. Service is not installed in system"
    }
  }
  catch
  {
    Write-VSOFTLog ($_.Exception.Message) Error
  }

}


<#
.SYNOPSIS
Function updates element of the xml configuration file.

.DESCRIPTION
Function can replace value of the attribute or inner xml of specified node.
You can pass hash table of XPath addresses and their values or XPath and value of single setting to be modified. 
 

.PARAMETER  ConfigFileName 
File name of the ini configuration file to be modified.
 
.PARAMETER Settings 
Hash table with XPath addresses and values to be modified.

.PARAMETER  SettingXPath
XPath address of the xml element to be updated. Can point to xml node or xml attribute.

.PARAMETER  NewValue
Value of the entry. Can be new value of the attribute or xml element to be inserted into the node.


.EXAMPLE
$settings = @{"configuration/a"=1; "configuration/b"=2}
#Update-VSOFTxmlConfig -ConfigFileName web.config -Settings $settings

.EXAMPLE
Update-VSOFTXmlConfig -ConfigFileName web.config -SettingXPath "/configuration/connectionStrings/add[@name=""CONNECT_STRING""]/@connectionString" -NewValue "connection string content"

.EXAMPLE
Update-VSOFTXmlConfig -ConfigFileName web.config -SettingXPath "/configuration/connectionStrings/add" -NewValue "<NewNode> Node content </NewNode>"
#>  
function Update-VSOFTXmlConfig ([Parameter(Mandatory = $true)] [string]$ConfigFileName,
                                                            [hashtable]$Settings,
                                                               [string]$SettingXPath,
                                                               [string]$NewValue)
{
  try
  {
    Write-VSOFTLog "Beginning of Update-VSOFTXmlConfig function"
    if (!$Settings)
    {
      if (!$SettingXPath -or !$NewValue)
      {
         Write-VSOFTLog "Either Settings hastable or SettingXPath and NewValue must be provided as parameters" Error
      }
      else
      {  
        $Settings = @{$SettingXPath = $NewValue}
      }
    }
    Write-VSOFTLog "Resolving $ConfigFileName into full filename" Debug
    $FullConfigFileName = Resolve-Path $ConfigFileName
    Write-VSOFTLog "Loading content of xml config file: $FullConfigFileName"
    $xml = [xml](Get-Content $FullConfigFileName)
    foreach ($setting in $Settings.GetEnumerator())
    {
      $SettingXPath = $setting.Key
      $NewValue = $setting.Value
      Write-VSOFTLog "Attempting to update element $SettingXPath with value $NewValue in file $ConfigFileName"
      Write-VSOFTLog "Looking for XPath: $SettingXPath" Debug
      $element = $xml | Select-Xml $SettingXPath
      if (!$element)
      {
        Write-VSOFTLog "Element $SettingXPath not found in xml" Error
      }
      $element = $element.Node
      if ($element.NodeType -eq [System.Xml.XmlNodeType]::Attribute)
      {
        Write-VSOFTLog "Old value of the Attribute: $($element.'#text')" Debug
        Write-VSOFTLog "Updating to new value: $NewValue" Debug
        $element.InnerText = $NewValue
      }

      if ($element.NodeType -eq [System.Xml.XmlNodeType]::Element)
      {
        Write-VSOFTLog "Old value of the Node: $($element.InnerXml)" Debug
        Write-VSOFTLog "Updating to new value: $NewValue" Debug
        $element.InnerXml = $NewValue
      }
    }
    Write-VSOFTLog "Saving updated xml config file: $FullConfigFileName" Debug
    $xml.Save($FullConfigFileName)
    Write-VSOFTLog "Configuration file $FullConfigFileName has been correctly updated."
  }
  catch
  {
    Write-VSOFTLog ($_.Exception.Message) Error
  }
}


<#
.SYNOPSIS
Function removes element from the xml configuration file.

.DESCRIPTION
Function can remove xml node or xml attribute.

.PARAMETER  ConfigFileName 
File name of the xml configuration file to be modified.
 
.PARAMETER  SettingXPath
XPath address(es) of the xml node or attribute to be removed.

.EXAMPLE
Remove-VSOFTXmlConfigNode -ConfigFileName "MyConfig.xml" -SettingXPath "/configuration/connectionStrings/add/ToBeRemoved"

.EXAMPLE
Remove-VSOFTXmlConfigNode -ConfigFileName "MyConfig.xml" -SettingXPath "/configuration/@attribute"
#>  
function Remove-VSOFTXmlConfigNode ([Parameter(Mandatory = $true)] [string]  $ConfigFileName,
                                    [Parameter(Mandatory = $true)] [string[]]$SettingXPath)
{
  try
  {
    Write-VSOFTLog "Beginning of Remove-VSOFTXmlConfigNode function"
    Write-VSOFTLog "Resolving $ConfigFileName into full filename" Debug
    $FullConfigFileName = Resolve-Path $ConfigFileName
    Write-VSOFTLog "Loading content of xml config file: $FullConfigFileName"
    $xml = [xml](Get-Content $FullConfigFileName)
    $savefile = $false
    foreach ($XPath in $SettingXPath)
    {
      Write-VSOFTLog "Looking for XPath to remove: $XPath" Debug
      $elementToRemove = ($xml | Select-Xml $XPath)
      if ($elementToRemove)
      {
        Write-VSOFTLog "XML element found - removing" Debug
        $elementToRemove = $elementToRemove.Node
        if ($elementToRemove.NodeType -eq [System.Xml.XmlNodeType]::Element)
        {
          $parent = $elementToRemove.ParentNode
          $removed = $parent.RemoveChild($elementToRemove)
          $savefile = $true
        }
        if ($elementToRemove.NodeType -eq [System.Xml.XmlNodeType]::Attribute)
        {
           $parent = $elementToRemove.OwnerElement
           $parent.RemoveAttribute($elementToRemove.Name)
           $savefile = $true
        }
      }
    }
    if ($savefile)
    {
      Write-VSOFTLog "Saving updated xml config file: $FullConfigFileName"
      $xml.Save($FullConfigFileName)
      Write-VSOFTLog "Configuration xml file $FullConfigFileName was correctly updated."
    }
    else
    {
      Write-VSOFTLog "XML element not found - nothing to remove" Debug
    }
  }
  catch
  {
    Write-VSOFTLog ($_.Exception.Message) Error
  }
}



<#
.SYNOPSIS
Function updates or adds entry and value to the ini configuration file.

.DESCRIPTION
Function can change existing entry (in any section) or add new one (only in the main section).
You can pass hash table of entry names and their values or name and value of single entry to be modified. 

Limitation
Adding new entries is supported only at the beginning of the file (with blank section name)

.PARAMETER  ConfigFileName 
File name of the ini configuration file to be modified. 
If such file does not exists - it will be created.
 
.PARAMETER  Entries
Hash table with entry names and values to be modified.

.PARAMETER  EntryName 
Name of the entry to be updated or added.

.PARAMETER  NewValue
Value of the entry.


.PARAMETER  SectionName 
Name of the section that contains entry to be updated. 
If not specified entry will be updated the top section of the file.
If "*" is provided then entries will be updated in all sections.

.EXAMPLE
$MyEntries = @{"MyEntry1" = "MyValue1"; "MyEntry2" = "MyValue2"}
Update-VSOFTIniConfig -ConfigFileName "MyConfig.ini" -Entries $MyEntries

.EXAMPLE
Update-VSOFTIniConfig -ConfigFileName "MyConfig.ini" -EntryName "MyEntry" -NewValue "MyValue"

#> 
function Update-VSOFTIniConfig ([Parameter(Mandatory = $true)]  [string]$ConfigFileName,
                                                             [hashtable]$Entries,
                                                                [string]$EntryName,
                                                                [string]$NewValue, 
                                                                [string]$SectionName="")
{
  try 
  {
    Write-VSOFTLog "Beginning of Update-IniConfig function"
    if (!$Entries)
    {
      if (!$EntryName -or !$NewValue)
      {
         Write-VSOFTLog "Either Entries hastable or EntryName and NewValue must be provided as parameters" Error
      }
      else
      {  
        $entries = @{$EntryName = $NewValue}
      }
    }
    if (!(Test-Path $ConfigFileName))
    {
       Write-VSOFTLog "INI file $ConfigFileName not found - creating new one" Info
       New-Item $ConfigFileName -ItemType File | Out-Null
    }
    $FullConfigFileName = Resolve-Path $ConfigFileName
    Write-VSOFTLog "Loading INI file $FullConfigFileName" Debug
    [System.Collections.ArrayList] $IniEntries = Get-IniEntries $FullConfigFileName

    $saveFile = $false
    foreach ($entry in $entries.GetEnumerator())
    {
      $EntryName = $entry.Key
      $newValue = $entry.Value
      Write-VSOFTLog "Attempting to update entry $SectionName\$EntryName in file $ConfigFileName"
      $entryFound = $false
      for ($i = 0; $i -lt $IniEntries.Count ; $i++)
      {
        if (($IniEntries[$i].Type -eq "Key") -and ($IniEntries[$i].Key -eq $EntryName) -and (($IniEntries[$i].Section -eq $SectionName) -or ($SectionName -eq "*")))
        {
           $entryFound = $true
           if ($IniEntries[$i].Value -eq $NewValue)
           {
             Write-VSOFTLog "Entry $SectionName\$EntryName found in line $($i+1) - with old value matching new value" Debug
           }
           else
           {
             Write-VSOFTLog "Entry $SectionName\$EntryName found in line $($i+1) - replacing old value" Debug
             $IniEntries[$i].Value = $NewValue 
             $saveFile = $true
           }
        }
      }
      if (!$entryFound)  #entry not found
      {
        if (($SectionName -ne "") -and ($SectionName -ne "*"))
        {
           Write-VSOFTLog "Adding new INI entries into section is not supported at the moment" Error
        }
        else
        {
           Write-VSOFTLog "Entry not found in file - adding new one at the begining of file" Debug
           $IniEntries.Insert(0,[pscustomobject]@{Type="Key";Section="";Key=$EntryName;value=$NewValue}) | Out-Null
           $savefile = $true
        }
      }
    }
    if ($savefile)
    {
       Write-VSOFTLog "Saving updated INI file"
       Save-IniEntries $IniEntries $FullConfigFileName
    }
  }
  catch
  {
    Write-VSOFTLog ($_.Exception.Message) Error
  }
}





<#
.SYNOPSIS
Function removes entry and its value from the ini configuration file.

.DESCRIPTION

.PARAMETER  ConfigFileName 
File name of the ini configuration file to be modified.
 
.PARAMETER  EntryName 
Name(s) of the entry to be removed.

.PARAMETER  SectionName 
Name of the section that contains entry to be removed. 
If not specified entry will be removed from the top of the file (before any named section).
If * is provided as value then entry will be removed from all sections.

.EXAMPLE
Remove-VSOFTIniConfigEntry -ConfigFileName "MyConfig.ini" -EntryName "MyEntry"

#>
function Remove-VSOFTIniConfigEntry ([Parameter(Mandatory = $true)] [string]  $ConfigFileName,
                                     [Parameter(Mandatory = $true)] [string[]]$EntryName, 
                                                                    [string]  $SectionName="")
{
  try
  {
    Write-VSOFTLog "Beginning of Remove-IniConfigEntry function"
    $FullConfigFileName = Resolve-Path $ConfigFileName
    Write-VSOFTLog "Loading INI file $FullConfigFileName" Debug
    [System.Collections.ArrayList] $IniEntries = Get-IniEntries $FullConfigFileName
    $saveFile = $false
    foreach ($Name in $EntryName)
    {
      Write-VSOFTLog "Attempting to remove entry $SectionName\$Name from file $ConfigFileName"
      for ($i = $IniEntries.Count - 1; $i -ge 0; --$i)
      {
        if (($IniEntries[$i].Type -eq "Key") -and ($IniEntries[$i].Key -eq $Name) -and (($IniEntries[$i].Section -eq $SectionName) -or ($SectionName -eq "*")))
        {
           Write-VSOFTLog "Entry found in line $($i+1) - removing"
           $IniEntries.RemoveAt($i) | Out-Null
           $saveFile = $true
        }
      }
    }
    if ($savefile)
    {
       Write-VSOFTLog "Saving updated INI file"
       Save-IniEntries $IniEntries $FullConfigFileName
    }
  }
  catch
  {
    Write-VSOFTLog ($_.Exception.Message) Error
  }
}



<#
.SYNOPSIS
Function removes all comments from ini configuration file.

.DESCRIPTION

.PARAMETER  ConfigFileName 
File name of the ini configuration file.

.EXAMPLE
Remove-VSOFTIniConfigComments -ConfigFileName "MyConfig.ini"
#> 
function Remove-VSOFTIniConfigComments ([Parameter(Mandatory = $true)] [string]$ConfigFileName)
{
  try
  {
    Write-VSOFTLog "Beginning of Remove-IniConfigComments function"
    $FullConfigFileName = Resolve-Path $ConfigFileName
    Write-VSOFTLog "Loading INI file $FullConfigFileName" Debug
    [System.Collections.ArrayList] $IniEntries = Get-IniEntries $FullConfigFileName
    $saveFile = $false
    for ($i = $IniEntries.Count - 1; $i -gt 0; --$i)
    {
      if ($IniEntries[$i].Type -eq "Comment") 
      {
         $IniEntries.RemoveAt($i) | Out-Null
         $saveFile = $true
      }
    }
    if ($savefile)
    {
       Write-VSOFTLog "Saving updated INI file"
       Save-IniEntries $IniEntries $FullConfigFileName
    }
    else
    {
      Write-VSOFTLog "Comments not found - no need to save file" Debug
    }

  }
  catch
  {
    Write-VSOFTLog ($_.Exception.Message) Error
  }
}



Function Save-IniEntries (
        [Parameter(Mandatory=$True)]  
        [System.Collections.ArrayList]$IniEntries,  
        [Parameter(Mandatory=$True)]  
        [string]$FilePath
    )  
{     
try
  {
        $outFile = New-Item -ItemType file -Path $Filepath -Force
        foreach ($entry in $IniEntries)  
        {  
            if ($entry.Type -eq "Key")  
            {  
                Add-Content -Path $outFile -Value "$($Entry.Key) = $($Entry.Value)" -Encoding UTF8
            } 
            else 
            {  
                Add-Content -Path $outFile -Value "$($Entry.Value)" -Encoding UTF8
            }  
        }  
        Write-VSOFTLog "Saved $($IniEntries.Count) lines to INI file" Debug
  }
  catch
  {
    Write-VSOFTLog ($_.Exception.Message) Error
  }

          
} 


Function Get-IniEntries(  
        [Parameter(Mandatory=$True)]  
        [string]$FilePath  
    )  
{      
try
  {
        $section = ""
        [System.Collections.ArrayList] $IniEntries = @()
        switch -regex (Get-Content $FilePath)
        {  
            "^\[(.+)\]$" # Section  
            {  
                $section = $matches[1]
                $IniEntries.Add([pscustomobject]@{Type="Section";Section=$section;Key="";Value="[$($matches[1])]"}) | Out-Null
                continue
            }  
            "^(;.*)$" # Comment  
            {  
                $IniEntries.Add([pscustomobject]@{Type="Comment";Section=$section;Key="";Value=$matches[1]}) | Out-Null
                continue
            }   
            "(.+?)\s*=\s*(.*)" # Key  
            {  
                $IniEntries.Add([pscustomobject]@{Type="Key";Section=$section;Key=$matches[1];value=$matches[2]}) | Out-Null
                continue
            }  
            default
            {
                $IniEntries.Add([pscustomobject]@{Type="Other";Section=$section;Key="";value=$_}) | Out-Null
                continue
            }
        }  
        Write-VSOFTLog "Loaded $($IniEntries.Count) lines from INI file" Debug
        Return ,$IniEntries
  }
  catch
  {
    Write-VSOFTLog ($_.Exception.Message) Error
  }

} 

<#
.SYNOPSIS
Function replaces content of the text file using regex search and replace.
All found occurrences are replaced

.DESCRIPTION


.PARAMETER  FileName 
File name of the file containing content to be searched and replaced.

.PARAMETER  Search 
Regex expression to be searched for.

.PARAMETER  Replace 
Regex expression to be replaced for.

 
.EXAMPLE
Update-VSOFTReplaceRegexInFile "file.txt" 'old' 'new'

.EXAMPLE
Update-VSOFTReplaceRegexInFile "file.txt" '(pre).*(post)' '$1 new $2'

#> 
function Update-VSOFTReplaceRegexInFile ( [Parameter(Mandatory = $true)][string] $FileName, 
                                          [Parameter(Mandatory = $true)][string] $Search, 
                                          [Parameter(Mandatory = $true)][string] $Replace)
{
  try
  {
    Write-VSOFTLog "Resolving $FileName into full filename" Debug
    $FullFileName = Resolve-Path $FileName
    Write-VSOFTLog "Loading content of file: $FullFileName"
    $content = Get-Content $FullFileName -Raw
    Write-VSOFTLog "Looking for expression: $Search" Debug
    $found = $content -match $Search
    if (!$found)
    {
      Write-VSOFTLog "Expression $Search not found in the file $FullFileName" Warn
      return
    }
      else
    {
      Write-VSOFTLog "Expression $Search found in the file with following matches:" 
      foreach ($match in $Matches.GetEnumerator())
      {
         Write-VSOFTLog "$($match.Name) $($match.Value)"
      }
    }
    Write-VSOFTLog "Replacing $Search with $Replace" 
    $newContent = $content -replace $Search, $Replace 
    Write-VSOFTLog "Saving updated file: $FullFileName" Debug
    Set-Content  $FullFileName -value $Newcontent
  }
  catch
  {
    Write-VSOFTLog ($_.Exception.Message) Error
  }
}


<#
.SYNOPSIS
Function checks if provided connection string allows connecting to the SQL Server.

.DESCRIPTION
Function take connection string and initiates connection to check is the connection string is valid. No operations on the database are performed so no special permissions are validated other than open connection. 

.PARAMETER  ConnectionString 
Connection string to be validated.

 
.EXAMPLE
Test-VSOFTSQLConnection "Data source=TestServer\TestInstance;Integrated Security=true;Initial catalog=MyDatabase"

#>  
function Test-VSOFTSQLConnection([Parameter(Mandatory=$true)] [string] $ConnectionString)
{
  Write-VSOFTLog "Checking connection for connection string: $ConnectionString"       
  try
  {
    $sqlConnection = New-Object System.Data.SqlClient.SqlConnection $ConnectionString;
    $sqlConnection.Open();
    $sqlConnection.Close();
  }
  catch
  {
    Write-VSOFTLog ($_.Exception.Message) Error
  }
}



<#
.SYNOPSIS
Executes VSoft DbUpgrader tool and passes all parameters to it.

.DESCRIPTION
Function takes all parameters and converts them into command line parameters required to call VSoft DbUpgrader. Captures output and results of execution of the VSoft DbUpgrader.

.PARAMETER  DbUpgraderFolder 
Path to folder where VSoft DbUpgrader program executable is located.

.PARAMETER ScriptsFolder 
Path to folder where SQL scripts are located.

.PARAMETER Databases 
Hashtable with names and connection strings of the databases to be upgraded. Database names must match root folder names in scripts folder. 

.PARAMETER Variables 
Hashtable with names and values of the variables used in SQL scripts.

.PARAMETER VariablesIniFile 
Path to .INI file that contains variables and values used in SQL scripts.

.PARAMETER  VariablesDatabase 
Connection string to the database that contains CONFIG_KEYS tables with variables and values used in SQL scripts.

.PARAMETER  InitializationMode 
Enables Initialization Mode.
Execution of scripts without versioning and tracking. Executes only scripts from folder !INITIALIZATION.

.PARAMETER  WhatIfMode 
Enables What If Mode.
Only displays scripts to be executed, does not execute upgrade scripts on database(s).

.PARAMETER  AppendLastVersionMode 
Enables Append Last Version Mode.
Upgrade database in special development mode that checks if version already applied in database contains any new scripts on disk. 
If such scripts are detected they are appended to the existing version in database even if the version was previously completed. 
This mode is intended for usage only in Continuous Integration process.
ts.

.PARAMETER  ExtensiveMode 
Enables Extensive Mode.
Force to run even empty upgrade procedure (contatins only !BEGIN and !FINISH scripts) on database.

.EXAMPLE
$dbs = @{
  "DATA" = "Data source=xxxx";
  "CONFIG" = "Data source=xxxx";
}
$vars = @{"variable1"="value1"; "variable2"="value2"}
$configDb="Data source=xxxx"

Invoke-VSOFTDbUpgrader -DbUpgraderFolder "Database\Program" -ScriptsFolder "Database\Scripts" -Databases $dbs -WhatIfMode -variables $vars -VariablesIniFile "variables.ini" -VariablesDatabase $configDb

#>  
function Invoke-VSOFTDbUpgrader([Parameter(Mandatory=$true)] [String] $DbUpgraderFolder,
                                [Parameter(Mandatory=$true)] [String] $ScriptsFolder,
                                [Parameter(Mandatory=$true)] [Hashtable] $Databases,
                                [Parameter(Mandatory=$false)] [Hashtable] $DatabaseProviders,
										  [Hashtable] $Variables,      
										  [String] $VariablesIniFile,      
										  [String] $VariablesDatabase,      
                                [switch] $InitializationMode,
                                [switch] $WhatIfMode,
                                [switch] $AppendLastVersionMode,
                                [String[]] $ExtensiveDatabases,
                                [String] $LogFilePath,
                                [String] $AccessToken,
                                [String[]] $MaskedVariables      
)
{
  Write-VSOFTLogHeader "Excuting database upgrader" 1
  
  $DbUpgraderProgram = join-path $DbUpgraderFolder "VSoft.DbUpgrader.exe"
  $DbUpgraderParams = @()
  $DbUpgraderParams += "-s" , "$ScriptsFolder"

  if ($InitializationMode)
  {
    $DbUpgraderParams += "-i"
  }
  if ($WhatIfMode)
  {
    $DbUpgraderParams += "-w"
  }
  if ($AppendLastVersionMode)
  {
    $DbUpgraderParams += "-a"
  }
  foreach ($database in $databases.GetEnumerator())
  {
    $DbUpgraderParams += "-d", "$($database.Name):$($database.Value)"
  }
  if ($null -ne $DatabaseProviders) {
    foreach ($provider in $DatabaseProviders.GetEnumerator())
    {
       $DbUpgraderParams += "-p", "$($provider.Name):$($provider.Value)"
    }
  }
  if ($Variables)
  {
	  foreach ($variable in $Variables.GetEnumerator())
	  {
		 $DbUpgraderParams += "--var", "$($variable.Name):$($variable.Value)"
	  }
  }
  if ($MaskedVariables)
  {
	  foreach ($maskedVariable in $MaskedVariables.GetEnumerator())
	  {
		 $DbUpgraderParams += "--varMasked", "$($maskedVariable)"
	  }
  }
  if ($VariablesIniFile)
  {
    $DbUpgraderParams += "--varINI", $VariablesIniFile
  }
  if ($VariablesDatabase)
  {
    $DbUpgraderParams += "--varDatabase", $VariablesDatabase
  }
  if ($ExtensiveDatabases)
  {
	  foreach ($extensiveDatabase in $ExtensiveDatabases.GetEnumerator())
	  {
		 $DbUpgraderParams += "--Extensive", "$($extensiveDatabase)"
	  }
  }
  if ($LogFilePath)
  {
    $DbUpgraderParams += "--log", "$LogFilePath"
  }
  if ($AccessToken)
  {
    $DbUpgraderParams += "--AccessToken", "$AccessToken"
  }

  & "$DbUpgraderProgram" $DbUpgraderParams | Write-VSOFTLog

  if ($lastexitcode -ne 0)
  {
    Write-VSOFTLog "Error occured while executing database upgrade process. Please fix the errors manually and run upgrade again to complete the operation." Error
  }
  else
  {
    Write-VSOFTLog "Database upgrade process completed sucesfully" 
  }
}










function Invoke-VSOFTSQLQuery(
[Parameter(Mandatory = $true)][string] $connectionString ,
[Parameter(Mandatory = $true)][string] $sqlCommand,
                              [hashtable] $sqlParamaters = @{}
      )
{
  try
  {  
    $connection = new-object system.data.SqlClient.SQLConnection($connectionString)
    $command = new-object system.data.sqlclient.sqlcommand($sqlCommand, $connection)
    foreach ($parameter in $sqlParamaters.GetEnumerator())
    {
      $command.Parameters.AddWithValue($parameter.Name, $parameter.Value) | Out-Null
    }
    $connection.Open()

    $adapter = New-Object System.Data.sqlclient.sqlDataAdapter($command)
    $dataset = New-Object System.Data.DataSet
    $adapter.Fill($dataSet) | Out-Null

    $connection.Close()
    $connection.Dispose()
    return ,$dataSet.Tables[0]
  }
  catch
  {
    Write-VSOFTLog ($_.Exception.Message) Error
  }

}


function Invoke-VSOFTSQLUpdate(
  [Parameter(Mandatory = $true)][string] $connectionString,
  [Parameter(Mandatory = $true)][string] $sqlCommand, 
                                [hashtable] $sqlParamaters = @{}
      )
{
  try
  {
    $connection = new-object system.data.SqlClient.SQLConnection($connectionString)
    $command = new-object system.data.sqlclient.sqlcommand($sqlCommand, $connection)
    foreach ($parameter in $sqlParamaters.GetEnumerator())
    {
      $command.Parameters.AddWithValue($parameter.Name, $parameter.Value) | Out-Null
    }
    $connection.Open()

    $rowsAffected = $command.ExecuteNonQuery()
    $connection.Close()
    $connection.Dispose()
    return $rowsAffected
  }
  catch
  {
    Write-VSOFTLog ($_.Exception.Message) Error
  }
}




function Get-VSOFTDBConfigKey(
 [Parameter(Mandatory = $true)][string] $connectionString,
 [Parameter(Mandatory = $true)][string] $KeyName,
                               [string] $NodeName 
      )
{
  try
  {
    Write-VSOFTLog "Getting DB config value for key=$KeyName and Node=$NodeName" 
    $query = "SELECT CK_VALUE FROM CONFIG_KEYS WHERE CK_KEY = @KeyName and CK_NODE_NAME = @NodeName"
    $parameters = @{"@KeyName" = "$KeyName";"@NodeName" = "$NodeName"}
    $Result = Invoke-VSOFTSQLQuery $connectionString $query $parameters
    switch ($Result.Rows.Count)
    {
      0 { 
          $value= ""
          break
        }
      1 { 
          $value = $Result.Rows[0]["CK_VALUE"]
          break
        }
      default 
        {
           Write-VSOFTLog "More than one value with key=$KeyName and Node=$NodeName returned" Error 
           break
        }
    }
    Return $value
  }
  catch
  {
    Write-VSOFTLog ($_.Exception.Message) Error
  }

}




function Update-VSOFTDBConfigKey(
 [Parameter(Mandatory = $true)][string] $ConnectionString,
 [Parameter(Mandatory = $true)][string] $KeyName,
 [Parameter(Mandatory = $true)]
 [AllowEmptyString()]          [string] $NewValue,
                               [string] $NodeName)
{
    try
    {
      Write-VSOFTLog "Updating DB config value for key=$KeyName and Node=$NodeName" 
      $query = "SELECT CK_VALUE FROM CONFIG_KEYS WHERE CK_KEY = @KeyName and CK_NODE_NAME = @NodeName"
      $parameters = @{"@KeyName" = "$KeyName";"@NodeName" = "$NodeName"}
      $Result = Invoke-VSOFTSQLQuery $ConnectionString $query $parameters
      switch ($Result.Rows.Count)
      {
        0 { 
            Write-VSOFTLog "Entry not found - adding new one" 
            $UpdateCommand = "INSERT INTO CONFIG_KEYS (CK_KEY, CK_VALUE, CK_NODE_NAME) VALUES (@KeyName, @NewValue, @NodeName)"
            break
          }
        1 { 
            Write-VSOFTLog "Entry found - updating to new value" 
            $UpdateCommand = "UPDATE CONFIG_KEYS SET CK_VALUE = @NewValue WHERE CK_KEY=@KeyName and CK_NODE_NAME = @NodeName" 
            break
          }
        default 
          {
            Write-VSOFTLog "More than one value with key=$KeyName and NODE=$NodeName returned" Error 
            break
          }
      }
      $parameters = @{"@KeyName" = "$KeyName";"@NodeName" = "$NodeName"; "@NewValue" = "$NewValue" }
      $RowsChanged = Invoke-VSOFTSQLUpdate $connectionString $UpdateCommand $parameters
      if ($RowsChanged -eq 1)
      {
        Write-VSOFTLog "Successfully updated DB config value"
      }
      else
      {  
        Write-VSOFTLog "Error while updating DB config value (updated rows=$RowsChanged)" Error
      }

    }
    catch
    {
      Write-VSOFTLog ($_.Exception.Message) Error
    }
}



<#
.SYNOPSIS
Function executes provided script remotely on provided servers in the loop.

.DESCRIPTION


.PARAMETER ServerNames
Array with names of the remote machines to execute script on. Can contain one or more names.

.PARAMETER Script
Text of the script to be executed remotely.
 
.EXAMPLE
Invoke-VSOFTRemotePSScript -ServerMames "server1"  -Script "dir" 

Invoke-VSOFTRemotePSScript -ServerMames ("server1" ,"server2") -Script "dir" 


#> 
function Invoke-VSOFTRemotePSScript (
  [Parameter(Mandatory = $true)] [string[]]$ServerNames,
  [Parameter(Mandatory = $true)] [string]$Script
)
{
  try
  {
    foreach ($server in $ServerNames)
    {
      Write-VSOFTLog "Executing remotely on machine $server, script: $Script   ===>"
      Invoke-Command -ComputerName $server -ArgumentList @( $Script) `
        -ScriptBlock {
           $scriptcommand = $args[0]
           Write-Verbose "Local execution of command: $scriptcommand" -verbose 4>&1
           Invoke-Expression $scriptcommand 4>&1
        } | Write-VSOFTLog
      Write-VSOFTLog " <=== End of remote script execution"
    }
  }
  catch
  {
    Write-VSOFTLog ($_.Exception.Message) Error
  }

}



<#
.SYNOPSIS
Function tests ability to invoke PowerShell script remotely on provided servers.
It perform execution of basic script do it check remote machine, connectivity, permissions, etc - everything that is  required to execute actual script.

.DESCRIPTION


.PARAMETER ServerNames
Array with names of the remote machines to execute script on. Can contain one or more names.

 
.EXAMPLE
Test-VSOFTRemotePSScript -ServerMames "server1" 

Test-VSOFTRemotePSScript -ServerMames ("server1" ,"server2") 
#> 
function Test-VSOFTRemotePSScript (
  [Parameter(Mandatory = $true)] [string[]]$ServerNames,
  [Parameter(Mandatory = $false)] [PSCredential]$Credential
)
{
  try
  {
    foreach ($server in $ServerNames)
    {
      Write-VSOFTLog "Testing ability to execute Powers Shell remotely on machine $server"
	  if ($Credential) {
		  Invoke-Command -ComputerName $server -Credential $Credential -ScriptBlock { hostname } | Out-Null
	  } else {
		Invoke-Command -ComputerName $server -ScriptBlock { hostname } | Out-Null
	  }
    }
  }
  catch
  {
    Write-VSOFTLog ($_.Exception.Message) Error
  }

}





<#
.SYNOPSIS
Function checks if provided Credential is valid.

.DESCRIPTION
Function checks if provided credential is valid. It first validates it on local machine and then on domain. At least one check must be positive.

.PARAMETER Credential
Credential to be validated.
 
.EXAMPLE
Test-VSOFTCredential Credential $MyServiceUser

#> 
function Test-VSOFTCredential (
  [Parameter(Mandatory = $true)]
  [ValidateNotNull()]
  [System.Management.Automation.PSCredential]
  [System.Management.Automation.Credential()]
  $Credential

)
{
  Add-Type -AssemblyName System.DirectoryServices.AccountManagement
  $PrincipalMachine = New-Object System.DirectoryServices.AccountManagement.PrincipalContext ([System.DirectoryServices.AccountManagement.ContextType]::Machine)
  $IsValidOnMachine = $PrincipalMachine.ValidateCredentials($credential.GetNetworkCredential().userName,$credential.GetNetworkCredential().password)

  $PrincipalDomain = New-Object System.DirectoryServices.AccountManagement.PrincipalContext ([System.DirectoryServices.AccountManagement.ContextType]::Domain)
  $IsValidOnDomain = $PrincipalDomain.ValidateCredentials($credential.GetNetworkCredential().userName,$credential.GetNetworkCredential().password)

  if ($IsValidOnMachine -or $IsValidOnDomain)
  {
    return $true
  }
  else
  {
    return $false
  }
}



<#
.SYNOPSIS
Function checks if provided Certificate exists and meets required criteria.

.DESCRIPTION


.PARAMETER CertThumbprint
Thumbprint of the certificate to be validated.

.PARAMETER StorePath
If provided certificate is searched only in specified path. If omitted all paths are analyzed.
Sample paths: \CurrentUser\My, \LocalMachine\CA, \LocalMachine\Trust

.PARAMETER CheckPrivateKey 
When set the certificate is checked to have private key.

.PARAMETER CheckServerAuthentication 
When set the certificate is checked if it supports Server Authentication. This is displayed as "Ensures the identity of a remote computer" in cerficate manager.

.PARAMETER ExpectedIssuedTo 
When provided this value is compared to certificate "IssuedTo" value. Error is reported when values do not match. 
Can be used to check is certificate contains proper server name with or without domain name.


 
.EXAMPLE
Test-VSOFTCertificate -CertThumbprint 45C800F4F4BBE0636EC76D473843E8E23E410914 -CheckPrivateKey 
Test-VSOFTCertificate -CertThumbprint 45C800F4F4BBE0636EC76D473843E8E23E410914 -StorePath "CurrentUser\My" -CheckPrivateKey 
Test-VSOFTCertificate -CertThumbprint 45C800F4F4BBE0636EC76D473843E8E23E410914 -StorePath "LocalMachine\My" -CheckPrivateKey -CheckServerAuthentication -ExpectedIssuedTo "myserver"


#>  
function Test-VSOFTCertificate (
  [Parameter(Mandatory = $true)]
  [string]$CertThumbprint,
  [string]$StorePath,
  [switch]$CheckPrivateKey,
  [switch]$CheckServerAuthentication,
  [string]$ExpectedIssuedTo,
  [switch]$WarningOnly
  )

{
  try
  {
    $FullStorePath = Join-Path "Cert:" $StorePath
    $CertThumbprint = $CertThumbprint.Replace(" ","")
    Write-VSOFTLog "Checking certificate with thumbprint $CertThumbprint in $FullStorePath." 
    $cert = Get-ChildItem -Path $FullStorePath -recurse | where { $_ -is [System.Security.Cryptography.X509Certificates.X509Certificate2]} | where {$_.Thumbprint -eq $CertThumbprint}
    
	$logLevel = "Error"
	if ($WarningOnly) {
		$logLevel = "Warning"
	}
	if (!$cert)
    {
        Write-VSOFTLog "Certificate with thumbprint $CertThumbprint not found in $FullStorePath." $logLevel
    } else {
		if ($CheckPrivateKey)
		{
		  if (!$cert.HasPrivateKey)
		  {
			Write-VSOFTLog "Certificate with thumbprint $CertThumbprint does not have private key." $logLevel
		  }
		}
		if ($CheckServerAuthentication)
		{
		  $ServerAuthentication = $cert.EnhancedKeyUsageList | where { $_.ObjectId -eq "1.3.6.1.5.5.7.3.1"} # { $_.FriendlyName -eq "Server Authentication"}
		  if (!$ServerAuthentication)
		  {
			Write-VSOFTLog "Certificate with thumbprint $CertThumbprint does support Server Authentication." $logLevel
		  }
		}
		if ($ExpectedIssuedTo)
		{
		  $CertIssuedTo = $cert.GetNameInfo( 'SimpleName', $false )
		  if ($CertIssuedTo -ne $ExpectedIssuedTo)
		  {
			Write-VSOFTLog "Certificate with thumbprint $CertThumbprint is issued to '$CertIssuedTo' instead of expected '$ExpectedIssuedTo'." $logLevel
		  }
		}
	}
  }
  catch
  {
    Write-VSOFTLog ($_.Exception.Message) Error
  }


}




<#
.SYNOPSIS
Function grants LogOnAsService right to specified Credential

.DESCRIPTION
Function grants LogOnAsService right to user specified as Credential. This allow running Windows services as this user.
Function modifies local security policy to achieve it.

.PARAMETER Credential
Credential of the user which should receive new permission (only UserName field is used).

.EXAMPLE
Grant-VSOFTLogOnAsService Credential $MyServiceUser

#> 
function Grant-VSOFTLogOnAsService(
  [System.Management.Automation.PSCredential]
  [System.Management.Automation.Credential()]
  $Credential = [System.Management.Automation.PSCredential]::Empty
)
{    

  if (!(($Credential) -and ($Credential -ne [System.Management.Automation.PSCredential]::Empty)))
  {
     Write-VSOFTLog "No changes in security policy are required as empty credential was passed." 
     return
  }
  try
  {
    $user = $Credential.UserName
    Write-VSOFTLog "Granting 'Log as Service' to user: $user" 
    $tempExportFile = [System.IO.Path]::GetTempFileName()
    $tempImportFile = [System.IO.Path]::GetTempFileName()
    $seceditDBFile =  "seceditDB"
    secedit /export /cfg $tempExportFile | Write-VSOFTLog
    $curSIDs = Select-String $tempExportFile -Pattern "SeServiceLogonRight" 
    $Sids = $curSIDs.line 
    $sidstring = ""
    $objUser = New-Object System.Security.Principal.NTAccount($user)
    $strSID = $objUser.Translate([System.Security.Principal.SecurityIdentifier])
    if(!$Sids.Contains($strSID) -and !$sids.Contains($user))
    {
        Write-VSOFTLog "Adding rights for new user: $user" Debug
        $sidstring += ",*$strSID"
    }
    if($sidstring)
    {
        $newSids = $sids + $sidstring
        $tempinf = Get-Content $tempExportFile
        $tempinf = $tempinf.Replace($Sids,$newSids)
        Add-Content -Path $tempImportFile -Value $tempinf 
        secedit /import /db $seceditDBFile /cfg $tempImportFile | Write-VSOFTLog
        if ($LASTEXITCODE)
        {
           Write-VSOFTLog "Error while calling secedit /import" Error
        }
        secedit /configure /db $seceditDBFile | Write-VSOFTLog
        if ($LASTEXITCODE)
        {
           Write-VSOFTLog "Error while calling secedit /configure" Error
        }
    }
    else
    {
        Write-VSOFTLog "No changes in security policy required" 
    }
    del $tempExportFile -force -ErrorAction SilentlyContinue
    del $tempImportFile -force -ErrorAction SilentlyContinue
    del $seceditDBFile -force -ErrorAction SilentlyContinue
    del "$seceditDBFile.jfm" -force -ErrorAction SilentlyContinue
  }
  catch
  {
    Write-VSOFTLog ($_.Exception.Message) Error
  }

}




<#
.SYNOPSIS
Function adds new access rule to specified file or directory.

.DESCRIPTION

.PARAMETER  Path 
File name or directory name to be modified. Wildcards are not permitted.
 
.PARAMETER  IdentityName 
Name of the identity (user name or group name) to be granted the rights.
Note that standard groups names can be localized on non-English version of Windows. Providing SID solves this issue.
Either IdentityName or IdentitySID parameter must be provided but not both.

.PARAMETER  IdentitySID 
SID of the identity (user name or group name) to be granted the rights.
Either IdentityName or IdentitySID parameter must be provided but not both.

Refer to following link for list of well-known security identifiers
https://support.microsoft.com/en-us/help/243330/well-known-security-identifiers-in-windows-operating-systems

.PARAMETER  FileSystemRights 
Comma separated list of the rights to be granted. 
See below link for list of possible names:
https://msdn.microsoft.com/en-us/library/system.security.accesscontrol.filesystemrights

.PARAMETER  AccessControlType 
Specified if the right should be allowed or denied.


.EXAMPLE
Add-VSOFTFileAccessRule -path D:\Logs -IdentityName "Domain\username" -FileSystemRights "FullControl"
.EXAMPLE
Add-VSOFTFileAccessRule -path D:\Logs -IdentitySID "S-1-1-0" -FileSystemRights "FullControl"
#>  
function Add-VSOFTFileAccessRule([Parameter(Mandatory = $true)] [string] $Path,
								                                [string] $IdentityName,
								                                [string] $IdentitySID,
								 [Parameter(Mandatory = $true)] [string] $FileSystemRights,
								 [ValidateSet("Allow", "Deny")]	[string] $AccessControlType = "Allow"
)
{
  try
  {
    if (!$IdentityName -and !$IdentitySID)
    {
       Write-VSOFTLog "Either IdentityName or IdentitySID paramater must be provided for Add-VSOFTFileAccessRule" Error
    }
    if ($IdentityName -and $IdentitySID)
    {
       Write-VSOFTLog "Either IdentityName or IdentitySID paramater must be provided but not both for Add-VSOFTFileAccessRule" Error
    }
    if ($IdentityName)
    {
      $Identity = $IdentityName
    }
    if ($IdentitySID)
    {
      Write-VSOFTLog "Geting user/group name for SID: $IdentitySID"
      $objSID = New-Object System.Security.Principal.SecurityIdentifier($IdentitySID) 
      $objUser = $objSID.Translate( [System.Security.Principal.NTAccount]) 
      $Identity = $objUser.Value
    }
    Write-VSOFTLog "Adding access right $AccessControlType $FileSystemRights to $Path for identity $Identity"
	$ArDir = New-Object System.Security.AccessControl.FileSystemAccessRule($Identity, $FileSystemRights, "ContainerInherit,ObjectInherit", "None", $AccessControlType)
	$ArFile = New-Object System.Security.AccessControl.FileSystemAccessRule($Identity, $FileSystemRights, "None", "None", $AccessControlType)

	if ((Get-Item $Path) -is  [System.IO.DirectoryInfo])
	{          
		$dirAcl = [System.IO.Directory]::GetAccessControl($Path)
        $dirAcl.SetAccessRule($ArDir)
        [System.IO.Directory]::SetAccessControl($Path, $dirAcl)
	}
	else
	{
		$fileAcl = [System.IO.File]::GetAccessControl($Path)
		$fileAcl.SetAccessRule($ArFile)
		[System.IO.File]::SetAccessControl($Path, $fileAcl)
	}
  }
  catch
  {
     Write-VSOFTLog ($_.Exception.Message) Error
  }
}





<#
.SYNOPSIS
Function creates SSRS folder in Reporting Services Server

.DESCRIPTION
Function creates folder in the root catalog in Reporting Services server. 
If folder already exist then nothing is done.

Limitation:
Folder is always created in the root and can have only one level.

.PARAMETER ReportingServicesURL
URL of the SSRS server. Usually http://<server>/ReportServer

.PARAMETER Folder
Name of the folder to be crested. Must start with "/", only one level depth is currently supported.

.PARAMETER Credential
Credential to be used while uploading reports.

.EXAMPLE
Add-VSOFTSSRSFolder   -ReportingServicesURL "http://myserver/ReportServer" -Folder "/MyFolder" 
#>
function Add-VSOFTSSRSFolder( [Parameter(Mandatory = $true)] [string] $ReportingServicesURL,
                                                             [string] $Folder,
                          [System.Management.Automation.PSCredential]
                          [System.Management.Automation.Credential()] $Credential = [System.Management.Automation.PSCredential]::Empty)
{
  Write-VSOFTLog "Creating folder $Folder at SSRS server $ReportingServicesURL" 
  if ($Folder -eq "/")
  {
     return
  }
  if (!$Folder.StartsWith("/"))
  {
     Write-VSOFTLog "Target SSRS folder ($Folder) must start with /" Error
  }
  if (([regex]::Matches($Folder, "/" )).count -gt 1)
  {
    Write-VSOFTLog "Add-VSOFTSSRSFolder function can create only folders with depth=1" Error
  }

  $reportServerUri = "$ReportingServicesURL/ReportService2010.asmx?wsdl"
  try 
  {
    if (($Credential) -and ($Credential -ne [System.Management.Automation.PSCredential]::Empty))
    {
      $rs = New-WebServiceProxy -Uri $reportServerUri -Credential $Credential
    }
    else 
    {
      $rs = New-WebServiceProxy -Uri $reportServerUri -UseDefaultCredential
    }
    $proxyNamespace = $rs.GetType().Namespace
    try
    {
         Write-VSOFTLog "Creating SSRS folder $Folder"
         $createdFolder = $rs.CreateFolder($Folder.substring(1), "/", $null)
    }
    catch [System.Web.Services.Protocols.SoapException]
    {
      if ($_.Exception.Detail.InnerText.StartsWith("rsItemAlreadyExists400"))
      {
         Write-VSOFTLog ("Folder $TargetFolder already exist")
      }
      else
      {
        throw
      }
    }
  }
  catch
  {
    Write-VSOFTLog ($_.Exception.Message) Error
  }
}


<#
.SYNOPSIS
Function uploads SSRS data source into Reporting Services Server

.DESCRIPTION
Function takes datasource file specified by paramater and uploades it into Reporting Services server. 
Function can upload datasource into the folder but only one level folder is supported.

You need to configure datasource on existing SSRS server then download it into disk to have it ready for this function as a template. 
Then modify settings in the datasource template file (using xml modification functions) to match you target environment and to have it ready for upload.

.PARAMETER DataSourceFile
Filename of the datasource to be uploaded. 

.PARAMETER ReportingServicesURL
URL of the SSRS server. Usually http://<server>/ReportServer

.PARAMETER TargetFolder
Name of the folder into which datasource should be uploaded. Must start with "/", only one level depth is currently supported.

.PARAMETER Credential
Credential to be used while uploading reports.

.EXAMPLE
#Add-VSOFTSSRSUploadDataSource -DataSourceFile "Reports\Production.xml" -ReportingServicesURL "http://myserver/ReportServer" -TargetFolder "/MyFolder" 
#>
function Add-VSOFTSSRSUploadDataSource  ([Parameter(Mandatory = $true)] [string] $DataSourceFile,
                                         [Parameter(Mandatory = $true)] [string] $ReportingServicesURL,
                                                                        [string] $TargetFolder = "/",
                                     [System.Management.Automation.PSCredential]
                                     [System.Management.Automation.Credential()] $Credential = [System.Management.Automation.PSCredential]::Empty)
{
  $FullDataSourceFile = Resolve-Path $DataSourceFile
  Write-VSOFTLog "Uploading data source $FullDataSourceFile into ReportingServices server at $ReportingServicesURL" 
  $reportServerUri = "$ReportingServicesURL/ReportService2010.asmx?wsdl"
  try 
  {
    if (($Credential) -and ($Credential -ne [System.Management.Automation.PSCredential]::Empty))
    {
      $rs = New-WebServiceProxy -Uri $reportServerUri -Credential $Credential
    }
    else 
    {
      $rs = New-WebServiceProxy -Uri $reportServerUri -UseDefaultCredential
    }
    $proxyNamespace = $rs.GetType().Namespace

    if ($TargetFolder)
    {
      Add-VSOFTSSRSFolder -ReportingServicesURL $ReportingServicesURL -Folder $TargetFolder -Credential $Credential  
    }

    Write-VSOFTLog "Uploading data source $FullDataSourceFile into $TargetFolder"
    $DSName = [System.IO.Path]::GetFileNameWithoutExtension($FullDataSourceFile)
    $DSContent = [System.IO.File]::ReadAllBytes($FullDataSourceFile)
    $warnings = $null
    $report = $rs.CreateCatalogItem("DataSource", $DSName, $TargetFolder, $true, $DSContent, $null, [ref]$warnings)
      
    Foreach ($warning in $warnings)
    {
      Write-VSOFTLog ("Warning: $($warning.Message)") Warn
    }
  }
  catch
  {
    Write-VSOFTLog ($_.Exception.Message) Error
  }
}

<#
.SYNOPSIS
Function uploads SSRS Reports into Reporting Services Server

.DESCRIPTION
Function takes rdl files specified by file mask and uploades them into Reporting Services server. 
If target data source is provided then after upload Data Source inside reports is updated to point to provided data source name.
Function can upload reports into the folder but only one level folder is supported.

.PARAMETER ReportFiles
File mask that specifies .rdl files to be uploaded. Any value supported by Get-ChildItem commant can be used.

.PARAMETER ReportingServicesURL
URL of the SSRS server. Usually http://<server>/ReportServer

.PARAMETER TargetDataSource
Full name (may include folder name) of the existing data source that should be used by uploaded reports.

.PARAMETER TargetFolder
Name of the folder into which reports should be uploaded. Must start with "/", only one level depth is currently supported.

.PARAMETER Credential
Credential to be used while uploading reports.

.EXAMPLE
Add-VSOFTSSRSUploadReports    -ReportFiles "Reports\*.rdl" -ReportingServicesURL "http://myserver/ReportServer" -TargetFolder "/MyFolder"  -TargetDataSource "/MyFolder/Production"
#>
function Add-VSOFTSSRSUploadReports  ([Parameter(Mandatory = $true)] [string] $ReportFiles,
                                      [Parameter(Mandatory = $true)] [string] $ReportingServicesURL,
                                                                     [string] $TargetDataSource,
                                                                     [string] $TargetFolder = "/",
                                  [System.Management.Automation.PSCredential]
                                  [System.Management.Automation.Credential()] $Credential = [System.Management.Automation.PSCredential]::Empty)
{
  Write-VSOFTLog "Uploading reports $ReportFiles into SSRS server at $ReportingServicesURL" 
  $reportServerUri = "$ReportingServicesURL/ReportService2010.asmx?wsdl"
  try 
  {
    if (($Credential) -and ($Credential -ne [System.Management.Automation.PSCredential]::Empty))
    {
      $rs = New-WebServiceProxy -Uri $reportServerUri -Credential $Credential
    }
    else 
    {
      $rs = New-WebServiceProxy -Uri $reportServerUri -UseDefaultCredential
    }
    $proxyNamespace = $rs.GetType().Namespace

    if ($TargetFolder)
    {
      Add-VSOFTSSRSFolder -ReportingServicesURL $ReportingServicesURL -Folder $TargetFolder -Credential $Credential  
    }

    $actualReportFiles = Get-ChildItem -Path $ReportFiles 
    foreach($reportFile in $actualReportFiles)
    {
      Write-VSOFTLog "Uploading report $($reportFile.FullName) into folder $TargetFolder"
      $reportName = [System.IO.Path]::GetFileNameWithoutExtension($reportFile.Name)
      $rdlContent = [System.IO.File]::ReadAllBytes($reportFile.FullName)
      $warnings = $null
                               # Catalog item type, Report name, Destination folder, Overwrite, Prooerties, warnings
      $report = $rs.CreateCatalogItem("Report", $reportName, $TargetFolder, $true, $rdlContent, $null, [ref]$warnings)              
      Foreach ($warning in $warnings)
      {
        Write-VSOFTLog ("Warning: $($warning.Message)")
      }
      if ($TargetDataSource)
      {
        Write-VSOFTLog "Updading data source in $reportName to $TargetDataSource"
        # Pobranie nazwy DataSource z pliku zrodlowego
        # $referencedDataSource = (@( $rs.GetItemReferences($report.Path,"DataSource")))[0]
        # $OldDSName = $referencedDataSource.Name
        $dataSource = New-Object ("$proxyNamespace.DataSource")
        $dataSource.Name = "DS" # $OldDSName
        $dataSource.Item = New-Object ("$proxyNamespace.DataSourceReference")
        $dataSource.Item.Reference = $TargetDataSource
        $rs.SetItemDataSources($report.Path,@( $dataSource))
      }
    }
  }
  catch
  {
    Write-VSOFTLog ($_.Exception.Message) Error
  }
}


<#
.SYNOPSIS
Function sets up reverse proxy configuration on IIS.

.DESCRIPTION
Function requires URL Rewrite IIS Extension https://www.iis.net/downloads/microsoft/url-rewrite
Function requires Application Request Routing (ARR) IIS Extension https://www.iis.net/downloads/microsoft/application-request-routing

.PARAMETER  SiteName
Name of the target web site.

.PARAMETER  ServiceBaseUrl
Address of the rest service

.PARAMETER  ServiceProxyUrl
Address of the service proxy

.PARAMETER  ServiceProxyApp
Name of the service proxy app.

.PARAMETER  ServiceProxyName
Name of the service proxy instance.

.EXAMPLE
Add-VSOFTRuleUrlRewrite -SiteName "Default Web Site" -ServiceBaseUrl "https://appserver/Scheduler-rest" -ServiceProxyApp "scheduler_webapp/rest-proxy" -ServiceProxyName "scheduler_proxy"
#>
function Add-VSOFTRuleUrlRewrite(
	[Parameter(Mandatory = $true)] [string] $SiteName, 
	[Parameter(Mandatory = $true)] [string] $ServiceBaseUrl,
	[Parameter(Mandatory = $true)] [string] $ServiceProxyApp, 
	[Parameter(Mandatory = $true)] [string] $ServiceProxyName, 
								   [string] $ServiceProxyUrl
) 
{
	Write-VSOFTLog "Starting reverse proxy configuration..."
	Write-VSOFTLog "WebSite name: $SiteName"
	Write-VSOFTLog "Proxy address: $ServiceProxyApp"
	Write-VSOFTLog "Target address: $ServiceBaseUrl"
	Write-VSOFTLog "Parameter ServiceProxyUrl is depracated (not used)" Warning

	$site = "iis:\sites\$SiteName"
	Set-WebConfigurationProperty -pspath "MACHINE/WEBROOT/APPHOST" -filter "system.webServer/proxy" -name "enabled" -value "True"
	Set-WebConfigurationProperty -pspath "MACHINE/WEBROOT/APPHOST" -filter "system.webServer/proxy" -name "minResponseBuffer" -value 131072
	
	$ruleName = "RestApiRequest_$ServiceProxyName"
	$filterRoot = "system.webServer/rewrite/rules/rule[@name='$ruleName']"
	Clear-WebConfiguration -pspath $site -filter $filterRoot
	
	Add-WebConfigurationProperty -pspath $site -filter "system.webServer/rewrite/rules" -name "." -value @{name=$ruleName ;patternSyntax='Regular Expressions';stopProcessing='True'}
	Set-WebConfigurationProperty -pspath $site -filter "$filterRoot/match" -name "url" -value "$ServiceProxyApp/(.*)"
	Set-WebConfigurationProperty -pspath $site -filter "$filterRoot/conditions" -name "logicalGrouping" -value "MatchAny"
	Set-WebConfigurationProperty -pspath $site -filter "$filterRoot/conditions" -name "." -value @{
		input = '{HTTPS}'
		matchType ='0'
		pattern = (&{If($ServiceBaseUrl.ToLower().StartsWith("https")) {'^ON$'} Else {'^OFF$'}})
		ignoreCase ='True'
		negate ='False'
	}
	
	Set-WebConfigurationProperty -pspath $site -filter "$filterRoot/conditions" -name "logicalGrouping" -value "MatchAny"

	Set-WebConfigurationProperty -pspath $site -filter "$filterRoot/action" -name "type" -value "Rewrite"
	Set-WebConfigurationProperty -pspath $site -filter "$filterRoot/action" -name "url" -value "$ServiceBaseUrl/{R:1}"
	
	Write-VSOFTLog "Reverse proxy has been successfully configured."
}


<#
.SYNOPSIS
Function removes reverse proxy configuration from IIS.

.DESCRIPTION
Function requires URL Rewrite IIS Extension https://www.iis.net/downloads/microsoft/url-rewrite
Function requires Application Request Routing (ARR) IIS Extension https://www.iis.net/downloads/microsoft/application-request-routing

.PARAMETER  SiteName
Name of the target web site.

.PARAMETER  ServiceProxyApp
Name of the service proxy app.

.PARAMETER  ServiceProxyName
Name of the service proxy instance.

.EXAMPLE
Remove-VSOFTRuleUrlRewrite -SiteName "Default Web Site" -ServiceProxyName "scheduler_proxy"
#>
function Remove-VSOFTRuleUrlRewrite(
	[Parameter(Mandatory = $true)] [string] $SiteName, 
	[Parameter(Mandatory = $true)] [string] $ServiceProxyName
) 
{
	Write-VSOFTLog "Starting reverse proxy removal..."
	Write-VSOFTLog "WebSite name: $SiteName"

	$site = "iis:\sites\$SiteName"
	$ruleName = "RestApiRequest_$ServiceProxyName"
	$filterRoot = "system.webServer/rewrite/rules/rule[@name='$ruleName']"
	Clear-WebConfiguration -pspath $site -filter $filterRoot
	
	$ruleName = "RestoreHttpEncodingHeader_$ServiceProxyName"
	$filterRoot = "system.webServer/rewrite/outboundRules/rule[@name='$ruleName']"
	Clear-WebConfiguration -pspath $site -filter $filterRoot
	Clear-WebConfiguration -pspath $site -filter "//System.webServer/rewrite/outboundRules/preConditions/preCondition[@name='HttpHeaderExists_$ServiceProxyName']"  -Force
	
	$ruleName = "RestApiResponse_$ServiceProxyName"
	$filterRoot = "system.webServer/rewrite/outboundRules/rule[@name='$ruleName']"
	Clear-WebConfiguration -pspath $site -filter $filterRoot
	Clear-WebConfiguration -pspath $site -filter "//System.webServer/rewrite/outboundRules/preConditions/preCondition[@name='Json_$ServiceProxyName']"  -Force

	
	Write-VSOFTLog "Reverse proxy has been successfully removed."
}


<#
.SYNOPSIS
Function installs VSoft InstallTools module into Powershell modules folder.

.DESCRIPTION
After installing InstallTools module it gets detected by Powershell editors. 
This allows using its help, IntelliSense etc.

.EXAMPLE
Install-VSOFTInstallToolsModule 
#>
function Install-VSOFTInstallToolsModule()
{
  try
  {
    $ModulesPath=$Env:PSModulePath.Split(";")[0]
    $ScriptLocation = Split-Path -Parent $script:MyInvocation.MyCommand.Definition
    Write-VSOFTLog "Installing InstallTools module into path $ModulesPath from $ScriptLocation"
    Copy-VSOFTFiles $ScriptLocation $ModulesPath\InstallTools -PurgeDestination
  }
  catch
  {
    Write-VSOFTLog ($_.Exception.Message) Error
  }
}


#Initialize functions in this module
Initialize-VSOFTInstallTools 



Export-ModuleMember -Function Show-VSOFTLogForTFS
Export-ModuleMember -Function Write-VSOFTLog
Export-ModuleMember -Function Write-VSOFTLogHeader

Export-ModuleMember -Function Test-VSOFTIISisInstalled

Export-ModuleMember -Function Test-VSOFTdotNET48isInstalled
Export-ModuleMember -Function Test-VSOFTdotNET472isInstalled
Export-ModuleMember -Function Test-VSOFTdotNET471isInstalled
Export-ModuleMember -Function Test-VSOFTdotNET47isInstalled
Export-ModuleMember -Function Test-VSOFTdotNET462isInstalled
Export-ModuleMember -Function Test-VSOFTdotNET46isInstalled
Export-ModuleMember -Function Test-VSOFTdotNET45isInstalled
Export-ModuleMember -Function Test-VSOFTdotNET40isInstalled
Export-ModuleMember -Function Test-VSOFTdotNET35isInstalled
Export-ModuleMember -Function Test-VSOFTdotNET30isInstalled
Export-ModuleMember -Function Test-VSOFTdotNET20isInstalled

Export-ModuleMember -Function Test-VSOFTVCRedist2010x64isInstalled
Export-ModuleMember -Function Test-VSOFTVCRedist2013x64isInstalled

Export-ModuleMember -Function Test-VSOFTFileEncodingIsUTF8

Export-ModuleMember -Function Install-VSOFTWindowsRequiredFeatures

Export-ModuleMember -Function Copy-VSOFTFiles

Export-ModuleMember -Function Expand-VSOFTArchive
Export-ModuleMember -Function Start-VSOFTWebAppPool
Export-ModuleMember -Function Stop-VSOFTWebAppPool
Export-ModuleMember -Function Add-VSOFTAppPool
Export-ModuleMember -Function Remove-VSOFTWebAppPool

Export-ModuleMember -Function Add-VSOFTWebSite
Export-ModuleMember -Function Remove-VSOFTWebSite
Export-ModuleMember -Function Add-VSOFTWebBinding
Export-ModuleMember -Function Remove-VSOFTWebBinding

Export-ModuleMember -Function Add-VSOFTWebApp
Export-ModuleMember -Function Remove-VSOFTWebApp

Export-ModuleMember -Function Update-VSOFTIISConfigurationForTLS

Export-ModuleMember -Function Start-VSOFTService
Export-ModuleMember -Function Stop-VSOFTService
Export-ModuleMember -Function Install-VSOFTService
Export-ModuleMember -Function Remove-VSOFTService

Export-ModuleMember -Function Update-VSOFTXmlConfig
Export-ModuleMember -Function Remove-VSOFTXmlConfigNode

Export-ModuleMember -Function Update-VSOFTIniConfig
Export-ModuleMember -Function Remove-VSOFTIniConfigEntry
Export-ModuleMember -Function Remove-VSOFTIniConfigComments

Export-ModuleMember -Function Update-VSOFTReplaceRegexInFile

Export-ModuleMember -Function Test-VSOFTSQLConnection
Export-ModuleMember -Function Invoke-VSOFTDbUpgrader

Export-ModuleMember -Function Get-VSOFTDBConfigKey
Export-ModuleMember -Function Update-VSOFTDBConfigKey

Export-ModuleMember -Function Test-VSOFTRemotePSScript
Export-ModuleMember -Function Invoke-VSOFTRemotePSScript

Export-ModuleMember -Function Test-VSOFTCredential

Export-ModuleMember -Function Test-VSOFTCertificate

Export-ModuleMember -function Grant-VSOFTLogOnAsService
Export-ModuleMember -function Add-VSOFTFileAccessRule

Export-ModuleMember -function Add-VSOFTSSRSFolder
Export-ModuleMember -function Add-VSOFTSSRSUploadDataSource 
Export-ModuleMember -function Add-VSOFTSSRSUploadReports

Export-ModuleMember -function Add-VSOFTRuleUrlRewrite
Export-ModuleMember -function Remove-VSOFTRuleUrlRewrite

Export-ModuleMember -function Install-VSOFTInstallToolsModule



<#
Major changes in versions:
17.1.48 
- Copy-VSOFTFiles: Added removal of ReadOnly attribute while coping files
- Add-VSOFTWebSite: Better checking of existence of binding while creating new web site
- Install-VSOFTWindowsRequiredFeatures: Added function for installing prerequisites supporting both Windows client and server 

17.1.51
 - Extract-VSOFTArchive: Added function for extracting zip archives
 - Update-VSOFTXmlConfig, Update-VSOFTIniConfig: Added ability to pass hash table with list of options to be updated 
 - Update-VSOFTXmlConfig: Fixed handling error when XPath is not found
 - Install-VSOFTWindowsRequiredFeatures: On Windows client functions installs only missing features for better performance
 - Install-VSOFTService: Added check for presence of service executable
 - Removed support for IIS older that 7.
 - Improved handling of empty Credentials


#>
